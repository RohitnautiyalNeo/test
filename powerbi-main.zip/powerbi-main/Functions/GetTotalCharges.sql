DROP FUNCTION IF EXISTS GetTotalCharges;

DELIMITER $$

CREATE FUNCTION GetTotalCharges(id_input INT) 
RETURNS DECIMAL(10, 2)
DETERMINISTIC
BEGIN

    DECLARE TotalCharges DECIMAL(10, 2);

    SET @EncKey = EncKey();

    SELECT SUM(CAST(REPLACE(REPLACE(AES_DECRYPT(Total_Acc_Bal, @EncKey), '$', ''), ',', '') AS DECIMAL(10, 2)))
    INTO TotalCharges
    FROM charges
    WHERE id IN (
        SELECT MAX(id) 
        FROM charges 
        WHERE case_id = id_input
          AND AES_DECRYPT(Total_Acc_Bal, @EncKey) IS NOT NULL
        GROUP BY case_id, AES_DECRYPT(charges_ref_number, @EncKey)
    )
    GROUP BY case_id;

    RETURN IFNULL(TotalCharges, 0);
END$$

DELIMITER ;
