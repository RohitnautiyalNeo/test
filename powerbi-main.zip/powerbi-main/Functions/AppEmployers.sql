DROP FUNCTION IF EXISTS AppEmployers;

DELIMITER $$

CREATE FUNCTION AppEmployers(employer varchar(50))
RETURNS int
DETERMINISTIC
BEGIN
DECLARE EmpTotal int;

SELECT COUNT(*)
INTO EmpTotal
FROM case_enrollment_details_current e
INNER JOIN track_case t on e.case_id = t.case_id
INNER JOIN case_status cs on t.status = cs.value
WHERE e.field_type = 'employer' 
and e.field_key = 'NAME'
and e.field_value LIKE CONCAT('%', employer, '%')
and cs.status = 'Application Approved';

RETURN IFNULL(EmpTotal, 0);

END$$

DELIMITER ;