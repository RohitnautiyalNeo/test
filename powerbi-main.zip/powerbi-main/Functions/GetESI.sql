DROP FUNCTION IF EXISTS GetESI;

DELIMITER $$

CREATE FUNCTION GetESI(input_id INT) 
RETURNS DATE
DETERMINISTIC
BEGIN
    DECLARE esi_date DATE;

    SELECT 
        COALESCE(
                DATE_FORMAT(STR_TO_DATE(esi_effective_date, '%m/%d/%Y'), '%Y-%m-%d'),
                DATE_FORMAT(STR_TO_DATE(esi_effective_date, '%Y-%m-%d'), '%Y-%m-%d'),
                DATE_FORMAT(STR_TO_DATE(esi_effective_date, '%Y-%m-%d %H:%i:%s'), '%Y-%m-%d')
        ) 
    INTO esi_date
    FROM case_verification_details
    WHERE case_id = input_id
    LIMIT 1;

    RETURN esi_date;
END$$

DELIMITER ;
