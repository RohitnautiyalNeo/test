DROP FUNCTION IF EXISTS targetAdmit;

DELIMITER $$

CREATE FUNCTION targetAdmit(caseID int, targetDate varchar(50))
RETURNS VARCHAR(50)
DETERMINISTIC
BEGIN
    DECLARE AdmDate varchar(50);

    SET @EncKey = EncKey();

SELECT admit_date
INTO AdmDate
FROM (
	SELECT admit_date
	,ROW_NUMBER () OVER(PARTITION BY c.case_id ORDER BY id DESC) as rownum
	FROM charges c
	WHERE c.case_id = caseID
	AND FROM_UNIXTIME(c.created_at,'%Y-%m-%d') <= targetDate) as InnerTable
WHERE InnerTable.rownum = 1;

    RETURN AdmDate;
END$$
