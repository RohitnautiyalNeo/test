DROP FUNCTION IF EXISTS GetDOB;

DELIMITER $$

CREATE FUNCTION GetDOB(id INT)
RETURNS DATE
DETERMINISTIC
BEGIN
    DECLARE OutDOB DATE;

    SET @EncKey = EncKey();
    SET @DOB_Format = (SELECT value FROM setting WHERE setting_key = 'DOB_DATE_FORMAT' LIMIT 1);
    SET @DOBK = (SELECT column_value FROM upload_settings WHERE column_name = 'DOB_KEY' LIMIT 1);

#   SELECT STR_TO_DATE(AES_DECRYPT(column_value, @EncKey), @DOB_Format)
    SELECT COALESCE(
               STR_TO_DATE(AES_DECRYPT(column_value, @EncKey), @DOB_Format),
               STR_TO_DATE(AES_DECRYPT(column_value, @EncKey), '%Y-%m-%d %H:%i:%s'),
               STR_TO_DATE(AES_DECRYPT(column_value, @EncKey), '%m/%d/%Y')
           ) AS DOB
    INTO OutDOB
    FROM demographic_meta
    WHERE case_id = id
      AND column_name = @DOBK
    LIMIT 1;

    RETURN OutDOB;

END$$

DELIMITER ;
