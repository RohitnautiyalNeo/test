DROP FUNCTION IF EXISTS GetLastName;

DELIMITER $$

CREATE FUNCTION GetLastName(input_id INT)
RETURNS VARCHAR(50)
DETERMINISTIC
BEGIN
    DECLARE OutVal VARCHAR(50);
    SET @EncK = EncKey();
    SET @ColumnV = (SELECT column_value FROM upload_settings WHERE column_name = 'NAME_KEY' LIMIT 1);
    SET @Column = (SELECT column_value FROM upload_settings WHERE column_name = 'LAST_KEY' LIMIT 1);

    SELECT 
        TRIM(SUBSTRING_INDEX(
            AES_DECRYPT(
                COALESCE(
                    (SELECT column_value 
                     FROM demographic_meta 
                     WHERE case_id = input_id 
                       AND column_name = @Column
                     LIMIT 1),
                    (SELECT column_value 
                     FROM demographic_meta 
                     WHERE case_id = input_id 
                       AND column_name = @ColumnV 
                     LIMIT 1)
                ), 
                @EncK
            ), 
            ',', 1
        )) 
    INTO OutVal;

    RETURN OutVal;
END$$

DELIMITER ;
