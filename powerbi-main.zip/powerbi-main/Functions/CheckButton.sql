DROP FUNCTION IF EXISTS CheckButton;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` FUNCTION `CheckButton`(
cid INT
) RETURNS int
    DETERMINISTIC
BEGIN

DECLARE OutVal int;

With OrderedTemp as (
select *
,ROW_NUMBER () OVER(PARTITION BY c.case_id,c.field_key,field_type,familymembernumber,count_template_number ORDER BY id desc) as rownum
from case_enrollment_details c
where is_deleted = 0
and case_id = cid
)


select count(case_id) INTO OutVal
from OrderedTemp
where rownum = 1
and field_key in ('MRN','MEMBER MRN','ESI CARRIER', 'ESI ID','EFF','FIRSTNAME','FIRST NAME','LASTNAME','LAST NAME','BIRTH DOB','DOB')
and field_value is null
LIMIT 1;

RETURN OutVal;
END$$
DELIMITER ;