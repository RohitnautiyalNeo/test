DROP FUNCTION IF EXISTS GetDaysLeft;
DELIMITER $$

CREATE FUNCTION GetDaysLeft(id INT) 
RETURNS INT
DETERMINISTIC
BEGIN
    DECLARE DaysLeftss INT;

    SET @ENCKEY = EncKey();
    SET @Admit_Format = (SELECT value FROM setting WHERE setting_key = 'ADMIT_DATE_FORMAT' LIMIT 1);
    SET @Admit_DT = (SELECT value FROM setting WHERE setting_key = 'ADMIT_DATE_FIELD' LIMIT 1);

    WITH TrackQLE AS (
        SELECT * 
        FROM track_qle 
        WHERE id IN (
            SELECT MAX(id) AS id 
            FROM track_qle 
            GROUP BY case_id
        )
    ),
    ESI_Dates AS (
        SELECT 
            case_id, 
            COALESCE(
                DATE_FORMAT(STR_TO_DATE(esi_effective_date, '%m/%d/%Y'), '%Y-%m-%d'),
                DATE_FORMAT(STR_TO_DATE(esi_effective_date, '%Y-%m-%d'), '%Y-%m-%d'),
                DATE_FORMAT(STR_TO_DATE(esi_effective_date, '%Y-%m-%d %H:%i:%s'), '%Y-%m-%d')
            ) AS ESI_DATE
        FROM case_verification_details
    ),
    AdmitDates AS (
        SELECT 
            case_id,
            COALESCE(
                DATE_FORMAT(STR_TO_DATE(AES_DECRYPT(column_value, @ENCKEY), '%m/%d/%Y'), '%Y-%m-%d'),
                DATE_FORMAT(STR_TO_DATE(AES_DECRYPT(column_value, @ENCKEY), '%Y-%m-%d'), '%Y-%m-%d'),
                DATE_FORMAT(STR_TO_DATE(AES_DECRYPT(column_value, @ENCKEY), '%Y-%m-%d %H:%i:%s'), '%Y-%m-%d')
            ) AS ADMIT_DATE
        FROM 
            demographic_meta
        WHERE 
            column_name = @Admit_DT
    ),
    DaysLeftCTE AS (
        SELECT 
            d.id AS case_id,
            qle.days AS DAYS,
            ESI_Dates.ESI_DATE AS ESI_DATE,
            AdmitDates.ADMIT_DATE AS ADMIT_DATE,
            DATE_FORMAT(CURDATE(), '%Y-%m-%d') AS CURR_DATE,
            CASE
                WHEN ESI_Dates.ESI_DATE IS NOT NULL THEN DAYS - DATEDIFF(CURDATE(), ESI_Dates.ESI_DATE)
                ELSE DAYS - DATEDIFF(CURDATE(), AdmitDates.ADMIT_DATE)
            END AS DaysLeft
        FROM 
            demographics d
        LEFT JOIN TrackQLE tqle ON tqle.case_id = d.id
        LEFT JOIN qle ON qle.id = tqle.qle  
        LEFT JOIN ESI_Dates ON ESI_Dates.case_id = d.id
        LEFT JOIN AdmitDates ON AdmitDates.case_id = d.id
        WHERE 
            LEFT(AES_DECRYPT(MRN, @ENCKEY), 2) != '0-'
    )

    SELECT DaysLeft 
    INTO DaysLeftss
    FROM DaysLeftCTE
    WHERE case_id = id
    LIMIT 1;

    RETURN DaysLeftss;
    
END$$
DELIMITER ;
