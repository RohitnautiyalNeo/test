DROP FUNCTION IF EXISTS PickSecondary;

DELIMITER $$
CREATE FUNCTION `PickSecondary`(`chargeID` INT) RETURNS varchar(100) CHARSET utf8mb4
    DETERMINISTIC
BEGIN

DECLARE OutVal varchar(100);

With Cohort as (
select c.Admit_Date
,c.Discharge_Date
,c.enrollee_id
,d.case_group
from charges c
LEFT JOIN demographics d on c.enrollee_id = d.id
where c.id = chargeID
),

Gather_Ins as (
SELECT cv.plan as InsName
,ROW_NUMBER() OVER(PARTITION BY case_id ORDER BY STR_TO_DATE(cd.effective_date,'%m/%d/%Y') asc) as rownum
FROM Cohort c
INNER JOIN coverages cv on c.case_group = cv.group_id
INNER JOIN coverages_details cd on cv.id = cd.coverage_id and c.enrollee_id = cd.case_id
INNER JOIN coverage_payors p on cd.payor_id = p.id
left join coverage_tpa tpa on cv.tpa = tpa.id
WHERE cv.level = 'secondary'
AND ((UNIX_TIMESTAMP(STR_TO_DATE(Admit_Date,'%m/%d/%Y')) - 
     UNIX_TIMESTAMP(STR_TO_DATE(
     CASE
     	WHEN term_date='' THEN '01/01/2040'
     	WHEN term_date IS NULL THEN '01/01/2040'
     	ELSE term_date
     END,'%m/%d/%Y'))) *
    (UNIX_TIMESTAMP(STR_TO_DATE(
    CASE
    	WHEN Discharge_Date='' THEN '01/01/2040'
    	WHEN Discharge_Date IS NULL THEN '01/01/2040'
    	ELSE Discharge_Date
    END,'%m/%d/%Y')) - 
    UNIX_TIMESTAMP(STR_TO_DATE(
    CASE
    	WHEN effective_date='' THEN '01/01/2040'
    	WHEN effective_date IS NULL THEN '01/01/2040'
    	ELSE effective_date
    END,'%m/%d/%Y'))) <= 0) 
    OR ((effective_date IS NULL OR effective_date = '')
     AND (term_date IS NULL or term_date = ''))
)

select 
CASE
	WHEN g2.InsName IS NOT NULL THEN CONCAT(g.InsName,'/',g2.InsName)
    ELSE g.InsName
END into OutVal
FROM Gather_Ins g
LEFT JOIN  Gather_Ins g2 on g2.rownum = 2
WHERE g.rownum = 1;


RETURN OutVal;
END$$
DELIMITER ;