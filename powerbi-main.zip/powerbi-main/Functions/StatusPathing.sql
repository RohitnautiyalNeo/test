DROP FUNCTION IF EXISTS StatusPathing;

DELIMITER $$

CREATE FUNCTION StatusPathing(
cid INT,
from_type VARCHAR(100),
thru_type VARCHAR(100)
)
RETURNS longtext
DETERMINISTIC
BEGIN

DECLARE OutVal longtext;

WITH RECURSIVE possible_path AS (
    SELECT  t.status
           ,t.previous_status
           ,t.case_id
           ,s.status as 'NamedStatus'
           ,s.status as route
           ,t.time_spent
           ,t.created
      from track_case t
      left join case_status s on t.status = s.value
      left join case_status s2 on t.previous_status = s2.value
      WHERE s.status = from_type
      and t.case_id = cid
 
UNION ALL
 
SELECT t.status
      ,t.previous_status
      ,t.case_id
      ,s.status as 'NamedStatus'
      ,CONCAT(pp.route, '->', s.status) as route
      ,pp.time_spent + t.time_spent as time_spent
      ,t.created
FROM possible_path pp
inner join track_case t on pp.case_id = t.case_id and t.previous_status = pp.status and t.created > pp.created
left join case_status s on t.status = s.value
left join case_status s2 on t.previous_status = s2.value
)


SELECT route INTO OutVal
FROM possible_path pp
WHERE pp.NamedStatus = thru_type
ORDER BY time_spent ASC
LIMIT 1;

RETURN OutVal;
END$$

DELIMITER ;