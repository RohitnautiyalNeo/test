DROP FUNCTION IF EXISTS GetAdmit;

DELIMITER $$

CREATE FUNCTION GetAdmit(id INT)
RETURNS DATE
DETERMINISTIC
BEGIN

    DECLARE OutAdmit DATE;
    SET @EncKey = EncKey();
    SET @Admit_Format = (SELECT value FROM setting WHERE setting_key = 'ADMIT_DATE_FORMAT' LIMIT 1);
    SET @ADF = (SELECT value FROM setting WHERE setting_key = 'ADMIT_DATE_FIELD' LIMIT 1);

#    SELECT STR_TO_DATE(AES_DECRYPT(column_value, @EncKey), @DOB_Format)
	SELECT
    	COALESCE(
    		STR_TO_DATE(AES_DECRYPT(column_value, @EncKey), @Admit_Format),
    		STR_TO_DATE(AES_DECRYPT(column_value, @EncKey), '%Y-%m-%d %H:%i:%s'),
    		STR_TO_DATE(AES_DECRYPT(column_value, @EncKey), '%m/%d/%Y')
    			) AS DOB
    
    INTO OutAdmit
    FROM demographic_meta
      WHERE case_id = id
      AND column_name = @ADF
    LIMIT 1;

    RETURN OutAdmit;
END$$

DELIMITER ;
