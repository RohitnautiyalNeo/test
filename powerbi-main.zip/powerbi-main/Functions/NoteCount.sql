DROP FUNCTION IF EXISTS NoteCount;

DELIMITER $$

CREATE FUNCTION NoteCount(caseID int, targetNote varchar(20), targetDate date)
RETURNS int
DETERMINISTIC
BEGIN
DECLARE NoteTotal int;

SET @EncKey = EncKey();

SELECT COUNT(*)
INTO NoteTotal
FROM notes
WHERE case_id = caseID
AND AES_DECRYPT(Note, @EncKey) LIKE CONCAT('%', targetNote, '%')
AND NoteDate <= targetDate
AND NoteDate >= DATE_ADD(targetDate, INTERVAL -7 DAY);



RETURN IFNULL(NoteTotal, 0);

END$$

DELIMITER ;