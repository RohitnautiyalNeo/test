DROP FUNCTION IF EXISTS GetCharges;

DELIMITER $$

CREATE FUNCTION GetCharges(caseID int, targetDate date)
RETURNS int
DETERMINISTIC
BEGIN
DECLARE ChargeTotal DECIMAL(10, 2);

    SET @EncKey = EncKey();

SELECT SUM(x.TotalCharges)
INTO ChargeTotal
FROM (
        SELECT c.case_id,
         CAST(REPLACE(REPLACE(AES_DECRYPT(c.Total_Acc_Bal, @EncKey),'$',''),',','') AS DECIMAL(10,2)) AS TotalCharges,
         c.created_at, 
         ROW_NUMBER() OVER (PARTITION BY c.case_id, AES_DECRYPT(c.charges_ref_number, @EncKey) ORDER BY c.id DESC) AS rn
        FROM charges c
        INNER JOIN demographics d on c.case_id = d.id
        WHERE AES_DECRYPT(c.Total_Acc_Bal, @EncKey) IS NOT NULL
        AND FROM_UNIXTIME(c.created_at,'%Y-%m-%d') <= targetDate
        AND FROM_UNIXTIME(c.created_at,'%Y-%m-%d') >= (d.date_add - INTERVAL 60 day)
        AND c.case_id = caseID
     ) x
WHERE x.rn = 1
GROUP BY case_id;

    RETURN IFNULL(ChargeTotal, 0);
END$$

DELIMITER ;