DROP FUNCTION IF EXISTS NoteDate;

DELIMITER $$

CREATE FUNCTION NoteDate(caseGroup int, targetNote varchar(100), targetDate date)
RETURNS date
DETERMINISTIC
BEGIN
DECLARE NoteD date;

SET @EncKey = EncKey();

SELECT n.date_add
INTO NoteD
FROM demographics d
LEFT JOIN notes n on d.id = n.case_id
WHERE d.case_group = caseGroup
AND AES_DECRYPT(Note, @EncKey) LIKE CONCAT('%', targetNote, '%')
AND n.date_add <= targetDate
GROUP BY case_group;

RETURN NoteD;

END$$

DELIMITER ;