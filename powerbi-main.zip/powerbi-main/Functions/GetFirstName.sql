DROP FUNCTION IF EXISTS GetFirstName;

DELIMITER $$

CREATE FUNCTION GetFirstName(input_id INT)
RETURNS VARCHAR(50)
DETERMINISTIC
BEGIN
    DECLARE OutVal VARCHAR(50);
	SET @EncK = EncKey();
	SET @ColumnV = (SELECT column_value FROM upload_settings WHERE column_name = 'NAME_KEY' LIMIT 1);

    SELECT TRIM(SUBSTRING_INDEX(
    AES_DECRYPT(column_value, @EncK), ',', -1)) 
    INTO OutVal
    FROM demographic_meta 
    WHERE case_id = input_id 
      AND column_name = @ColumnV
    LIMIT 1;


    RETURN OutVal;
END$$

DELIMITER ;