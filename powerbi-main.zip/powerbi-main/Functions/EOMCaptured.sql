DROP FUNCTION IF EXISTS EOMCharges;

DELIMITER $$

CREATE FUNCTION EOMCharges(caseID int, AppDate date)
RETURNS DECIMAL(15,2)
DETERMINISTIC
BEGIN

DECLARE EOMCap DECIMAL(15,2);

SET @EncKey = EncKey();

SELECT 
CASE
	WHEN Captured1 IS NULL AND
	     Captured2 IS NULL AND 
	     Captured3 IS NULL THEN NULL
	ELSE IFNULL(Captured1,0) + IFNULL(Captured2,0) + IFNULL(Captured3,0) 
END
INTO EOMCap
FROM (
SELECT n.case_id
,nt.type
,n.date_add
,ROW_NUMBER () OVER(PARTITION BY n.case_id ORDER BY n.id desc) as rownum
,COALESCE(
    NULLIF(
		CAST(
			REGEXP_REPLACE(
			REGEXP_SUBSTR(AES_DECRYPT(n.Note, @EncKey),'\\[\\$[0-9,]+\\.?[0-9]*\\]',1,1),
     		'[^0-9.]','')
     	AS DECIMAL(15,2)),
    ''),
'0') as Captured1
,COALESCE(
    NULLIF(
		CAST(
			REGEXP_REPLACE(
			REGEXP_SUBSTR(AES_DECRYPT(n.Note, @EncKey),'\\[\\$[0-9,]+\\.?[0-9]*\\]',1,2),
     		'[^0-9.]','')
     	AS DECIMAL(15,2)),
    ''),
'0') as Captured2
,COALESCE(
    NULLIF(
		CAST(
			REGEXP_REPLACE(
			REGEXP_SUBSTR(AES_DECRYPT(n.Note, @EncKey),'\\[\\$[0-9,]+\\.?[0-9]*\\]',1,3),
     		'[^0-9.]','')
     	AS DECIMAL(15,2)),
    ''),
'0') as Captured3
FROM notes n
LEFT JOIN note_type nt on n.Note_type = nt.type_id
WHERE n.case_id = caseID
and nt.type = 'Hosp notified Verif tab completed'
AND MONTH(AppDate) = MONTH(n.date_add)
AND YEAR(AppDate) = YEAR(n.date_add)
AND REGEXP_SUBSTR(AES_DECRYPT(n.Note, @EncKey),'\\[\\$[0-9,]*\\.?[0-9]*\\]',1,1) IS NOT NULL
) as InnerTable
WHERE rownum = 1;

RETURN EOMCap;

END$$

DELIMITER ;