DROP FUNCTION IF EXISTS PickCoverageID;

DELIMITER $$
CREATE FUNCTION `PickCoverageID`(`chargeID` INT) RETURNS int
    DETERMINISTIC
BEGIN

DECLARE OutVal int;

With Cohort as (
select c.Admit_Date
,c.Discharge_Date
,c.enrollee_id
,d.case_group
,c.Created
from charges c
LEFT JOIN demographics d on c.enrollee_id = d.id
where c.id = chargeID
),

Gather_Ins as (
SELECT cd.coverage_id
,ROW_NUMBER() OVER(PARTITION BY case_id ORDER BY STR_TO_DATE(cd.effective_date,'%m/%d/%Y') asc) as rownum
FROM Cohort c
INNER JOIN coverages cv on c.case_group = cv.group_id
INNER JOIN coverages_details cd on cv.id = cd.coverage_id and c.enrollee_id = cd.case_id
INNER JOIN coverage_payors p on cd.payor_id = p.id
WHERE cv.level = 'primary'
AND (UNIX_TIMESTAMP(STR_TO_DATE(Admit_Date,'%m/%d/%Y')) - 
     UNIX_TIMESTAMP(STR_TO_DATE(
     CASE
     	WHEN term_date='' THEN '01/01/2040'
     	WHEN term_date IS NULL THEN '01/01/2040'
     	ELSE term_date
     END,'%m/%d/%Y'))) *
    (UNIX_TIMESTAMP(STR_TO_DATE(
    CASE
    	WHEN Discharge_Date='' THEN '01/01/2040'
    	WHEN Discharge_Date IS NULL THEN '01/01/2040'
    	ELSE Discharge_Date
    END,'%m/%d/%Y')) - 
    UNIX_TIMESTAMP(STR_TO_DATE(
    CASE
    	WHEN effective_date='' THEN '01/01/2040'
    	WHEN effective_date IS NULL THEN '01/01/2040'
    	ELSE effective_date
    END,'%m/%d/%Y'))) <= 0
)

select g.coverage_id into OutVal
FROM Gather_Ins g
LEFT JOIN  Gather_Ins g2 on g2.rownum = 2
WHERE g.rownum = 1;

RETURN OutVal;
END$$
DELIMITER ;