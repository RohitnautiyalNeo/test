DROP FUNCTION IF EXISTS RemainingWorkingDays;

DELIMITER $$

CREATE FUNCTION RemainingWorkingDays(targetDate date)
RETURNS int
DETERMINISTIC
BEGIN

DECLARE WorkingTotal int;

SELECT COUNT(working_date)
INTO WorkingTotal
FROM working_days
WHERE working_date >= targetDate
AND working_date <= LAST_DAY(targetDate);

RETURN IFNULL(WorkingTotal, 0);
END$$