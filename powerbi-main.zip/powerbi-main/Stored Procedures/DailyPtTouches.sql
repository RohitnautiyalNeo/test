DROP PROCEDURE IF EXISTS DailyPtTouches;

DELIMITER $$    
CREATE PROCEDURE DailyPtTouches()
BEGIN
    SET @EncKey = EncKey();
    SET SESSION group_concat_max_len = 1000000;

    SET @sql = NULL;
    SET @sql = CONCAT("
    
    WITH
    SigUsers AS (
        SELECT DISTINCT s.user_id
        FROM (
            SELECT * 
            FROM signatures 
            GROUP BY IF(case_group_id IS NULL 
                        OR case_group_id='', CONCAT('CG- ', case_id), case_group_id)
        ) AS s
        LEFT JOIN demographics d ON s.case_group_id = d.case_group
        LEFT JOIN setting ON setting_key = 'HOSPITAL_NAME'
        WHERE user_id IS NOT NULL 
        AND user_id IN (
            SELECT id 
            FROM admin_user 
            WHERE user_type != 1 
            AND username NOT IN ('shivam_support', 'revmax_superadmin')
        )
        AND s.case_id NOT IN (
            SELECT id FROM demographics WHERE AES_DECRYPT(MRN, '", @EncKey, "') LIKE '0-%'
        )
        AND FROM_UNIXTIME(s.created, '%Y-%m-%d') > (CURDATE() - INTERVAL 90 DAY)
    )
    
    SELECT 
        region.value AS 'Region',
        c.status AS CurrentStatus,
        CAST(AES_DECRYPT(au.name, '", @EncKey, "') AS CHAR) AS 'Patient Helper',
        n.case_id,
        cr.total_rank AS CaseRank,
        d.Total_Acc_Bal AS TotalCharges,
        hospital.value AS 'HOSPITAL_NAME',
        n.NoteDate,
        d.days_left AS DaysLeft
    FROM notes n
    LEFT JOIN setting hospital ON hospital.setting_key = 'HOSPITAL_NAME'
    LEFT JOIN demographics d ON d.id = n.case_id
    LEFT JOIN case_ranks cr ON cr.case_id = n.case_id
    LEFT JOIN admin_user au ON au.id = n.added_by
    INNER JOIN SigUsers s ON n.added_by = s.user_id
    INNER JOIN setting region ON region.setting_key = 'REGION'
    LEFT JOIN case_status c ON d.case_status = c.value
    LEFT JOIN campuses cp ON cp.id = d.campus
    WHERE 
        (CASE 
            WHEN STR_TO_DATE(AES_DECRYPT(n.NoteDate, '", @EncKey, "'), '%Y-%m-%d') IS NOT NULL 
                THEN STR_TO_DATE(AES_DECRYPT(n.NoteDate, '", @EncKey, "'), '%Y-%m-%d')
            WHEN STR_TO_DATE(AES_DECRYPT(n.NoteDate, '", @EncKey, "'), '%Y-%m-%d %H:%i:%s') IS NOT NULL 
                THEN STR_TO_DATE(AES_DECRYPT(n.NoteDate, '", @EncKey, "'), '%Y-%m-%d %H:%i:%s')
            ELSE STR_TO_DATE(AES_DECRYPT(n.NoteDate, '", @EncKey, "'), '%m/%d/%Y')
         END) = (CURDATE() - INTERVAL 1 DAY)
    AND (hospital.value = 'Phoebe' OR cp.campus_isactive = 1)
    GROUP BY n.case_id, au.username
    ORDER BY CAST(AES_DECRYPT(au.name, '", @EncKey, "') AS CHAR)");

    PREPARE stmt FROM @sql;
    EXECUTE stmt;
END$$    
DELIMITER ;