DROP PROCEDURE IF EXISTS BillingExportProc_Trinity; 

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `BillingExportProc_Trinity`(IN `AcctStatus` VARCHAR(255)
, IN `InvoiceMonth` INT
, IN `InvoiceYear` INT)
BEGIN

SET @EncKey = CATSEncKey();
SET @DBName = DATABASE();

SET SESSION group_concat_max_len = 1000000;


SET @sql = NULL;
SET @sql = CONCAT("
                  
SELECT AES_DECRYPT(AcctNumber,'",@EncKey,"') as 'Client Account Number'
,AES_DECRYPT(AcctNumber,'",@EncKey,"') as 'Vendor Account Number'
,DATE_FORMAT(STR_TO_DATE(Claim_date,'%m/%d/%Y'),'%Y%m%d') as 'Post Date'
,difference as 'Collected Amount'
,pfa_contingency as 'Fee Amount'
,0 as 'Flat Fee Amount'
,CONCAT(AES_DECRYPT(AcctNumber,'",@EncKey,"'),'_',REPLACE(Claim_date,'/','')) AS 'Transaction ID'
,cp.campus_name as 'Hospital Name'
,i.inv_number as 'Invoice #'
,DATE_FORMAT(STR_TO_DATE(i.inv_submit_date,'%m/%d/%Y'),'%Y%m%d') as 'Invoice Date'
,'Premium Assistance' as 'Service Line'
,NULL as 'Subscription Fee'
,NULL as 'Transaction Amount'
FROM charges c
LEFT JOIN case_status cs on c.status = cs.value and cs.type = 'account'
LEFT JOIN campuses cp on c.campus_id = cp.id
LEFT JOIN invoices i on c.invoice_month = i.inv_month and c.invoice_year = i.inv_year
LEFT JOIN demographics d on c.enrollee_id = d.id
WHERE (FIND_IN_SET(c.status, '",AcctStatus,"') != 0 OR '",AcctStatus,"' < 0) AND
      (c.invoice_month = '",InvoiceMonth,"' OR '",InvoiceMonth,"' < 0) AND
      (c.invoice_year = '",InvoiceYear,"' OR '",InvoiceYear,"' < 0) AND
       d.verified != 0 AND
       d.is_archive = 0");

PREPARE stmt FROM @sql;
EXECUTE stmt;
      
END$$
DELIMITER ;