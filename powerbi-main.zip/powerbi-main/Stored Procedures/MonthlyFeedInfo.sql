DROP PROCEDURE IF EXISTS MonthlyFeedInfo;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `MonthlyFeedInfo`()

BEGIN
SET @EncKey = EncKey();

select a.value as 'ADF'
into 
@Admit_Date_Format
from setting a
where a.setting_key = 'Admit_Date_Format';

SET @sql = NULL;
SET @sql = CONCAT("
SELECT Region
,Hospital
,Campus
,case_id as CaseID
,MRN
,charges_ref_number as AcctNumber               
,adm_date as AdmitDate          
,Total_Acc_Bal as Charges                
                  FROM (
select c.case_id
,s.value as 'Hospital'
,r.value as 'Region'
,AES_DECRYPT(c.charges_ref_number,'",@EncKey,"') as charges_ref_number
,AES_DECRYPT(c.Total_Acc_Bal,'",@EncKey,"') as Total_Acc_Bal              
,DATE_FORMAT(STR_TO_DATE(c.admit_date,'",@Admit_Date_Format,"'),'%Y-%m-%d') as adm_date
,ROW_NUMBER () OVER(PARTITION BY AES_DECRYPT(c.charges_ref_number,'",@EncKey,"') ORDER BY c.created_at desc) as rownum
,AES_DECRYPT(d.MRN,'",@EncKey,"') as MRN
,IFNULL(cp.campus_alias, cp.campus_name) as Campus
from charges c
LEFT JOIN setting s on s.setting_key = 'HOSPITAL_NAME'
LEFT JOIN setting r on r.setting_key = 'REGION'
LEFT JOIN campuses cp on c.campus_id = cp.id
LEFT JOIN demographics d on c.case_id = d.id
where DATE_FORMAT(STR_TO_DATE(c.admit_date,'",@Admit_Date_Format,"'),'%Y-%m-%d') between '2025-05-01' and '2025-05-31') as InnerTable
WHERE InnerTable.rownum = 1
");

PREPARE stmt FROM @sql;
EXECUTE stmt;
END$$    
DELIMITER ;