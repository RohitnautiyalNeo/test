DROP PROCEDURE IF EXISTS CATS_TransactionFile;

DELIMITER $$
CREATE PROCEDURE `CATS_TransactionFile`(IN `Type` INT)
BEGIN

SET @EncKey = EncKey();
SET SESSION group_concat_max_len = 1000000;

SET @sql = NULL;
SET @sql = CONCAT("
                  
SELECT m.case_id
,m.case_group
,IFNULL(IFNULL(cp2.campus_alias,cp2.campus_name),cp.campus_alias) as Campus
,AES_DECRYPT(d.MRN,'",@EncKey,"') as MRN
,AES_DECRYPT(c.charges_ref_number,'",@EncKey,"') as AcctNumber
,AES_DECRYPT(c.Total_Acc_Bal,'",@EncKey,"') as Total_Acc_Bal
,c.admit_date
,c.discharge_date
,c.created_at
FROM MovedBillingCases m 
LEFT JOIN demographics d on m.case_group = d.case_group
LEFT JOIN campuses cp on d.campus = cp.id
LEFT JOIN charges c on d.id = c.case_id AND 
                       c.id in (SELECT MAX(c2.id)
                                FROM charges c2
                                WHERE AES_DECRYPT(c2.Total_Acc_Bal,'",@EncKey,"') IS NOT NULL
                                AND c.case_id = c2.case_id 
                                GROUP BY c.case_id, AES_DECRYPT(c.charges_ref_number,'",@EncKey,"')
                                )
LEFT JOIN campuses cp2 on c.campus_id = cp2.id
WHERE AES_DECRYPT(c.charges_ref_number,'",@EncKey,"') IS NOT NULL
AND AES_DECRYPT(c.Total_Acc_Bal,'",@EncKey,"') IS NOT NULL ",
CASE
     WHEN Type = '1' THEN "AND DATE_FORMAT(FROM_UNIXTIME(c.created_at),"'"%Y-%m-%d"'") = DATE_SUB(CURDATE(), INTERVAL 1 DAY)"
     ELSE ""
END,"              
ORDER BY case_id");

PREPARE stmt FROM @sql;
EXECUTE stmt;
      
END$$
DELIMITER ;