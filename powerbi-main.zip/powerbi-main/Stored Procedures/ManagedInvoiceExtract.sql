DROP PROCEDURE IF EXISTS ManagedInvoiceExtract;

DELIMITER $$
CREATE PROCEDURE `ManagedInvoiceExtract`(
IN `AcctStatus` VARCHAR(255), 
IN `InvoiceMonth` INT, 
IN `InvoiceYear` INT, 
IN `GroupID` INT,
IN `CaseID` INT,
IN `DateFrom` VARCHAR(255), 
IN `DateThru` VARCHAR(255), 
IN `ChargeType` VARCHAR(255), 
IN `ChargeAmount` VARCHAR(255), 
IN `CommExpectedType` VARCHAR(255), 
IN `CommExpectedAmount` VARCHAR(255), 
IN `ContingencyType` VARCHAR(255), 
IN `ContingencyAmount` VARCHAR(255), 
IN `AdmitFrom` VARCHAR(255), 
IN `AdmitThru` VARCHAR(255), 
IN `VerifFrom` VARCHAR(255), 
IN `VerifThru` VARCHAR(255), 
IN `DRGType` VARCHAR(255), 
IN `DRGAmount` VARCHAR(255), 
IN `IORS` VARCHAR(255), 
IN `ClaimCat` VARCHAR(255), 
IN `ClaimSubCat` VARCHAR(255), 
IN `CommPaymentType` VARCHAR(255), 
IN `CommPaymentAmount` VARCHAR(255), 
IN `MCDExpectedType` VARCHAR(255), 
IN `MCDExpectedAmount` VARCHAR(255), 
IN `NetRevType` VARCHAR(255), 
IN `NetRevAmount` VARCHAR(255), 
IN `DischargeFrom` VARCHAR(255), 
IN `DischargeThru` VARCHAR(255), 
IN `PaidFrom` VARCHAR(255), 
IN `PaidThru` VARCHAR(255), 
IN `PRType` VARCHAR(255), 
IN `PRAmount` VARCHAR(255), 
IN `FlagType` VARCHAR(255), 
IN `FlagCategory` VARCHAR(255), 
IN `FlagSubCategory` VARCHAR(255), 
IN `AlreadyEnrolled` VARCHAR(255), 
IN `HospOnFile` VARCHAR(255),
IN `BalType` VARCHAR(255), 
IN `BalAmount` VARCHAR(255),
IN `ServiceType` VARCHAR(255), 
IN `Campus` VARCHAR(255),
IN `InvoiceQuarter` VARCHAR(255),
IN `CaseOwner` VARCHAR(255),
IN `Appealed` VARCHAR(255),
IN `SubmitFrom` VARCHAR(255), 
IN `SubmitThru` VARCHAR(255), 
IN `InvPaidFrom` VARCHAR(255), 
IN `InvPaidThru` VARCHAR(255), 
IN `ApprovalFrom` VARCHAR(255), 
IN `ApprovalThru` VARCHAR(255), 
IN `SignatureFrom` VARCHAR(255), 
IN `SignatureThru` VARCHAR(255), 
IN `ARDaysType` VARCHAR(255), 
IN `ARDaysAmount` VARCHAR(255))

BEGIN

SET @EncKey = CATSEncKey();

With Secondary_Ins as (
SELECT cv.group_id
,cv.payor
,cv.id
,cv.plan
,ROW_NUMBER () OVER(PARTITION BY cv.group_id ORDER BY cv.id DESC) as rownum
FROM coverages cv
WHERE cv.level = 'secondary'
and cv.plan != ''
),

Flags_Grouped as (
select enrollee_id
,GROUP_CONCAT(f.name SEPARATOR '//') as category
,GROUP_CONCAT(f2.name SEPARATOR '//') as subcategory
from assigned_flags a
left join flag_category f on a.flag_type = f.type and a.category = f.id
left join flag_category f2 on a.flag_type = f2.type and a.subcategory = f2.id
group by enrollee_id
),

PT_Notes_Grouped as (
select acct_id
,GROUP_CONCAT(AES_DECRYPT(note,@EncKey) SEPARATOR '//') as notes
from notes n
where note_type = 'account'
group by acct_id
),

FM_Notes_Grouped as (
select group_id
,GROUP_CONCAT(AES_DECRYPT(note,@EncKey) SEPARATOR '//') as notes
from notes n
where note_type = 'family'
group by group_id
),

DemoCat as (
SELECT *
,ROW_NUMBER () OVER(PARTITION BY case_id ORDER BY id desc) as rownum
FROM demographics_category dc
)

SELECT *
FROM (
SELECT inv_number as INVOICE_NUMBER
,IF(c.invoice_year=0,'',c.invoice_year) as INVOICE_YEAR
,IF(c.invoice_month=0,'',c.invoice_month) as INVOICE_MONTH
,i.inv_quarter as INVOICE_QUARTER
,inv_submit_date AS INVOICE_SUBMIT_DATE
,inv_paid_date AS INVOICE_PAID_DATE
,DATEDIFF(STR_TO_DATE(inv_paid_date,'%m/%d/%Y'),STR_TO_DATE(inv_submit_date,'%m/%d/%Y')) as 'Days for PFA to Get Paid from Invoice Submit Date'
,hospital.value as 'Hospital System'
,cp.campus_name as Campus
,CONCAT(AES_DECRYPT(d.LastName,@EncKey),', ',AES_DECRYPT(d.FirstName,@EncKey)) as NAME
,AES_DECRYPT(d.MRN,@EncKey) as MRN
,AES_DECRYPT(c.AcctNumber,@EncKey) AS 'ACCOUNT#'
,IF(c.Admit_Date = '0000-00-00',NULL,c.Admit_Date) AS 'ADMIT DATE'
,c.Discharge_Date as 'DISCHARGE DATE'
,st.name as 'SERVICE TYPE'
,REPLACE(c.Charges,',','') as 'TOTAL CHARGES'
,cd.effective_date as 'INSURANCE EFFECTIVE DATE'
,PickCoverage(c.id) as 'PRIMARY_INS'
,IF(si.plan='0','MEDICAID',si.plan) as 'SECONDARY_INS'
,c.Comm_expected as 'COMMERCIAL EXPECTED'	
,c.Comm_payment as 'COMMERCIAL PAYMENT'
,c.Mcd_expacted as 'MEDICAID EXPECTED'
,c.difference as 'DIFFERENCE'
,c.pfa_contingency as 'PFA CONTINGENCY'
,c.net_revenue as 'HOSPITAL NET REVENUE'
,c.i_or_s as 'I OR S'
,cd.verif_date as 'VERIF/EMAIL DATE'
,c.claim_date as 'CLAIM PAID DATE'
,pt.name as 'PATIENT TYPE'
,c.pr as 'PR'
,c.drg as 'MS DRG'
,apr_drg as 'APR DRG'
,ts_drg as 'TR DRG'
,n.notes as 'NOTES'
,c.hospital_notes as 'HOSPITAL NOTES'
,c.Comm_payment / c.Charges as 'Commercial PAF'
,c.Mcd_expacted / c.Charges as 'Medicaid PAF'
,(c.Comm_payment / c.Charges) - (c.Mcd_expacted / c.Charges) as 'PAF Delta'
,CASE
	WHEN REPLACE(c.pfa_contingency,',','') < 0 THEN 'N/A'
	WHEN STR_TO_DATE(cd.verif_date,'%m/%d/%Y') < STR_TO_DATE(c.Discharge_Date,'%m/%d/%Y') AND
         c.claim_date != 0 AND
         DATEDIFF(STR_TO_DATE(c.claim_date,'%m/%d/%Y'),STR_TO_DATE(c.Discharge_Date,'%m/%d/%Y')) >= 0 THEN
         DATEDIFF(STR_TO_DATE(c.claim_date,'%m/%d/%Y'),STR_TO_DATE(c.Discharge_Date,'%m/%d/%Y'))
	WHEN STR_TO_DATE(cd.verif_date,'%m/%d/%Y') >= STR_TO_DATE(c.Discharge_Date,'%m/%d/%Y') AND
	     c.claim_date != 0 AND
	     DATEDIFF(STR_TO_DATE(c.claim_date,'%m/%d/%Y'),STR_TO_DATE(cd.verif_date,'%m/%d/%Y')) >= 0 THEN
         DATEDIFF(STR_TO_DATE(c.claim_date,'%m/%d/%Y'),STR_TO_DATE(cd.verif_date,'%m/%d/%Y'))
	ELSE 'N/A'
END as 'AR DAYS OUTSTANDING'
,c.bal as BAL
,cs.status as 'FINAL DISP'
,LEFT(d.case_id,LOCATE('-',d.case_id) - 1) as RVCase
from charges c
LEFT JOIN campuses cp on c.campus_id = cp.id
LEFT JOIN case_status cs on c.status = cs.value and cs.type = 'account'
LEFT JOIN setting hospital on hospital.setting_key = 'HOSPITAL_NAME'
LEFT JOIN demographics d on c.enrollee_id = d.id
LEFT JOIN Flags_Grouped f on d.id = f.enrollee_id
LEFT JOIN PT_Notes_Grouped n on c.id = n.acct_id
LEFT JOIN FM_Notes_Grouped n2 on d.case_group = n2.group_id
LEFT JOIN svc_types st on c.type = st.id
LEFT JOIN invoices i on c.invoiced_id = i.id
LEFT JOIN coverages_details cd on c.enrollee_id = cd.case_id and cd.coverage_id = PickCoverageID(c.id)
LEFT JOIN coverage_payors p on cd.payor_id = p.id
LEFT JOIN Secondary_Ins si on si.group_id = d.case_group AND si.rownum = 1
LEFT JOIN coverage_payors p3 on si.payor = p3.id
LEFT JOIN coverages_details cd2 on si.id = cd2.coverage_id
LEFT JOIN DemoCat dc on d.id = dc.case_id and dc.rownum = 1
LEFT JOIN patient_types pt on dc.category_id = pt.id
LEFT JOIN assigned_flags af on af.enrollee_id = c.enrollee_id and af.flag_type = FlagType and af.category = FlagCategory
LEFT JOIN assigned_flags af2 on af2.enrollee_id = c.enrollee_id and af2.flag_type = FlagType and af2.subcategory = FlagSubCategory
WHERE (FIND_IN_SET(c.status, AcctStatus) != 0 OR AcctStatus < 0) AND
      (c.invoice_month = InvoiceMonth OR InvoiceMonth < 0) AND
      (c.invoice_year = InvoiceYear OR InvoiceYear < 0) AND
      (i.inv_quarter = InvoiceQuarter OR InvoiceQuarter < 0) AND     
      (d.case_group = GroupID OR GroupID < 0) AND
      (FIND_IN_SET(cp.id, Campus) != 0 OR Campus < 0) AND
      (FIND_IN_SET(c.type, ServiceType) != 0 OR ServiceType < 0) AND
      (d.id = CaseID OR CaseID < 0) AND
      (c.created >= (UNIX_TIMESTAMP(STR_TO_DATE(DateFrom,'%m/%d/%Y'))) OR DateFrom < 0) AND
      (c.created <= (UNIX_TIMESTAMP(STR_TO_DATE(DateThru,'%m/%d/%Y'))) OR DateThru < 0) AND
      (FIND_IN_SET(REPLACE(f.category,'//',','), ClaimCat) != 0 OR ClaimCat < 0) AND    
      (FIND_IN_SET(REPLACE(f.subcategory,'//',','), ClaimSubCat) != 0 OR ClaimSubCat < 0) AND
      (af.category = FlagCategory OR FlagCategory < 0) AND
      (af2.subcategory = FlagSubCategory OR FlagSubCategory < 0) AND
      (c.i_or_s = IORS OR IORS < 0) AND
      (d.case_owner = CaseOwner OR CaseOwner < 0) AND
      (c.appealed = Appealed OR Appealed < 0) AND
      (CASE
           WHEN ChargeType = 1 THEN CAST(REPLACE(c.Charges,',','') as DECIMAL(12,2)) = ChargeAmount
           WHEN ChargeType = 2 THEN CAST(REPLACE(c.Charges,',','') as DECIMAL(12,2)) > ChargeAmount
           WHEN ChargeType = 3 THEN CAST(REPLACE(c.Charges,',','') as DECIMAL(12,2)) >= ChargeAmount
           WHEN ChargeType = 4 THEN CAST(REPLACE(c.Charges,',','') as DECIMAL(12,2)) < ChargeAmount
           WHEN ChargeType = 5 THEN CAST(REPLACE(c.Charges,',','') as DECIMAL(12,2)) <= ChargeAmount     
           WHEN ChargeType = 6 THEN CAST(REPLACE(c.Charges,',','') as DECIMAL(12,2)) BETWEEN REPLACE(SUBSTRING_INDEX(ChargeAmount, '-', 1),',','') AND 
                                                                                                   REPLACE(SUBSTRING_INDEX(ChargeAmount, '-', -1),',','')       
       END OR ChargeType < 0) AND 
      (CASE
           WHEN BalType = 1 THEN CAST(REPLACE(c.bal,',','') as DECIMAL(12,2)) = BalAmount
           WHEN BalType = 2 THEN CAST(REPLACE(c.bal,',','') as DECIMAL(12,2)) > BalAmount
           WHEN BalType = 3 THEN CAST(REPLACE(c.bal,',','') as DECIMAL(12,2)) >= BalAmount
           WHEN BalType = 4 THEN CAST(REPLACE(c.bal,',','') as DECIMAL(12,2)) < BalAmount
           WHEN BalType = 5 THEN CAST(REPLACE(c.bal,',','') as DECIMAL(12,2)) <= BalAmount     
           WHEN BalType = 6 THEN CAST(REPLACE(c.bal,',','') as DECIMAL(12,2)) BETWEEN REPLACE(SUBSTRING_INDEX(BalAmount, '-', 1),',','') AND 
                                                                                                   REPLACE(SUBSTRING_INDEX(BalAmount, '-', -1),',','')       
       END OR BalType < 0) AND 
      (CASE
           WHEN CommExpectedType = 1 THEN CAST(REPLACE(c.Comm_expected,',','') as DECIMAL(12,2)) = CommExpectedAmount
           WHEN CommExpectedType = 2 THEN CAST(REPLACE(c.Comm_expected,',','') as DECIMAL(12,2)) > CommExpectedAmount
           WHEN CommExpectedType = 3 THEN CAST(REPLACE(c.Comm_expected,',','') as DECIMAL(12,2)) >= CommExpectedAmount
           WHEN CommExpectedType = 4 THEN CAST(REPLACE(c.Comm_expected,',','') as DECIMAL(12,2)) < CommExpectedAmount
           WHEN CommExpectedType = 5 THEN CAST(REPLACE(c.Comm_expected,',','') as DECIMAL(12,2)) <= CommExpectedAmount     
           WHEN CommExpectedType = 6 THEN CAST(REPLACE(c.Comm_expected,',','') as DECIMAL(12,2)) BETWEEN REPLACE(SUBSTRING_INDEX(CommExpectedAmount, '-', 1),',','') AND 
                                                                                                               REPLACE(SUBSTRING_INDEX(CommExpectedAmount, '-', -1),',','')       
       END OR CommExpectedType < 0) AND 
      (CASE
           WHEN ContingencyType = 1 THEN CAST(REPLACE(c.pfa_contingency,',','') as DECIMAL(12,2)) = ContingencyAmount
           WHEN ContingencyType = 2 THEN CAST(REPLACE(c.pfa_contingency,',','') as DECIMAL(12,2)) > ContingencyAmount
           WHEN ContingencyType = 3 THEN CAST(REPLACE(c.pfa_contingency,',','') as DECIMAL(12,2)) >= ContingencyAmount
           WHEN ContingencyType = 4 THEN CAST(REPLACE(c.pfa_contingency,',','') as DECIMAL(12,2)) < ContingencyAmount
           WHEN ContingencyType = 5 THEN CAST(REPLACE(c.pfa_contingency,',','') as DECIMAL(12,2)) <= ContingencyAmount     
           WHEN ContingencyType = 6 THEN CAST(REPLACE(c.pfa_contingency,',','') as DECIMAL(12,2)) BETWEEN REPLACE(SUBSTRING_INDEX(ContingencyAmount, '-', 1),',','') AND 
                                                                                                                REPLACE(SUBSTRING_INDEX(ContingencyAmount, '-', -1),',','')       
       END OR ContingencyType < 0) AND 
      (CASE
           WHEN DRGType = 1 THEN CAST(REPLACE(c.drg,',','') as DECIMAL(12,2)) = DRGAmount
           WHEN DRGType = 2 THEN CAST(REPLACE(c.drg,',','') as DECIMAL(12,2)) > DRGAmount
           WHEN DRGType = 3 THEN CAST(REPLACE(c.drg,',','') as DECIMAL(12,2)) >= DRGAmount
           WHEN DRGType = 4 THEN CAST(REPLACE(c.drg,',','') as DECIMAL(12,2)) < DRGAmount
           WHEN DRGType = 5 THEN CAST(REPLACE(c.drg,',','') as DECIMAL(12,2)) <= DRGAmount     
           WHEN DRGType = 6 THEN CAST(REPLACE(c.drg,',','') as DECIMAL(12,2)) BETWEEN REPLACE(SUBSTRING_INDEX(DRGAmount, '-', 1),',','') AND 
                                                                                            REPLACE(SUBSTRING_INDEX(DRGAmount, '-', -1),',','')       
       END OR DRGType < 0) AND 
      (CASE
           WHEN CommPaymentType = 1 THEN CAST(REPLACE(c.Comm_payment,',','') as DECIMAL(12,2)) = CommPaymentAmount
           WHEN CommPaymentType = 2 THEN CAST(REPLACE(c.Comm_payment,',','') as DECIMAL(12,2)) > CommPaymentAmount
           WHEN CommPaymentType = 3 THEN CAST(REPLACE(c.Comm_payment,',','') as DECIMAL(12,2)) >= CommPaymentAmount
           WHEN CommPaymentType = 4 THEN CAST(REPLACE(c.Comm_payment,',','') as DECIMAL(12,2)) < CommPaymentAmount
           WHEN CommPaymentType = 5 THEN CAST(REPLACE(c.Comm_payment,',','') as DECIMAL(12,2)) <= CommPaymentAmount     
           WHEN CommPaymentType = 6 THEN CAST(REPLACE(c.Comm_payment,',','') as DECIMAL(12,2)) BETWEEN REPLACE(SUBSTRING_INDEX(CommPaymentAmount, '-', 1),',','') AND 
                                                                                            REPLACE(SUBSTRING_INDEX(CommPaymentAmount, '-', -1),',','')       
       END OR CommPaymentType < 0) AND 
      (CASE
           WHEN MCDExpectedType = 1 THEN CAST(REPLACE(c.Mcd_expacted,',','') as DECIMAL(12,2)) = MCDExpectedAmount
           WHEN MCDExpectedType = 2 THEN CAST(REPLACE(c.Mcd_expacted,',','') as DECIMAL(12,2)) > MCDExpectedAmount
           WHEN MCDExpectedType = 3 THEN CAST(REPLACE(c.Mcd_expacted,',','') as DECIMAL(12,2)) >= MCDExpectedAmount
           WHEN MCDExpectedType = 4 THEN CAST(REPLACE(c.Mcd_expacted,',','') as DECIMAL(12,2)) < MCDExpectedAmount
           WHEN MCDExpectedType = 5 THEN CAST(REPLACE(c.Mcd_expacted,',','') as DECIMAL(12,2)) <= MCDExpectedAmount     
           WHEN MCDExpectedType = 6 THEN CAST(REPLACE(c.Mcd_expacted,',','') as DECIMAL(12,2)) BETWEEN REPLACE(SUBSTRING_INDEX(MCDExpectedAmount, '-', 1),',','') AND 
                                                                                                             REPLACE(SUBSTRING_INDEX(MCDExpectedAmount, '-', -1),',','')       
       END OR MCDExpectedType < 0) AND 
      (CASE
           WHEN NetRevType = 1 THEN CAST(REPLACE(c.net_revenue,',','') as DECIMAL(12,2)) = NetRevAmount
           WHEN NetRevType = 2 THEN CAST(REPLACE(c.net_revenue,',','') as DECIMAL(12,2)) > NetRevAmount
           WHEN NetRevType = 3 THEN CAST(REPLACE(c.net_revenue,',','') as DECIMAL(12,2)) >= NetRevAmount
           WHEN NetRevType = 4 THEN CAST(REPLACE(c.net_revenue,',','') as DECIMAL(12,2)) < NetRevAmount
           WHEN NetRevType = 5 THEN CAST(REPLACE(c.net_revenue,',','') as DECIMAL(12,2)) <= NetRevAmount     
           WHEN NetRevType = 6 THEN CAST(REPLACE(c.net_revenue,',','') as DECIMAL(12,2)) BETWEEN REPLACE(SUBSTRING_INDEX(NetRevAmount, '-', 1),',','') AND 
                                                                                                       REPLACE(SUBSTRING_INDEX(NetRevAmount, '-', -1),',','')       
       END OR NetRevType < 0) AND 
      (CASE
           WHEN PRType = 1 THEN CAST(REPLACE(c.pr,',','') as DECIMAL(12,2)) = PRAmount
           WHEN PRType = 2 THEN CAST(REPLACE(c.pr,',','') as DECIMAL(12,2)) > PRAmount
           WHEN PRType = 3 THEN CAST(REPLACE(c.pr,',','') as DECIMAL(12,2)) >= PRAmount
           WHEN PRType = 4 THEN CAST(REPLACE(c.pr,',','') as DECIMAL(12,2)) < PRAmount
           WHEN PRType = 5 THEN CAST(REPLACE(c.pr,',','') as DECIMAL(12,2)) <= PRAmount     
           WHEN PRType = 6 THEN CAST(REPLACE(c.pr,',','') as DECIMAL(12,2)) BETWEEN REPLACE(SUBSTRING_INDEX(PRAmount, '-', 1),',','') AND 
                                                                                          REPLACE(SUBSTRING_INDEX(PRAmount, '-', -1),',','')       
       END OR PRType < 0) AND
      (CASE
           WHEN AlreadyEnrolled = 1 THEN cd.ae_enrolled = 1
           WHEN AlreadyEnrolled = 2 THEN cd.ae_enrolled = 0
           WHEN AlreadyEnrolled = 3 THEN (cd.ae_enrolled != 1 OR cd.hospital_has_on_file != 1)
       END OR AlreadyEnrolled < 0) AND 
       
      (CASE
           WHEN HospOnFile = 1 THEN cd.hospital_has_on_file=1
           WHEN HospOnFile = 2 THEN cd.hospital_has_on_file=0
       END OR HospOnFile < 0) AND 
      ((STR_TO_DATE(c.Admit_Date,'%m/%d/%Y') >= STR_TO_DATE(IF(AdmitFrom = -1,'01/01/1999',AdmitFrom),'%m/%d/%Y')) OR AdmitFrom < 0) AND
      ((STR_TO_DATE(c.Admit_Date,'%m/%d/%Y') <= STR_TO_DATE(IF(AdmitThru = -1,'01/01/2999',AdmitThru),'%m/%d/%Y')) OR AdmitThru < 0) AND
      ((STR_TO_DATE(c.Discharge_Date,'%m/%d/%Y') >= STR_TO_DATE(IF(DischargeFrom = -1,'01/01/1999',DischargeFrom),'%m/%d/%Y')) OR DischargeFrom < 0) AND
      ((STR_TO_DATE(c.Discharge_Date,'%m/%d/%Y') <= STR_TO_DATE(IF(DischargeThru = -1,'01/01/2999',DischargeThru),'%m/%d/%Y')) OR DischargeThru < 0) AND
      ((STR_TO_DATE(cd.verif_date,'%m/%d/%Y') >= STR_TO_DATE(IF(VerifFrom = -1,'01/01/1999',VerifFrom),'%m/%d/%Y')) OR VerifFrom < 0) AND
      ((STR_TO_DATE(cd.verif_date,'%m/%d/%Y') <= STR_TO_DATE(IF(VerifThru = -1,'01/01/2999',VerifThru),'%m/%d/%Y')) OR VerifThru < 0) AND
      ((STR_TO_DATE(c.claim_date,'%m/%d/%Y') >= STR_TO_DATE(IF(PaidFrom = -1,'01/01/1999',PaidFrom),'%m/%d/%Y')) OR PaidFrom < 0) AND
      ((STR_TO_DATE(c.claim_date,'%m/%d/%Y') <= STR_TO_DATE(IF(PaidThru = -1,'01/01/2999',PaidThru),'%m/%d/%Y')) OR PaidThru < 0) AND
      ((STR_TO_DATE(inv_submit_date,'%m/%d/%Y') >= STR_TO_DATE(IF(SubmitFrom = -1,'01/01/1999',SubmitFrom),'%m/%d/%Y')) OR SubmitFrom < 0) AND
      ((STR_TO_DATE(inv_submit_date,'%m/%d/%Y') <= STR_TO_DATE(IF(SubmitThru = -1,'01/01/2999',SubmitThru),'%m/%d/%Y')) OR SubmitThru < 0) AND
      ((STR_TO_DATE(inv_paid_date,'%m/%d/%Y') >= STR_TO_DATE(IF(InvPaidFrom = -1,'01/01/1999',InvPaidFrom),'%m/%d/%Y')) OR InvPaidFrom < 0) AND
      ((STR_TO_DATE(inv_paid_date,'%m/%d/%Y') <= STR_TO_DATE(IF(InvPaidThru = -1,'01/01/2999',InvPaidThru),'%m/%d/%Y')) OR InvPaidThru < 0) AND
      ((STR_TO_DATE(d.approval_date,'%m/%d/%Y') >= STR_TO_DATE(IF(ApprovalFrom = -1,'01/01/1999',ApprovalFrom),'%m/%d/%Y')) OR ApprovalFrom < 0) AND
      ((STR_TO_DATE(d.approval_date,'%m/%d/%Y') <= STR_TO_DATE(IF(ApprovalThru = -1,'01/01/2999',ApprovalThru),'%m/%d/%Y')) OR ApprovalThru < 0) AND
      ((STR_TO_DATE(d.signature_date,'%m/%d/%Y') >= STR_TO_DATE(IF(SignatureFrom = -1,'01/01/1999',SignatureFrom),'%m/%d/%Y')) OR SignatureFrom < 0) AND
      ((STR_TO_DATE(d.signature_date,'%m/%d/%Y') <= STR_TO_DATE(IF(SignatureThru = -1,'01/01/2999',SignatureThru),'%m/%d/%Y')) OR SignatureThru < 0) AND
d.is_archive = 0 AND
cs.status not in ('Invoice–pending','Outstanding') AND
cs.type != 'family') as InnerTable
WHERE (CASE
           WHEN ARDaysType = 1 THEN `AR DAYS OUTSTANDING` = ARDaysAmount
           WHEN ARDaysType = 2 THEN `AR DAYS OUTSTANDING` > ARDaysAmount
           WHEN ARDaysType = 3 THEN `AR DAYS OUTSTANDING` >= ARDaysAmount
           WHEN ARDaysType = 4 THEN `AR DAYS OUTSTANDING` < ARDaysAmount
           WHEN ARDaysType = 5 THEN `AR DAYS OUTSTANDING` <= ARDaysAmount     
           WHEN ARDaysType = 6 THEN `AR DAYS OUTSTANDING` BETWEEN REPLACE(SUBSTRING_INDEX(ARDaysAmount, '-', 1),',','') AND 
                                                                  REPLACE(SUBSTRING_INDEX(ARDaysAmount, '-', -1),',','')
       END OR ARDaysType < 0);
END$$
DELIMITER ;