DROP PROCEDURE IF EXISTS SignatureApproval_Dash;

DELIMITER $$    
CREATE PROCEDURE SignatureApproval_Dash()
BEGIN

SET @EncKey = EncKey();
SET SESSION group_concat_max_len = 1000000;     
 
 SELECT setting.value
 ,format.value 
 into 
 @Admit_DT
 ,@Admit_DT_Format
 from setting 
 left join setting format on format.setting_key = 'ADMIT_DATE_FORMAT'
 where setting.setting_key = 'ADMIT_DATE_FIELD';
 
 SET @sql = NULL;
 SET @sql = CONCAT("
 
 With Cohort as (
 select distinct IFNULL(d.id,s.case_id) as case_id
 ,s.user_id
 ,FROM_UNIXTIME(s.created,"'"%Y-%m-%d"'") as created
 ,LAST_DAY(FROM_UNIXTIME(s.created,"'"%Y-%m-%d"'")) as LDOM
 ,DATE_SUB(FROM_UNIXTIME(s.created,"'"%Y-%m-%d"'"), INTERVAL 60 DAY) as SixtyPrior
 ,AES_DECRYPT(d.MRN,'",@EncKey,"')
 ,concat(setting.value,'.',s.case_group_id) as SignatureID
 ,o.type AS OutreachType
 ,cs.status
 from (select * 
       from signatures 
       group by IF(case_group_id is NULL 
                   OR case_group_id='', CONCAT('CG- ',case_id), case_group_id)) as s
 LEFT JOIN demographics d on s.case_group_id = d.case_group
 LEFT JOIN setting on setting_key = 'HOSPITAL_NAME'
 LEFT JOIN outreach_type o on s.outreach_type = o.type_id
 LEFT JOIN case_status cs on d.case_status = cs.value
 where user_id IS NOT NULL 
 and user_id IN (select id 
 				from admin_user 
 				where user_type !=1 
 				and username not in ('shivam_support','revmax_superadmin','amit_support')
 				)
 and s.case_id NOT IN(select id from demographics where AES_DECRYPT(MRN,'",@EncKey,"') LIKE '0-%')
 ),
 
Approvals AS (
  SELECT t.case_id,
         t.created,
         d.case_owner,
         d.MRN,
         c.status
  FROM ( SELECT *
    FROM track_case t
    WHERE t.archive_status = 0
      AND t.id = (
        SELECT MIN(t2.id)
        FROM track_case t2
        WHERE t.case_id = t2.case_id
          AND t.status = t2.status
          AND t2.archive_status = 0 )) t
LEFT JOIN demographics d on t.case_id = d.id
LEFT JOIN case_status c on t.status = c.value
WHERE c.status = 'Application Approved'
AND AES_DECRYPT(d.MRN,'",@EncKey,"') != "'"0-"'"

UNION ALL

SELECT n.case_id
,ROUND(UNIX_TIMESTAMP(NoteDate),0)
,d.case_owner
,d.MRN
,cs.status
FROM notes n
INNER JOIN note_type nt on n.note_type = nt.type_id and nt.type = 'Approval'
LEFT JOIN demographics d on n.case_id = d.id
LEFT JOIN case_status cs on d.case_status = cs.value
),                    

CaseDetailsRanks as (
SELECT case_id
,CASE
     WHEN not_invoicing_patient = 0 THEN 'Yes'
     ELSE 'No'
END as Invoicing
,esi_verification_date
,sum(charges) as charges
,ROW_NUMBER () OVER(PARTITION BY case_id ORDER BY data_from ASC, id DESC) as rownum
FROM case_verification_details
group by case_id,data_from
),                   
                   
Orphans as (
SELECT a.case_id
,NULL as user_id
,NULL as created
,NULL as LDOM
,NULL as SixtyPrior
,AES_DECRYPT(a.MRN,'",@EncKey,"') as MRN
,NULL as SignatureID
,NULL as OutreachType
,a.status                
FROM Approvals a
LEFT JOIN CaseDetailsRanks c on a.case_id = c.case_id
LEFT JOIN admin_user au on a.case_owner = au.id
WHERE au.name IS NULL
AND c.charges > 0
),
                   
JoinedCohort as (
SELECT *
FROM Cohort

UNION ALL

SELECT *
FROM Orphans
),

EmployerRank as (
SELECT e.*
,ROW_NUMBER () OVER(PARTITION BY case_id ORDER BY created asc) as rownum
FROM employers_tab e
), 
                      
 Total_Charges as (
 SELECT case_id
 ,SUM(CAST(replace(replace(AES_DECRYPT(Total_Acc_Bal,'",@EncKey,"'),'$',''),',','') as decimal(10,2))) as TotalCharges
 ,MAX(created_at) as created_at_max 
 ,MAX(STR_to_date(admit_date,'",@Admit_DT_Format,"')) as ADMIT_DATE
 ,MAX(STR_to_date(discharge_date,'",@Admit_DT_Format,"')) as DISCHARGE_DATE
 FROM charges 
 WHERE id IN(
 			SELECT max(id) as id 
 			FROM charges 
 			WHERE AES_DECRYPT(Total_Acc_Bal,'",@EncKey,"') IS NOT NULL
 			GROUP BY case_id,AES_DECRYPT(charges_ref_number,'",@EncKey,"'))
 GROUP BY case_id
 )
 
 SELECT rvp.value as 'RVP'
 ,hospital.value as 'Hospital'
 ,region.value as 'Region'
 ,CASE
 	WHEN dcn.category_id = 1 THEN 'NICU'
 	WHEN dcn.category_id = 2 THEN 'PICU'
 	ELSE 'ADULT'
 END as CaseCategory
 ,CONCAT(s.case_id,'.',hospital.value) as case_id
 ,s.SignatureID
 ,CAST(AES_DECRYPT(a.name,'",@EncKey,"') as CHAR) as PatientHelper
 ,s.created as SignatureDate
 ,IFNULL(t.TotalCharges,0) as GrownTotalCharges
 #,IFNULL(c.TotalCharges,0) as TotalCharges
 #,IFNULL(sc.TotalCharges,0) as SixtyPriorCharges
 ,d.max_case_rank as CaseRank
 ,region.value as 'Region'
 ,cp.campus_name as campus
 ,t.admit_date
 ,t.discharge_date
 ,DATE_FORMAT(d.date_add,'%Y-%m-%d') as FeedDate
 ,s.OutreachType
 ,IFNULL(s.status,'Purged') as CurrentBucket
 ,d.case_group
 ,AES_DECRYPT(d.MRN,'",@EncKey,"') as MRN
 ,IFNULL(REPLACE(o8.field_value,'amp;',''),AES_DECRYPT(EmpName,'",@EncKey,"')) as 'Employer'
 from JoinedCohort s
 LEFT JOIN demographics d on s.case_id = d.id
 LEFT JOIN campuses cp on d.campus = cp.id
 LEFT JOIN admin_user a on s.user_id = a.id
 LEFT JOIN Total_Charges t on s.case_id = t.case_id
 LEFT JOIN setting hospital on hospital.setting_key = 'HOSPITAL_NAME'
 LEFT JOIN setting rvp on rvp.setting_key = 'RVP_NAME'
 LEFT JOIN setting region on region.setting_key ='REGION'
 LEFT JOIN (select * from demographics_category group by case_id) dcn on  dcn.case_id = s.case_id
 LEFT JOIN case_enrollment_details_current o8 on d.id = o8.case_id and o8.field_type = 'employer' and o8.field_key = 'NAME' and o8.is_deleted = 0
 LEFT JOIN EmployerRank et on d.id = et.case_id and et.rownum = 1
 LEFT JOIN employer_new en on en.id = et.employer_id
 WHERE (hospital.value = 'Phoebe' OR cp.campus_isactive = 1)
 #WHERE YEAR(s.created) >= 2023 OR cvd.charges > 0
                  ");
 
 PREPARE stmt FROM @sql;
 EXECUTE stmt;
 
 END$$    
 DELIMITER ;