DROP PROCEDURE IF EXISTS RollForwardInventory; 

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `RollForwardInventory`(IN `AcctStatus` VARCHAR(255))
BEGIN

SET @EncKey = CATSEncKey();
SET @DBName = DATABASE();

SET SESSION group_concat_max_len = 1000000;


SET @sql = NULL;
SET @sql = CONCAT("

With Secondary_Ins as (
SELECT cv.group_id
,cv.payor
,max(cv.id) as id
,max(cv.plan) as plan
,ROW_NUMBER () OVER(PARTITION BY cv.group_id ORDER BY cv.id DESC) as rownum
FROM coverages cv
WHERE cv.level = 'secondary'
#and cv.plan != ''
group by group_id
),

Added_Inv as (
SELECT account_id
,t.created
,ROW_NUMBER () OVER(PARTITION BY account_id ORDER BY t.id asc) as added_inv
,ROW_NUMBER () OVER(PARTITION BY account_id ORDER BY t.id desc) as last_inv
,cs.status as Disp
FROM track_billing_accounts t 
LEFT JOIN case_status cs on t.status = cs.value and cs.type = 'account'
WHERE cs.status in ('Outstanding','Invoice–pending')
),

Removed_Inv as (
SELECT t.account_id
,cs.status as Disp
,t.created
,ROW_NUMBER () OVER(PARTITION BY t.account_id ORDER BY t.id asc) as removed_inv
FROM track_billing_accounts t
LEFT JOIN case_status cs on t.status = cs.value and cs.type = 'account'
LEFT JOIN Added_Inv av on t.account_id = av.account_id and av.last_inv = 1
WHERE t.created > av.created
),

CaseMRNRank as (
select *
,ROW_NUMBER () OVER(PARTITION BY case_id,campus_id ORDER BY is_default DESC) as rownum
from case_mrns
)
                  
SELECT hospital.value as 'Hospital'
,REPLACE(CAST(CONCAT(AES_DECRYPT(d.LastName,'",@EncKey,"'),', ',AES_DECRYPT(d.FirstName,'",@EncKey,"')) as CHAR),'&#039;','') as NAME
,IFNULL(cm.MRN, AES_DECRYPT(d.MRN,'",@EncKey,"')) as MRN
,AES_DECRYPT(c.AcctNumber,'",@EncKey,"') AS 'ACCOUNT#'
,c.Admit_Date AS 'ADMIT DATE'
,c.Discharge_Date as 'DISCHARGE DATE'
,st.name as 'SERVICE TYPE'
,REPLACE(c.Charges,',','') as 'TOTAL CHARGES'
,cd.effective_date as 'INSURANCE EFFECTIVE DATE'
,PickCoverage(c.id) as 'PRIMARY'
,CASE
	WHEN si.plan IS NULL THEN p3.name
    WHEN si.plan = '' THEN p3.name
    WHEN si.plan IS NOT NULL THEN si.plan
    ELSE p3.name
END as 'SECONDARY'
,REPLACE(c.Comm_expected,',','') as 'COMMERCIAL EXPECTED'
,REPLACE(c.Comm_payment,',','') as 'COMMERCIAL PAYMENT'
,CASE
	WHEN '",AcctStatus,"' like ip.value THEN NULL
	ELSE REPLACE(c.Mcd_expacted,',','')
END as 'MEDICAID EXPECTED'
,CASE
	WHEN '",AcctStatus,"' like ip.value THEN NULL
	ELSE REPLACE(c.difference,',','')
END as 'DIFFERENCE'
,CASE
	WHEN '",AcctStatus,"' like ip.value THEN NULL
	ELSE REPLACE(c.pfa_contingency,',','')
END as 'PFA CONTINGENCY'
,CASE
	WHEN '",AcctStatus,"' like ip.value THEN NULL
	ELSE REPLACE(c.net_revenue,',','')
END as 'HOSPITAL NET REVENUE'
,c.i_or_s as 'I OR S'
,cd.verif_date as 'Verif/Email Date'
,c.claim_date as 'CLAIM PAID DATE'
,CASE
    WHEN c.invoice_month = 0 or c.invoice_year = 0 THEN NULL
    ELSE CONCAT(c.invoice_month,'/','01','/',c.invoice_year) 
 END as 'INVOICE_DATE'
,pt.name as 'PATIENT TYPE'
,REPLACE(c.pr,',','') as 'PR'
,c.drg as 'MS DRG'
,cp.campus_name as 'CAMPUS'
,cs.status as 'Final Disp'
,'Pending Invoice'
,d.case_group as GroupID
,ai.Disp as 'Added Disp'
,FROM_UNIXTIME(ai.created) as AddedDateTime
,ri.Disp as 'Removed Disp'
,FROM_UNIXTIME(ri.created) as RemovedDateTime
from charges c
LEFT JOIN CaseMRNRank cm on cm.case_id = c.enrollee_id and c.campus_id = cm.campus_id and cm.rownum = 1
LEFT JOIN campuses cp on c.campus_id = cp.id
LEFT JOIN setting hospital on hospital.setting_key = 'HOSPITAL_NAME'
LEFT JOIN case_status cs on c.status = cs.value
LEFT JOIN demographics d on c.enrollee_id = d.id
LEFT JOIN demographic_meta dm on c.enrollee_id = dm.case_id and dm.column_name = 'SignatureDate'
LEFT JOIN claim_category cc on c.claim_cat = cc.id 
LEFT JOIN claim_category sc on c.claim_sub_cat = sc.id 
LEFT JOIN svc_types st on c.type = st.id
LEFT JOIN coverages_details cd on c.enrollee_id = cd.case_id and cd.coverage_id = PickCoverageID(c.id)
LEFT JOIN demographics_category dc on d.id = dc.case_id and 
                                      dc.id = (SELECT MAX(dc2.id)
                                               FROM demographics_category dc2
                                               where dc.case_id = dc2.case_id)
LEFT JOIN coverage_payors p on cd.payor_id = p.id
LEFT JOIN patient_types pt on dc.category_id = pt.id
LEFT JOIN case_status ip on ip.status = 'Invoice–pending'
LEFT JOIN Secondary_Ins si on si.group_id = d.case_group AND si.rownum = 1
LEFT JOIN coverage_payors p3 on si.payor = p3.id
LEFT JOIN Added_Inv ai on AES_DECRYPT(c.AcctNumber,'",@EncKey,"') = ai.account_id and ai.added_inv = 1
LEFT JOIN Removed_Inv ri on AES_DECRYPT(c.AcctNumber,'",@EncKey,"') = ri.account_id and ri.removed_inv = 1
WHERE (FIND_IN_SET(c.status, '",AcctStatus,"') != 0 OR '",AcctStatus,"' < 0) AND
       cs.type = 'account' AND
       d.verified != 0 AND
       d.is_archive = 0 AND
       (cd.ae_enrolled != 1 OR cd.hospital_has_on_file != 1 OR cd.ae_enrolled IS NULL)
ORDER BY STR_TO_DATE(c.Admit_date,'%m/%d/%Y'), c.acct_order DESC
                  ");

PREPARE stmt FROM @sql;
EXECUTE stmt;
      
END$$
DELIMITER ;