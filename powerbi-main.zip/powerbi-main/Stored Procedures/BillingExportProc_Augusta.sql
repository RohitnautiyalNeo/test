DROP PROCEDURE IF EXISTS BillingExportProc_Augusta;

DELIMITER $$
CREATE PROCEDURE BillingExportProc_Augusta()

BEGIN

With Flags_Grouped as (
select enrollee_id
,ft.name as flag_type
,GROUP_CONCAT(DISTINCT f.name SEPARATOR '//') as category
,GROUP_CONCAT(DISTINCT f2.name SEPARATOR '//') as subcategory
from assigned_flags a
left join flag_category f on a.flag_type = f.type and a.category = f.id
left join flag_category f2 on a.flag_type = f2.type and a.subcategory = f2.id
left join flag_type ft on a.flag_type = ft.id
group by enrollee_id, flag_type
)

SELECT MONTHNAME(STR_TO_DATE(IF(c.invoice_month=0,'',c.invoice_month), '%m')) as "Invoice Month"
,IF(c.invoice_year=0,'',c.invoice_year) as "Invoice Year"
,SUM(c.Comm_payment) as "Commercial Payments"
,SUM(REPLACE(c.Charges,',','')) as "Total Charges"
,COUNT(rf.enrollee_id) as "Referral Accounts"
,COUNT(DISTINCT rf.enrollee_id) as "Referral Patients"
,SUM(CASE WHEN rf.enrollee_id IS NOT NULL THEN REPLACE(c.Charges,',','') ELSE 0 END) as "Total Charges Referral Accounts"
,SUM(CASE WHEN rf.enrollee_id IS NOT NULL THEN c.Comm_payment ELSE 0 END) as "Total Commercial Payment Referral Accounts"
FROM charges c
LEFT JOIN Flags_Grouped rf on c.enrollee_id = rf.enrollee_id and rf.flag_type = 'Info Flags' and rf.category like '%REF%'
LEFT JOIN case_status cs on c.status = cs.value and cs.type = 'account'
WHERE c.invoice_month is not null
and cs.status in ('Invoice–sent','Invoice–paid','Invoice–ready')
GROUP BY c.invoice_year, c.invoice_month;

END$$    
DELIMITER ;