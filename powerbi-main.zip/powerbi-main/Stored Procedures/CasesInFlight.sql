DROP PROCEDURE IF EXISTS CasesInFlight;

DELIMITER $$    
CREATE PROCEDURE CasesInFlight() 

BEGIN

SET @NameKey = (SELECT column_value FROM upload_settings WHERE column_name = 'NAME_KEY');
SET @LastKey = (SELECT IFNULL((SELECT column_value FROM upload_settings WHERE column_name = 'LAST_KEY'),
    (SELECT column_value FROM upload_settings WHERE column_name = 'NAME_KEY')));
SET @DOBKey = (SELECT column_value FROM upload_settings WHERE column_name = 'DOB_KEY');

SET @EncKey = EncKey();
SET SESSION group_concat_max_len = 1000000;

SET @sql = NULL;
SET @sql = CONCAT("

                  
With 
Total_Charges as (
SELECT case_id
,AES_DECRYPT(charges_ref_number,'",@EncKey,"') as AcctNumber
,SUM(CAST(replace(replace(AES_DECRYPT(Total_Acc_Bal,'",@EncKey,"'),'$',''),',','') as decimal(10,2))) as TotalCharges
,MAX(created_at) as created_at_max 
FROM charges 
WHERE id IN(
			SELECT max(id) as id 
			FROM charges 
			WHERE AES_DECRYPT(Total_Acc_Bal,'",@EncKey,"') IS NOT NULL
			GROUP BY case_id,AES_DECRYPT(charges_ref_number,'",@EncKey,"'))
GROUP BY case_id
),
                  
TrackQLE as (
 SELECT * 
 FROM track_qle 
 WHERE id IN (SELECT MAX(id) as id 
              FROM track_qle 
              GROUP BY case_id)
 GROUP BY case_id
 ),

Signatures as (
SELECT s.*
FROM signatures s
GROUP BY IF(case_group_id is NULL or case_group_id='', CONCAT('CG- ',case_id), case_group_id)
),

InhouseCases as (
SELECT fc.case_id 
FROM flagged_cases fc 
INNER JOIN flags f on fc.flag_id = f.id AND f.title = 'Inhouse'
),

CaseEnrollmentRank as (
SELECT ce.*
,ROW_NUMBER () OVER(PARTITION BY case_group ORDER BY id asc) as rownum
,d.case_group
FROM case_enrollment ce
LEFT JOIN demographics d on ce.case_id = d.id
),

BAS as
(SELECT d.id 
,c.bas_assigned, 
AES_DECRYPT(a.name,'",@EncKey,"') AS Bas_Assigned_Name
FROM demographics d
LEFT JOIN CaseEnrollmentRank c on d.case_group = c.case_group and c.rownum = 1
LEFT JOIN admin_user a ON a.id = c.bas_assigned
),
                  
Last_Moved_Date as (
select case_id
,max(created) as created
from track_case 
GROUP BY case_id
),

EOStart as (
SELECT case_id
,cs.status
,FROM_UNIXTIME(MIN(created)) as created
FROM track_case tc
LEFT JOIN case_status cs on tc.status = cs.value
WHERE cs.status = 'Employer Outreach'
GROUP BY case_id, status
),
                  
AppPrepStart as (
SELECT case_id
,cs.status
,FROM_UNIXTIME(MIN(created)) as created
FROM track_case tc
LEFT JOIN case_status cs on tc.status = cs.value
WHERE cs.status = 'App Prep'
GROUP BY case_id, status
),  

AppSentStart as (
SELECT case_id
,cs.status
,FROM_UNIXTIME(MIN(created)) as created
FROM track_case tc
LEFT JOIN case_status cs on tc.status = cs.value
WHERE cs.status = 'Application Sent'
GROUP BY case_id, status
),

Consent_Received as (
SELECT case_id
,NoteDate
,ROW_NUMBER () OVER(PARTITION BY n.case_id ORDER BY n.id asc) as rownum
FROM notes n
LEFT JOIN demographics d on n.case_id = d.id
WHERE AES_DECRYPT(Note,'",@EncKey,"') like '%ESI Consent Received%'
),
                  
Enrollment_Complete as (                  
SELECT case_id
,NoteDate
,ROW_NUMBER () OVER(PARTITION BY n.case_id ORDER BY n.id asc) as rownum
FROM notes n
LEFT JOIN demographics d on n.case_id = d.id
WHERE AES_DECRYPT(Note,'",@EncKey,"') like '%Enrollment Status%ENROLLMENT COMPLETE%'
), 

CostEffective as (
SELECT case_id
,CASE 
     WHEN NotCostEffective = 1 THEN 'No'
     WHEN CE = 1 THEN 'C/E'
     ELSE NULL
END as 'CE'
,CASE
     WHEN CE = 1 THEN FROM_UNIXTIME(created)
     ELSE NULL
END as CE_Date
FROM (
select s.case_id
,s.NotCostEffective
,max(p.family_members_enrolling) as CE
,p.created
from state_operations s
INNER JOIN state_operations_plans p on s.id = p.relation_id
group by case_id) as InnerTable
),

CaseDetailsRanks as (
SELECT case_id
,charges
,esi_verification_date
,ROW_NUMBER () OVER(PARTITION BY case_id ORDER BY data_from ASC, id DESC) as rownum
FROM case_verification_details
)

SELECT DISTINCT hospital.value as "'"Hospital"'"
,rvp.value as "'"RVP"'"
,region.value as "'"Region"'"
,d.id as case_id
,CASE 
 	WHEN @NameKey = @LastKey THEN AES_DECRYPT(fn.column_value,'",@EncKey,"')
 	ELSE CAST(CONCAT(AES_DECRYPT(ln.column_value,'",@EncKey,"'), ', ',AES_DECRYPT(fn.column_value,'",@EncKey,"')) as CHAR)
 END as Name
,AES_DECRYPT(dn.column_value,'",@EncKey,"') as DOB
,cp.campus_name as Campus
,CAST(AES_DECRYPT(d.MRN,'",@EncKey,"') as CHAR) as MRN
,d.admit_dates as Date_Admitted
,c.status as Bucket
,DATEDIFF(NOW(),FROM_UNIXTIME(lmd.created)) as 'Days in Bucket'
,d.days_left AS DaysLeft
,tc.TotalCharges
,tc.AcctNumber
,CASE
    WHEN tc.TotalCharges IS NULL THEN '0 - 100,000'
    WHEN tc.TotalCharges <= 100000 THEN '0 - 100,000'
    WHEN tc.TotalCharges <= 300000 THEN '100,000 - 300,000'
    WHEN tc.TotalCharges <= 500000 THEN '300,000 - 500,000'
    WHEN tc.TotalCharges <= 1000000 THEN '500,000 - 1,000,000'
    WHEN tc.TotalCharges <= 2000000 THEN '1,000,000 - 2,000,000'
    ELSE '2,000,000+'
END as ChargeRange
,d.date_add
,cr.total_rank as CurrentCaseRank
,d.max_case_rank
,CASE
	WHEN dcn.category_id = 1 THEN 'NICU'
	WHEN dcn.category_id = 2 THEN 'PICU'
	ELSE 'ADULT'
END as PatientType
,FROM_UNIXTIME(sig.created,'%m/%d/%Y') as SIGNATURE_DATE
,eo.created as EmployerOutreach
,ap.created as AppPrep
,CASE
    WHEN hospital.value in ('CHOA','Northern Light','Prisma Health','The valley Health System','Northeast Georgia','Emory Health System','Northside','Phoebe','Saint Francis','Augusta University Medical Center') and ap.created IS NOT NULL THEN 'C/E'
    ELSE ce.CE
END as 'CE'
,ass.created as ApplicationSent
,CASE
	WHEN hospital.value in ('CHOA','Northern Light','Prisma Health','The valley Health System','Northeast Georgia','Emory Health System','Northside','Phoebe','Saint Francis','Augusta University Medical Center') and ap.created IS NOT NULL THEN ap.created
    ELSE ce.CE_Date
END as CE_Date
,enroll.esi_consent_received as ESI_Consent
,enroll.enrollment_sent as Enroll_Start
,enroll.enrollment_status as Enroll_Status
,cvd.esi_verification_date as Verify_Date
,cvd.charges as CapturedCharges
,enroll.qle_type
,enroll.issues
,enroll.verification_status
,enroll.potential_charges
,cnr.NoteDate as ConsentReceived
,ec.NoteDate as EnrollmentComplete
,d.highlight_case
,bb.Bas_Assigned_Name
,emp.field_value AS 'Employer Name'
,IF(ic.case_id IS NULL,'N','Y') as Inhouse
FROM demographics d
INNER JOIN case_status c on d.case_status = c.value and c.status not in ("'"Closed"'","'"Close"'","'"Archive"'","'"Maintenance"'","'"Renewal"'")
LEFT JOIN campuses cp on d.campus = cp.id
LEFT JOIN BAS bb ON d.id = bb.id
LEFT JOIN demographic_meta fn on d.id = fn.case_id and fn.column_name = @NameKey
LEFT JOIN demographic_meta ln on d.id = ln.case_id and ln.column_name = @LastKey
LEFT JOIN demographic_meta dn on d.id = dn.case_id and dn.column_name = @DOBKey
LEFT JOIN setting rvp on rvp.setting_key = "'"RVP_NAME"'"
LEFT JOIN setting hospital on hospital.setting_key = "'"HOSPITAL_NAME"'"
LEFT JOIN setting region on region.setting_key = "'"REGION"'"
LEFT JOIN Total_Charges tc on d.id = tc.case_id
LEFT JOIN Signatures sig on sig.case_id = d.id
LEFT JOIN EOStart eo on d.id = eo.case_id
LEFT JOIN AppPrepStart ap on d.id = ap.case_id
LEFT JOIN AppSentStart ass on d.id = ass.case_id
LEFT JOIN case_ranks cr on d.id = cr.case_id
LEFT JOIN CostEffective ce on d.id = ce.case_id
LEFT JOIN CaseEnrollmentRank enroll on d.id = enroll.case_id and enroll.rownum = 1
LEFT JOIN Last_Moved_Date lmd on d.id = lmd.case_id
LEFT JOIN CaseDetailsRanks cvd on d.id = cvd.case_id and cvd.rownum = 1
LEFT JOIN (select * from demographics_category group by case_id) dcn on dcn.case_id = d.id
LEFT JOIN Consent_Received cnr on d.id = cnr.case_id and cnr.rownum = 1
LEFT JOIN Enrollment_Complete ec on d.id = ec.case_id and ec.rownum = 1
LEFT JOIN case_enrollment_details_current emp on d.id = emp.case_id AND field_type = 'employer' AND field_key = 'NAME'
LEFT JOIN InhouseCases ic on d.id = ic.case_id 
WHERE LEFT(AES_DECRYPT(d.MRN,'",@EncKey,"'),2) != '0-'
AND (hospital.value = 'Phoebe' OR cp.campus_isactive = 1)
");

PREPARE stmt FROM @sql;
EXECUTE stmt;

END