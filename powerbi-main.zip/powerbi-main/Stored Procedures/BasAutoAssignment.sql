DROP PROCEDURE IF EXISTS BasAutoAssignment;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `BasAutoAssignment`(IN `input_caseID` INT)

BEGIN
SET @EncKey = EncKey();

SELECT COUNT(*)
INTO 
@CountRow 
FROM case_enrollment 
WHERE case_id = input_caseID;

SELECT GROUP_CONCAT(bas_user)
INTO
@BAS_User
FROM bas_auto b 
INNER JOIN setting s on s.setting_key = 'HOSPITAL_NAME'
WHERE b.hospital = s.value;

SELECT COUNT(case_id) as Moved
INTO
@Moved
from track_case tc
LEFT JOIN case_status cs on tc.status = cs.value
WHERE cs.status = 'App Prep';

SELECT LENGTH(REGEXP_REPLACE(@Bas_User, '[0-9]+', '')) + 1
INTO
@Num_Users;

IF @CountRow = 0 THEN
INSERT IGNORE INTO case_enrollment (case_id, user_id, bas_assigned)

With UserList as (
SELECT bas_user
,ROW_NUMBER () OVER(PARTITION BY hospital) as rownum
FROM bas_auto b 
INNER JOIN setting s on s.setting_key = 'HOSPITAL_NAME'
WHERE b.hospital = s.value
)

SELECT input_caseID
,1
,bas_user
FROM UserList b
WHERE rownum = (@Moved MOD @Num_Users) + 1;

ELSE

With UserList as (
SELECT bas_user
,ROW_NUMBER () OVER(PARTITION BY hospital) as rownum
FROM bas_auto b 
INNER JOIN setting s on s.setting_key = 'HOSPITAL_NAME'
WHERE b.hospital = s.value
)

UPDATE case_enrollment
INNER JOIN UserList b on rownum = (@Moved MOD @Num_Users) + 1
SET bas_assigned = bas_user
WHERE case_id = input_caseID
AND bas_assigned IS NULL;

END IF;

END$$    
DELIMITER ;