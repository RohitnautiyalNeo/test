DROP PROCEDURE IF EXISTS DailyCases;

DELIMITER $$ 

CREATE PROCEDURE DailyCases(Admin_id INT, Amount_id INT, Days INT, Statuses VARCHAR(25))
BEGIN

DECLARE ENCKEY VARCHAR(100);
DECLARE AmountCondition VARCHAR(250);

SET SESSION group_concat_max_len = 1000000;

SET ENCKEY = EncKey();
SET @SQL_ = NULL;

SET AmountCondition = CASE 
	WHEN Amount_id = 6 THEN 'd.Total_Acc_Bal > 500000'
    WHEN Amount_id = 5 THEN 'd.Total_Acc_Bal > 750000'
    WHEN Amount_id = 4 THEN 'd.Total_Acc_Bal BETWEEN 300000 AND 749999'
    WHEN Amount_id = 3 THEN 'd.Total_Acc_Bal BETWEEN 100000 AND 299999'
    WHEN Amount_id = 2 THEN 'd.Total_Acc_Bal BETWEEN 50000 AND 99999'
    WHEN Amount_id = 1 THEN 'd.Total_Acc_Bal BETWEEN 0 AND 49999'
    WHEN Amount_id = 0 THEN 'd.Total_Acc_Bal > 0'
END;

SET @SQL_ = CONCAT("

WITH 
Assign_user AS (
    SELECT
        cau.case_id
     ,cau.user_id
     ,AES_DECRYPT(au.name,'",ENCKEY, "') AS name
    ,ROW_NUMBER () OVER(PARTITION BY cau.case_id ORDER BY cau.id desc) as rownum
    FROM cases_assigned_users cau
    LEFT JOIN admin_user au ON au.id = cau.user_id
),

Notee AS (
    SELECT  
        d.case_group, 
        MAX(DATE_FORMAT(n.date_add, '%Y-%m-%d')) AS NoteDatee
    FROM demographics d
    LEFT JOIN notes n ON n.case_id = d.id
    GROUP BY d.case_group
),

Last_note_date AS (
    SELECT 
        d.id, 
        COALESCE(
            n.NoteDatee, 
            MAX(DATE_FORMAT(nn.date_add, '%Y-%m-%d'))
                  ) AS Last_note_date
    FROM demographics d
    LEFT JOIN notes nn on nn.case_id = d.id
    LEFT JOIN Notee n ON n.case_group = d.case_group
    GROUP BY d.id
),

RankedEmployers AS (
    SELECT * 
    FROM (
        SELECT
            et.case_id,
            AES_DECRYPT(en.EmpName, '",ENCKEY, "') AS Employer,
            ROW_NUMBER() OVER (PARTITION BY et.case_id ORDER BY et.created DESC) AS rownum
        FROM employers_tab et
        LEFT JOIN employer_new en ON en.id = et.employer_id
    ) AS FirstTable
    WHERE rownum = 1
)

SELECT 
    d.id AS case_id,
    CASE
         WHEN pa.patient_type = 'in' THEN 'Inpatient'
         WHEN pa.patient_type = 'out' THEN 'Outpatient'
    END AS PatientType,
    hospital.value AS 'Hospital',
    campuses.campus_name AS CAMPUS,
    AES_DECRYPT(d.MRN,'",ENCKEY, "') AS MRN,
    GetFirstName(d.id) AS 'First Name',
    GetLastName(d.id) AS 'Last Name',
    CASE
        WHEN d.Total_Acc_Bal < 100000 THEN '< 100,000'
        WHEN d.Total_Acc_Bal BETWEEN 100000 AND 300000 THEN '100,000 - 300,000'
        WHEN d.Total_Acc_Bal BETWEEN 300000 AND 500000 THEN '300,000 - 500,000'
        WHEN d.Total_Acc_Bal BETWEEN 500000 AND 1000000 THEN '500,000 - 1M'
        WHEN d.Total_Acc_Bal > 1000000 THEN '1M+'
        ELSE 'Unknown'
    END AS ChargeRange,
    d.Total_Acc_Bal AS 'Total Charges',
    L.Last_note_date AS 'Last Note Date',
    DATEDIFF(CURDATE(), L.Last_note_date) AS 'Days_since_last_Touched',
    cc.name AS 'Cases Categories',
    d.admit_dates AS Admit_Date,
    AES_DECRYPT(d.DischargeDate, '",ENCKEY, "') AS DischargeDate,
    d.date_add AS 'Added On',
    IFNULL(cec.field_value, re.Employer) AS Employer,
    au.name AS 'Assigned To',
    cs.status AS 'Current Status',
    AES_DECRYPT(admin_user.name, '",ENCKEY, "') AS CaseOwner,
    d.days_left AS DaysLeft,
    f.Flag
FROM demographics d
LEFT JOIN case_enrollment_details_current cec ON d.id = cec.case_id AND cec.field_type = 'employer' AND cec.field_key = 'NAME' AND cec.is_deleted = 0
LEFT JOIN patient_activity pa on d.id = pa.case_id and pa.id = (SELECT max(pa2.id)
                                                                       FROM patient_activity pa2
                                                                       WHERE pa.case_id = pa2.case_id)
LEFT JOIN case_status cs ON d.case_status = cs.value
LEFT JOIN setting hospital ON hospital.setting_key = 'HOSPITAL_NAME'
LEFT JOIN Last_note_date L ON L.id = d.id
LEFT JOIN admin_user ON admin_user.id = d.case_owner
LEFT JOIN campuses ON campuses.id = d.campus
LEFT JOIN demographics_category dc ON dc.case_id = d.id
LEFT JOIN cases_categories cc ON cc.id = dc.category_id
LEFT JOIN Assign_user au ON au.case_id = d.id and au.rownum = 1
LEFT JOIN RankedEmployers re ON re.case_id = d.id
LEFT JOIN (SELECT fc.case_id, 'Inhouse' AS Flag FROM flagged_cases fc LEFT JOIN flags f ON f.id = fc.flag_id WHERE f.title = 'Inhouse') f ON f.case_id = d.id
WHERE AES_DECRYPT(d.MRN, '",ENCKEY, "') NOT LIKE '%0-%'
  AND (hospital.value = 'Phoebe' OR campuses.campus_isactive = 1)
  AND DATEDIFF(CURDATE(),L.Last_note_date) > ",Days,"
  AND (FIND_IN_SET(cs.status, '",Statuses,"') != 0 OR '",Statuses,"' = 'All')
  AND (", Admin_id, " < 0 OR au.user_id = ", Admin_id, ")
  AND ", AmountCondition, "
");

PREPARE stmt FROM @SQL_;
EXECUTE stmt;

END$$    

DELIMITER ;