DROP PROCEDURE IF EXISTS BillingExportProc_Prisma;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `BillingExportProc_Prisma`(IN `AcctStatus` VARCHAR(255)
, IN `InvoiceMonth` INT
, IN `InvoiceYear` INT
, IN `GroupID` INT
, IN `CaseID` INT
, IN `FormatID` VARCHAR(255)
, IN `DateFrom` VARCHAR(255)
, IN `DateThru` VARCHAR(255)
, IN `ChargeType` VARCHAR(255)
, IN `ChargeAmount` VARCHAR(255)
, IN `CommExpectedType` VARCHAR(255)
, IN `CommExpectedAmount` VARCHAR(255)
, IN `ContingencyType` VARCHAR(255)
, IN `ContingencyAmount` VARCHAR(255)
, IN `AdmitFrom` VARCHAR(255)
, IN `AdmitThru` VARCHAR(255)
, IN `VerifFrom` VARCHAR(255)
, IN `VerifThru` VARCHAR(255)
, IN `DRGType` VARCHAR(255)
, IN `DRGAmount` VARCHAR(255)
, IN `IORS` VARCHAR(255)
, IN `ClaimCat` VARCHAR(255)
, IN `ClaimSubCat` VARCHAR(255)
, IN `CommPaymentType` VARCHAR(255)
, IN `CommPaymentAmount` VARCHAR(255)
, IN `MCDExpectedType` VARCHAR(255)
, IN `MCDExpectedAmount` VARCHAR(255)
, IN `NetRevType` VARCHAR(255)
, IN `NetRevAmount` VARCHAR(255)
, IN `DischargeFrom` VARCHAR(255)
, IN `DischargeThru` VARCHAR(255)
, IN `PaidFrom` VARCHAR(255)
, IN `PaidThru` VARCHAR(255)
, IN `PRType` VARCHAR(255)
, IN `PRAmount` VARCHAR(255)
, IN `FlagType` VARCHAR(255)
, IN `FlagCategory` VARCHAR(255)
, IN `FlagSubCategory` VARCHAR(255)
, IN `AlreadyEnrolled` VARCHAR(255)
, IN `HospOnFile` VARCHAR(255)
, IN `BalType` VARCHAR(255)
, IN `BalAmount` VARCHAR(255)
, IN `ServiceType` VARCHAR(255)
, IN `Campus` VARCHAR(255)
, IN `FlagStatus` VARCHAR(255)
, IN `NoteTags` VARCHAR(255)
, IN `DaysLeft` VARCHAR(255))
BEGIN

SET @EncKey = CATSEncKey();
SET @DBName = DATABASE();

SET SESSION group_concat_max_len = 1000000;


SET @sql = NULL;
SET @sql = CONCAT("

With Secondary_Ins as (
SELECT cv.group_id
,cv.payor
,max(cv.id) as id
,max(cv.plan) as plan
,ROW_NUMBER () OVER(PARTITION BY cv.group_id ORDER BY cv.id DESC) as rownum
FROM coverages cv
WHERE cv.level = 'secondary'
#and cv.plan != ''
group by group_id
),

PT_Notes_Grouped as (
select acct_id
,GROUP_CONCAT(note_tags order by pined desc, modified desc SEPARATOR ',') as note_tags
,GROUP_CONCAT(
	CASE
    	WHEN nt.name IS NULL THEN AES_DECRYPT(note,'",@EncKey,"')
        ELSE CONCAT(nt.name,' : ', AES_DECRYPT(note,'",@EncKey,"'))
    END order by pined desc, modified desc SEPARATOR '//') as notes
from notes n
LEFT JOIN note_tags nt ON nt.id = n.note_tags
where note_type = 'account'         
",
CASE
	WHEN FormatID = 'Small' THEN 
"AND pined = 1"
ELSE ""
END,
"
group by acct_id
),

Flags_Grouped as (
select enrollee_id
,ft.name as flag_type
,GROUP_CONCAT(DISTINCT f.name SEPARATOR '//') as category
,GROUP_CONCAT(DISTINCT f2.name SEPARATOR '//') as subcategory
from assigned_flags a
left join flag_category f on a.flag_type = f.type and a.category = f.id
left join flag_category f2 on a.flag_type = f2.type and a.subcategory = f2.id
left join flag_type ft on a.flag_type = ft.id
group by enrollee_id, flag_type
),

CaseMRNRank as (
select *
,ROW_NUMBER () OVER(PARTITION BY case_id,campus_id ORDER BY is_default DESC) as rownum
from case_mrns
)
                  
    SELECT 
    cp.campus_name as 'CAMPUS'
			,REPLACE(CAST(CONCAT(AES_DECRYPT(d.LastName,@EncKey),', ',AES_DECRYPT(d.FirstName,@EncKey)) as CHAR),'&#039;','') as 'NAME'
			,IFNULL(cm.MRN, AES_DECRYPT(d.MRN,@EncKey)) as 'MRN'
			,AES_DECRYPT(c.AcctNumber,@EncKey) AS 'ACCOUNT#'
			,c.Facility as 'FACILITY'
			,c.Admit_Date as 'ADMIT DATE'
			,c.Discharge_Date as 'DISCHARGE DATE'
			,st.name as 'SERVICE TYPE'
			,REPLACE(c.Charges,',','') as 'TOTAL CHARGES'
			,cd.effective_date as 'INSURANCE EFFECTIVE DATE'
			,PickCoverage(c.id) as 'PRIMARY'
			,c.drg as 'MS DRG'
			,PickCoverage_Secondary(c.id) as 'SECONDARY'
			,apr_drg as 'APR DRG'
			,APR_DRG_Relative_Weight as 'APR DRG Relative Weight'
			,REPLACE(c.Comm_expected,',','') as 'COMMERCIAL EXPECTED'
			,REPLACE(c.comm_allowed,',','') as 'Commercial Allowed'
			,REPLACE(c.Comm_payment,',','') as 'COMMERCIAL PAYMENT'
			,REPLACE(c.pr,',','') 'PR'
			,Medicaid_FFS_Expected as 'Medicaid FFS Expected'
			,Medicaid_HMO_Expected as 'Medicaid HMO Expected'
			,HAWQ as 'HAWQ %'
			,charges_check as 'check'
			",CASE
				WHEN FormatID = 'Prisma' THEN ',DSH'
				ELSE ""
			END
			,"
			,Medicaid_HMO_HAWQ_Expected as 'Medicaid HMO+HAWQ Expected'
			,Difference_Before_Deductions as 'Difference Before Deductions'
			,IME as 'IME'
			,GME as 'GME'
            ",CASE 
            	WHEN FormatID = 'Prisma' THEN ",CASE 
            										WHEN c.invoice_month = 0 or c.invoice_year = 0 THEN NULL
     												ELSE CONCAT(c.invoice_month,'/','01','/',c.invoice_year) 
  												END as 'Invoice Date (PFA Orig)'"
                   ELSE ",c.invoice_month as 'INVOICE MONTH'
					     ,c.invoice_year as 'INVOICE YEAR'"
              END,
            "
			,c.i_or_s as 'I or S'
			,cd.verif_date as 'Verif/Email Date'
			,pt.name as 'Patient Type'
			,c.claim_date as 'CLAIM PAID DATE'
			",CASE
				WHEN FormatID = 'Small' THEN ",c.hospital_notes as 'Hospital Notes'
                                              ,cs.status as 'Final Disp'
                                              ,REPLACE(c.Mcd_expacted,',','') as 'MEDICAID EXPECTED'
                                              ,REPLACE(c.difference,',','') as 'DIFFERENCE'
                                           	  ,REPLACE(c.pfa_contingency,',','') as 'PFA CONTINGENCY'
					                          ,REPLACE(c.net_revenue,',','') as 'HOSPITAL NET REVENUE'"
                ELSE ",REPLACE(c.Mcd_expacted,',','') as 'MEDICAID EXPECTED'
                      ,REPLACE(c.difference,',','') as 'DIFFERENCE'
					  ,REPLACE(c.net_revenue,',','') as 'HOSPITAL NET REVENUE'
					  ,REPLACE(c.pfa_contingency,',','') as 'PFA CONTINGENCY'
					  ,n.notes as 'ACCT NOTES'
					  ,cs.status as 'Final Disp'
                      ,CASE
						WHEN c.invoice_month = 0 THEN NULL
						ELSE c.invoice_month
					   END as 'INVOICE MONTH'
					  ,CASE
						WHEN c.invoice_year = 0 THEN NULL
						ELSE c.invoice_year
					   END as 'INVOICE YEAR'"
             END,
"
from charges c
LEFT JOIN CaseMRNRank cm on cm.case_id = c.enrollee_id and c.campus_id = cm.campus_id and cm.rownum = 1
LEFT JOIN campuses cp on c.campus_id = cp.id
LEFT JOIN setting hospital on hospital.setting_key = 'HOSPITAL_NAME'
LEFT JOIN case_status cs on c.status = cs.value
LEFT JOIN demographics d on c.enrollee_id = d.id
LEFT JOIN demographic_meta dm on c.enrollee_id = dm.case_id and dm.column_name = 'SignatureDate'
left join claim_category cc on c.claim_cat = cc.id 
left join claim_category sc on c.claim_sub_cat = sc.id 
LEFT JOIN svc_types st on c.type = st.id
LEFT JOIN coverages_details cd on c.enrollee_id = cd.case_id and cd.coverage_id = PickCoverageID(c.id)
left join demographics_category dc on d.id = dc.case_id and 
                                      dc.id = (SELECT MAX(dc2.id)
                                               FROM demographics_category dc2
                                               where dc.case_id = dc2.case_id)         
LEFT JOIN Flags_Grouped fiss on d.id = fiss.enrollee_id and fiss.flag_type = 'Issue Flags'
LEFT JOIN Flags_Grouped finfo on d.id = finfo.enrollee_id and finfo.flag_type = 'Info Flags'
LEFT JOIN Flags_Grouped facct on d.id = facct.enrollee_id and facct.flag_type = 'Acct Flags'
LEFT JOIN PT_Notes_Grouped n on c.id = n.acct_id
left join assigned_flags af on af.enrollee_id = c.enrollee_id and af.flag_type = '",FlagType,"' and af.category = '",FlagCategory,"'
left join assigned_flags af2 on af2.enrollee_id = c.enrollee_id and af2.flag_type = '",FlagType,"' and af2.subcategory = '",FlagSubCategory,"'
left join coverage_payors p on cd.payor_id = p.id
left join patient_types pt on dc.category_id = pt.id
left join case_status ip on ip.status = 'Invoice–pending'
left join Secondary_Ins si on si.group_id = d.case_group AND si.rownum = 1
left join coverage_payors p3 on si.payor = p3.id
WHERE (FIND_IN_SET(c.status, '",AcctStatus,"') != 0 OR '",AcctStatus,"' < 0) AND
      (FIND_IN_SET(cp.id, '",Campus,"') != 0 OR '",Campus,"' < 0) AND
      (FIND_IN_SET(c.type, '",ServiceType,"') != 0 OR '",ServiceType,"' < 0) AND
      (FIND_IN_SET('",NoteTags,"',n.note_tags) != 0 OR '",NoteTags,"' < 0) AND
      (c.invoice_month = '",InvoiceMonth,"' OR '",InvoiceMonth,"' < 0) AND
      (c.invoice_year = '",InvoiceYear,"' OR '",InvoiceYear,"' < 0) AND
      (d.case_group = '",GroupID,"' OR '",GroupID,"' < 0) AND
      (d.id = '",CaseID,"' OR '",CaseID,"' < 0) AND
      (c.created >= (UNIX_TIMESTAMP(STR_TO_DATE('",DateFrom,"','%m/%d/%Y'))) OR '",DateFrom,"' < 0) AND
      (c.created <= (UNIX_TIMESTAMP(STR_TO_DATE('",DateThru,"','%m/%d/%Y'))) OR '",DateThru,"' < 0) AND
      (FIND_IN_SET(REPLACE(fiss.category,'//',','), '",ClaimCat,"') != 0 OR '",ClaimCat,"' < 0) AND    
      (FIND_IN_SET(REPLACE(fiss.subcategory,'//',','), '",ClaimSubCat,"') != 0 OR '",ClaimSubCat,"' < 0) AND
      (af.category = '",FlagCategory,"' OR '",FlagCategory,"' < 0) AND
      (af2.subcategory = '",FlagSubCategory,"' OR '",FlagSubCategory,"' < 0) AND
      (af.is_resolved = '",FlagStatus,"' OR '",FlagStatus,"' < 0) AND
      (af2.is_resolved = '",FlagStatus,"' OR '",FlagStatus,"' < 0) AND
      (c.i_or_s = '",IORS,"' OR '",IORS,"' < 0) AND
      (CASE
           WHEN '",ChargeType,"' = 1 THEN CAST(REPLACE(c.Charges,',','') as DECIMAL(12,2)) = '",ChargeAmount,"'
           WHEN '",ChargeType,"' = 2 THEN CAST(REPLACE(c.Charges,',','') as DECIMAL(12,2)) > '",ChargeAmount,"'
           WHEN '",ChargeType,"' = 3 THEN CAST(REPLACE(c.Charges,',','') as DECIMAL(12,2)) >= '",ChargeAmount,"'
           WHEN '",ChargeType,"' = 4 THEN CAST(REPLACE(c.Charges,',','') as DECIMAL(12,2)) < '",ChargeAmount,"'
           WHEN '",ChargeType,"' = 5 THEN CAST(REPLACE(c.Charges,',','') as DECIMAL(12,2)) <= '",ChargeAmount,"'     
           WHEN '",ChargeType,"' = 6 THEN CAST(REPLACE(c.Charges,',','') as DECIMAL(12,2)) BETWEEN REPLACE(SUBSTRING_INDEX('",ChargeAmount,"', '-', 1),',','') AND 
                                                                                                   REPLACE(SUBSTRING_INDEX('",ChargeAmount,"', '-', -1),',','')       
       END OR '",ChargeType,"' < 0) AND 
      (CASE
           WHEN '",BalType,"' = 1 THEN CAST(REPLACE(c.bal,',','') as DECIMAL(12,2)) = '",BalAmount,"'
           WHEN '",BalType,"' = 2 THEN CAST(REPLACE(c.bal,',','') as DECIMAL(12,2)) > '",BalAmount,"'
           WHEN '",BalType,"' = 3 THEN CAST(REPLACE(c.bal,',','') as DECIMAL(12,2)) >= '",BalAmount,"'
           WHEN '",BalType,"' = 4 THEN CAST(REPLACE(c.bal,',','') as DECIMAL(12,2)) < '",BalAmount,"'
           WHEN '",BalType,"' = 5 THEN CAST(REPLACE(c.bal,',','') as DECIMAL(12,2)) <= '",BalAmount,"'     
           WHEN '",BalType,"' = 6 THEN CAST(REPLACE(c.bal,',','') as DECIMAL(12,2)) BETWEEN REPLACE(SUBSTRING_INDEX('",BalAmount,"', '-', 1),',','') AND 
                                                                                                   REPLACE(SUBSTRING_INDEX('",BalAmount,"', '-', -1),',','')       
       END OR '",BalType,"' < 0) AND 
      (CASE
           WHEN '",CommExpectedType,"' = 1 THEN CAST(REPLACE(c.Comm_expected,',','') as DECIMAL(12,2)) = '",CommExpectedAmount,"'
           WHEN '",CommExpectedType,"' = 2 THEN CAST(REPLACE(c.Comm_expected,',','') as DECIMAL(12,2)) > '",CommExpectedAmount,"'
           WHEN '",CommExpectedType,"' = 3 THEN CAST(REPLACE(c.Comm_expected,',','') as DECIMAL(12,2)) >= '",CommExpectedAmount,"'
           WHEN '",CommExpectedType,"' = 4 THEN CAST(REPLACE(c.Comm_expected,',','') as DECIMAL(12,2)) < '",CommExpectedAmount,"'
           WHEN '",CommExpectedType,"' = 5 THEN CAST(REPLACE(c.Comm_expected,',','') as DECIMAL(12,2)) <= '",CommExpectedAmount,"'     
           WHEN '",CommExpectedType,"' = 6 THEN CAST(REPLACE(c.Comm_expected,',','') as DECIMAL(12,2)) BETWEEN REPLACE(SUBSTRING_INDEX('",CommExpectedAmount,"', '-', 1),',','') AND 
                                                                                                               REPLACE(SUBSTRING_INDEX('",CommExpectedAmount,"', '-', -1),',','')       
       END OR '",CommExpectedType,"' < 0) AND 
      (CASE
           WHEN '",ContingencyType,"' = 1 THEN CAST(REPLACE(c.pfa_contingency,',','') as DECIMAL(12,2)) = '",ContingencyAmount,"'
           WHEN '",ContingencyType,"' = 2 THEN CAST(REPLACE(c.pfa_contingency,',','') as DECIMAL(12,2)) > '",ContingencyAmount,"'
           WHEN '",ContingencyType,"' = 3 THEN CAST(REPLACE(c.pfa_contingency,',','') as DECIMAL(12,2)) >= '",ContingencyAmount,"'
           WHEN '",ContingencyType,"' = 4 THEN CAST(REPLACE(c.pfa_contingency,',','') as DECIMAL(12,2)) < '",ContingencyAmount,"'
           WHEN '",ContingencyType,"' = 5 THEN CAST(REPLACE(c.pfa_contingency,',','') as DECIMAL(12,2)) <= '",ContingencyAmount,"'     
           WHEN '",ContingencyType,"' = 6 THEN CAST(REPLACE(c.pfa_contingency,',','') as DECIMAL(12,2)) BETWEEN REPLACE(SUBSTRING_INDEX('",ContingencyAmount,"', '-', 1),',','') AND 
                                                                                                                REPLACE(SUBSTRING_INDEX('",ContingencyAmount,"', '-', -1),',','')       
       END OR '",ContingencyType,"' < 0) AND 
      (CASE
           WHEN '",DRGType,"' = 1 THEN CAST(REPLACE(c.drg,',','') as DECIMAL(12,2)) = '",DRGAmount,"'
           WHEN '",DRGType,"' = 2 THEN CAST(REPLACE(c.drg,',','') as DECIMAL(12,2)) > '",DRGAmount,"'
           WHEN '",DRGType,"' = 3 THEN CAST(REPLACE(c.drg,',','') as DECIMAL(12,2)) >= '",DRGAmount,"'
           WHEN '",DRGType,"' = 4 THEN CAST(REPLACE(c.drg,',','') as DECIMAL(12,2)) < '",DRGAmount,"'
           WHEN '",DRGType,"' = 5 THEN CAST(REPLACE(c.drg,',','') as DECIMAL(12,2)) <= '",DRGAmount,"'     
           WHEN '",DRGType,"' = 6 THEN CAST(REPLACE(c.drg,',','') as DECIMAL(12,2)) BETWEEN REPLACE(SUBSTRING_INDEX('",DRGAmount,"', '-', 1),',','') AND 
                                                                                            REPLACE(SUBSTRING_INDEX('",DRGAmount,"', '-', -1),',','')       
       END OR '",DRGType,"' < 0) AND 
      (CASE
           WHEN '",CommPaymentType,"' = 1 THEN CAST(REPLACE(c.Comm_payment,',','') as DECIMAL(12,2)) = '",CommPaymentAmount,"'
           WHEN '",CommPaymentType,"' = 2 THEN CAST(REPLACE(c.Comm_payment,',','') as DECIMAL(12,2)) > '",CommPaymentAmount,"'
           WHEN '",CommPaymentType,"' = 3 THEN CAST(REPLACE(c.Comm_payment,',','') as DECIMAL(12,2)) >= '",CommPaymentAmount,"'
           WHEN '",CommPaymentType,"' = 4 THEN CAST(REPLACE(c.Comm_payment,',','') as DECIMAL(12,2)) < '",CommPaymentAmount,"'
           WHEN '",CommPaymentType,"' = 5 THEN CAST(REPLACE(c.Comm_payment,',','') as DECIMAL(12,2)) <= '",CommPaymentAmount,"'     
           WHEN '",CommPaymentType,"' = 6 THEN CAST(REPLACE(c.Comm_payment,',','') as DECIMAL(12,2)) BETWEEN REPLACE(SUBSTRING_INDEX('",CommPaymentAmount,"', '-', 1),',','') AND 
                                                                                            REPLACE(SUBSTRING_INDEX('",CommPaymentAmount,"', '-', -1),',','')       
       END OR '",CommPaymentType,"' < 0) AND 
      (CASE
           WHEN '",MCDExpectedType,"' = 1 THEN CAST(REPLACE(c.Mcd_expacted,',','') as DECIMAL(12,2)) = '",MCDExpectedAmount,"'
           WHEN '",MCDExpectedType,"' = 2 THEN CAST(REPLACE(c.Mcd_expacted,',','') as DECIMAL(12,2)) > '",MCDExpectedAmount,"'
           WHEN '",MCDExpectedType,"' = 3 THEN CAST(REPLACE(c.Mcd_expacted,',','') as DECIMAL(12,2)) >= '",MCDExpectedAmount,"'
           WHEN '",MCDExpectedType,"' = 4 THEN CAST(REPLACE(c.Mcd_expacted,',','') as DECIMAL(12,2)) < '",MCDExpectedAmount,"'
           WHEN '",MCDExpectedType,"' = 5 THEN CAST(REPLACE(c.Mcd_expacted,',','') as DECIMAL(12,2)) <= '",MCDExpectedAmount,"'     
           WHEN '",MCDExpectedType,"' = 6 THEN CAST(REPLACE(c.Mcd_expacted,',','') as DECIMAL(12,2)) BETWEEN REPLACE(SUBSTRING_INDEX('",MCDExpectedAmount,"', '-', 1),',','') AND 
                                                                                                             REPLACE(SUBSTRING_INDEX('",MCDExpectedAmount,"', '-', -1),',','')       
       END OR '",MCDExpectedType,"' < 0) AND 
      (CASE
           WHEN '",NetRevType,"' = 1 THEN CAST(REPLACE(c.net_revenue,',','') as DECIMAL(12,2)) = '",NetRevAmount,"'
           WHEN '",NetRevType,"' = 2 THEN CAST(REPLACE(c.net_revenue,',','') as DECIMAL(12,2)) > '",NetRevAmount,"'
           WHEN '",NetRevType,"' = 3 THEN CAST(REPLACE(c.net_revenue,',','') as DECIMAL(12,2)) >= '",NetRevAmount,"'
           WHEN '",NetRevType,"' = 4 THEN CAST(REPLACE(c.net_revenue,',','') as DECIMAL(12,2)) < '",NetRevAmount,"'
           WHEN '",NetRevType,"' = 5 THEN CAST(REPLACE(c.net_revenue,',','') as DECIMAL(12,2)) <= '",NetRevAmount,"'     
           WHEN '",NetRevType,"' = 6 THEN CAST(REPLACE(c.net_revenue,',','') as DECIMAL(12,2)) BETWEEN REPLACE(SUBSTRING_INDEX('",NetRevAmount,"', '-', 1),',','') AND 
                                                                                                       REPLACE(SUBSTRING_INDEX('",NetRevAmount,"', '-', -1),',','')       
       END OR '",NetRevType,"' < 0) AND 
      (CASE
           WHEN '",PRType,"' = 1 THEN CAST(REPLACE(c.pr,',','') as DECIMAL(12,2)) = '",PRAmount,"'
           WHEN '",PRType,"' = 2 THEN CAST(REPLACE(c.pr,',','') as DECIMAL(12,2)) > '",PRAmount,"'
           WHEN '",PRType,"' = 3 THEN CAST(REPLACE(c.pr,',','') as DECIMAL(12,2)) >= '",PRAmount,"'
           WHEN '",PRType,"' = 4 THEN CAST(REPLACE(c.pr,',','') as DECIMAL(12,2)) < '",PRAmount,"'
           WHEN '",PRType,"' = 5 THEN CAST(REPLACE(c.pr,',','') as DECIMAL(12,2)) <= '",PRAmount,"'     
           WHEN '",PRType,"' = 6 THEN CAST(REPLACE(c.pr,',','') as DECIMAL(12,2)) BETWEEN REPLACE(SUBSTRING_INDEX('",PRAmount,"', '-', 1),',','') AND 
                                                                                          REPLACE(SUBSTRING_INDEX('",PRAmount,"', '-', -1),',','')       
       END OR '",PRType,"' < 0) AND
      (CASE
           WHEN '",AlreadyEnrolled,"' = 1 THEN cd.ae_enrolled = 1
           WHEN '",AlreadyEnrolled,"' = 2 THEN cd.ae_enrolled = 0
           WHEN '",AlreadyEnrolled,"' = 3 THEN (cd.ae_enrolled != 1 OR cd.hospital_has_on_file != 1 OR cd.ae_enrolled IS NULL)
       END OR '",AlreadyEnrolled,"' < 0) AND 
       
      (CASE
           WHEN '",HospOnFile,"' = 1 THEN cd.hospital_has_on_file=1
           WHEN '",HospOnFile,"' = 2 THEN cd.hospital_has_on_file=0
       END OR '",HospOnFile,"' < 0) AND 
      ((STR_TO_DATE(c.Admit_Date,'%m/%d/%Y') >= STR_TO_DATE('",IF(AdmitFrom = -1,'01/01/1999',AdmitFrom),"','%m/%d/%Y')) OR '",AdmitFrom,"' < 0) AND
      ((STR_TO_DATE(c.Admit_Date,'%m/%d/%Y') <= STR_TO_DATE('",IF(AdmitThru = -1,'01/01/2999',AdmitThru),"','%m/%d/%Y')) OR '",AdmitThru,"' < 0) AND
      ((STR_TO_DATE(c.Discharge_Date,'%m/%d/%Y') >= STR_TO_DATE('",IF(DischargeFrom = -1,'01/01/1999',DischargeFrom),"','%m/%d/%Y')) OR '",DischargeFrom,"' < 0) AND
      ((STR_TO_DATE(c.Discharge_Date,'%m/%d/%Y') <= STR_TO_DATE('",IF(DischargeThru = -1,'01/01/2999',DischargeThru),"','%m/%d/%Y')) OR '",DischargeThru,"' < 0) AND
      ((STR_TO_DATE(cd.verif_date,'%m/%d/%Y') >= STR_TO_DATE('",IF(VerifFrom = -1,'01/01/1999',VerifFrom),"','%m/%d/%Y')) OR '",VerifFrom,"' < 0) AND
      ((STR_TO_DATE(cd.verif_date,'%m/%d/%Y') <= STR_TO_DATE('",IF(VerifThru = -1,'01/01/2999',VerifThru),"','%m/%d/%Y')) OR '",VerifThru,"' < 0) AND
      ((STR_TO_DATE(c.claim_date,'%m/%d/%Y') >= STR_TO_DATE('",IF(PaidFrom = -1,'01/01/1999',PaidFrom),"','%m/%d/%Y')) OR '",PaidFrom,"' < 0) AND
      ((STR_TO_DATE(c.claim_date,'%m/%d/%Y') <= STR_TO_DATE('",IF(PaidThru = -1,'01/01/2999',PaidThru),"','%m/%d/%Y')) OR '",PaidThru,"' < 0) AND
       cs.type = 'account' AND
       d.verified != 0 AND
       d.is_archive = 0
Order by STR_TO_DATE(c.Admit_date,'%m/%d/%Y'), c.acct_order DESC
                  ");

PREPARE stmt FROM @sql;
EXECUTE stmt;
      
END$$
DELIMITER ;