DROP PROCEDURE IF EXISTS MoveCasesBillingSystem;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `MoveCasesBillingSystem`(IN `input_groupID` INT)

BEGIN
SET @EncKey = EncKey();
SET @DB = DATABASE();

#DELETE FROM MovedBillingCases;
DELETE FROM FamilyUnit;

select u.column_value
,IFNULL(l.column_value,u.column_value)
,IFNULL(s.value,'')
,a.value as 'ADF'
into 
@NameKey 
,@LastKey
,@MCD_Meta
,@Admit_Date_Format
from upload_settings u
left join upload_settings l on l.column_name = 'LAST_KEY'
left join setting s on s.setting_key = 'MCD_Meta'
left join setting a on a.setting_key = 'Admit_Date_Format'
where u.column_name = 'NAME_KEY';

#UPDATE MovedBillingCases m 
#INNER JOIN track_case tc on m.case_id = tc.case_id
#INNER JOIN case_status cs on tc.status = cs.value
#SET m.added = UNIX_TIMESTAMP()
#WHERE cs.status = 'Application Approved'
#AND tc.created - m.added > 432000;

IF input_groupID > 0 THEN
INSERT IGNORE INTO MovedBillingCases (case_id, added, case_group)
SELECT d.id
,UNIX_TIMESTAMP()
,d.case_group
FROM demographics d 
WHERE d.case_group = input_groupID;

ELSE
INSERT IGNORE INTO MovedBillingCases (case_id, added, case_group)
SELECT d.id
,UNIX_TIMESTAMP()
,d.case_group
FROM demographics d
LEFT JOIN case_status cs on d.case_status = cs.value
WHERE cs.status = 'Application Approved';

INSERT IGNORE INTO MovedBillingCases (case_id, added, case_group)
select distinct n.case_id
,UNIX_TIMESTAMP()
,d.case_group
from notes n
LEFT JOIN note_type nt2 on n.Note_type = nt2.type_id
LEFT JOIN demographics d on n.case_id = d.id
where nt2.type = 'Verified Send Case To Billing';
END IF;

INSERT IGNORE INTO FamilyUnit

SELECT c.case_id
     ,MAX(CASE WHEN o.field_key = 'MEMBER MRN' THEN o.field_value END) AS MRN
     ,MAX(CASE WHEN o.field_key = 'SSN' THEN o.field_value END) AS SSN
     ,MAX(CASE WHEN o.field_key = 'GENDER' THEN o.field_value END) AS Gender
     ,MAX(CASE WHEN o.field_key = 'BIRTH DOB' THEN o.field_value END) AS DOB
     ,MAX(CASE WHEN o.field_key = 'LAST NAME' THEN o.field_value END) AS LastName
     ,MAX(CASE WHEN o.field_key = 'MEDICAID' THEN o.field_value END) AS Medicaid
     ,IFNULL(MAX(CASE WHEN o.field_key = 'PATIENT' THEN o.field_value END),'No') AS Patient
     ,MAX(CASE WHEN o.field_key = 'ENROLLED' THEN o.field_value END) AS Enrolled
     ,'N' as PolicyHolder
     ,UNIX_TIMESTAMP() as created
     ,MAX(CASE WHEN o.field_key = 'FIRST NAME' THEN o.field_value END) as FirstName
     ,MAX(CASE WHEN o.field_key = 'AE' THEN o.field_value END) as AE
     ,MAX(CASE WHEN o.field_key = 'ESI ID' THEN o.field_value END) as ESI_ID
     ,MAX(CASE WHEN o.field_key = 'MCD ID' THEN o.field_value END) as MCD_ID
     ,e.field_value as 'ESI CARRIER'
     ,d.case_group
     ,MAX(CASE WHEN o.field_key = 'EFF' THEN o.field_value END) as ESI_EFF  
     ,MAX(CASE WHEN o.field_key = 'TERM' THEN o.field_value END) as ESI_TERM     
     ,MAX(CASE WHEN o.field_key = 'MCD TERM DATE' THEN o.field_value END) as MCD_TERM  
   FROM MovedBillingCases c
   INNER JOIN case_enrollment_details_current o on c.case_id = o.case_id AND o.field_type = 'familymember' and o.is_deleted = 0
   LEFT JOIN case_enrollment_details_current e on c.case_id = e.case_id AND e.field_type = 'employee' AND e.field_key = 'ESI CARRIER' and e.is_deleted = 0
   LEFT JOIN demographics d on c.case_id = d.id
   where input_groupID > 0
   AND d.case_group = input_groupID
   group by o.familymembernumber,o.case_id

UNION ALL

SELECT c.case_id
     ,MAX(CASE WHEN o.field_key = 'MEMBER MRN' THEN o.field_value END) AS MRN
     ,MAX(CASE WHEN o.field_key = 'SSN' THEN o.field_value END) AS SSN
     ,MAX(CASE WHEN o.field_key = 'GENDER' THEN o.field_value END) AS Gender
     ,MAX(CASE WHEN o.field_key = 'BIRTH DOB' THEN o.field_value END) AS DOB
     ,MAX(CASE WHEN o.field_key = 'LAST NAME' THEN o.field_value END) AS LastName
     ,MAX(CASE WHEN o.field_key = 'MEDICAID' THEN o.field_value END) AS Medicaid
     ,IFNULL(MAX(CASE WHEN o.field_key = 'PATIENT' THEN o.field_value END),'No') AS Patient
     ,MAX(CASE WHEN o.field_key = 'ENROLLED' THEN o.field_value END) AS Enrolled
     ,'N' as PolicyHolder
     ,UNIX_TIMESTAMP() as created
     ,MAX(CASE WHEN o.field_key = 'FIRST NAME' THEN o.field_value END) as FirstName
     ,MAX(CASE WHEN o.field_key = 'AE' THEN o.field_value END) as AE
     ,MAX(CASE WHEN o.field_key = 'ESI ID' THEN o.field_value END) as ESI_ID
     ,MAX(CASE WHEN o.field_key = 'MCD ID' THEN o.field_value END) as MCD_ID
     ,e.field_value as 'ESI CARRIER'
     ,d.case_group
     ,MAX(CASE WHEN o.field_key = 'EFF' THEN o.field_value END) as ESI_EFF  
     ,MAX(CASE WHEN o.field_key = 'TERM' THEN o.field_value END) as ESI_TERM     
     ,MAX(CASE WHEN o.field_key = 'MCD TERM DATE' THEN o.field_value END) as MCD_TERM  
   FROM MovedBillingCases c
   INNER JOIN case_enrollment_details_current o on c.case_id = o.case_id AND o.field_type = 'familymember' and o.is_deleted = 0
   LEFT JOIN case_enrollment_details_current e on c.case_id = e.case_id AND e.field_type = 'employee' AND e.field_key = 'ESI CARRIER' and e.is_deleted = 0
   LEFT JOIN demographics d on c.case_id = d.id
   where input_groupID <= 0
   AND c.added > (UNIX_TIMESTAMP() - 30)
   group by o.familymembernumber,o.case_id;

INSERT IGNORE INTO FamilyUnit

SELECT c.case_id
     ,MAX(CASE WHEN o.field_key = 'MRN' THEN o.field_value END) AS MRN
     ,MAX(CASE WHEN o.field_key = 'SSN' THEN o.field_value END) AS SSN
     ,MAX(CASE WHEN o.field_key = 'GENDER' THEN o.field_value END) AS Gender
     ,MAX(CASE WHEN o.field_key = 'BIRTH DOB' THEN o.field_value END) AS DOB
     ,MAX(CASE WHEN o.field_key = 'LASTNAME' THEN o.field_value END) AS LastName
     ,MAX(CASE WHEN o.field_key = 'MEDICAID' THEN o.field_value END) AS Medicaid
     ,IFNULL(MAX(CASE WHEN o.field_key = 'PATIENT' THEN o.field_value END),'No') AS Patient
     ,MAX(CASE WHEN o.field_key = 'ENROLLED' THEN o.field_value END) AS Enrolled
     ,'Y' as PolicyHolder
     ,UNIX_TIMESTAMP() as created
     ,MAX(CASE WHEN o.field_key = 'FIRSTNAME' THEN o.field_value END) as FirstName
     ,MAX(CASE WHEN o.field_key = 'AE' THEN o.field_value END) as AE
     ,MAX(CASE WHEN o.field_key = 'ESI ID' THEN o.field_value END) as ESI_ID
     ,MAX(CASE WHEN o.field_key = 'MCDID' THEN o.field_value END) as MCD_ID
     ,MAX(CASE WHEN o.field_key = 'ESI CARRIER' THEN o.field_value END) as ESI_CARRIER
     ,d.case_group
     ,MAX(CASE WHEN o.field_key = 'EFF' THEN o.field_value END) as ESI_EFF  
     ,MAX(CASE WHEN o.field_key = 'TERM' THEN o.field_value END) as ESI_TERM     
     ,MAX(CASE WHEN o.field_key = 'MCD TERM DATE' THEN o.field_value END) as MCD_TERM    
  FROM MovedBillingCases c
  LEFT JOIN case_enrollment_details_current o on c.case_id = o.case_id AND o.field_type = 'employee' and o.is_deleted = 0
  LEFT JOIN demographics d on c.case_id = d.id
  where input_groupID > 0 
  AND d.case_group = input_groupID
   group by c.case_id

UNION ALL

SELECT c.case_id
     ,MAX(CASE WHEN o.field_key = 'MRN' THEN o.field_value END) AS MRN
     ,MAX(CASE WHEN o.field_key = 'SSN' THEN o.field_value END) AS SSN
     ,MAX(CASE WHEN o.field_key = 'GENDER' THEN o.field_value END) AS Gender
     ,MAX(CASE WHEN o.field_key = 'BIRTH DOB' THEN o.field_value END) AS DOB
     ,MAX(CASE WHEN o.field_key = 'LASTNAME' THEN o.field_value END) AS LastName
     ,MAX(CASE WHEN o.field_key = 'MEDICAID' THEN o.field_value END) AS Medicaid
     ,IFNULL(MAX(CASE WHEN o.field_key = 'PATIENT' THEN o.field_value END),'No') AS Patient
     ,MAX(CASE WHEN o.field_key = 'ENROLLED' THEN o.field_value END) AS Enrolled
     ,'Y' as PolicyHolder
     ,UNIX_TIMESTAMP() as created
     ,MAX(CASE WHEN o.field_key = 'FIRSTNAME' THEN o.field_value END) as FirstName
     ,MAX(CASE WHEN o.field_key = 'AE' THEN o.field_value END) as AE
     ,MAX(CASE WHEN o.field_key = 'ESI ID' THEN o.field_value END) as ESI_ID
     ,MAX(CASE WHEN o.field_key = 'MCDID' THEN o.field_value END) as MCD_ID
     ,MAX(CASE WHEN o.field_key = 'ESI CARRIER' THEN o.field_value END) as ESI_CARRIER
     ,d.case_group
     ,MAX(CASE WHEN o.field_key = 'EFF' THEN o.field_value END) as ESI_EFF  
     ,MAX(CASE WHEN o.field_key = 'TERM' THEN o.field_value END) as ESI_TERM     
     ,MAX(CASE WHEN o.field_key = 'MCD TERM DATE' THEN o.field_value END) as MCD_TERM    
  FROM MovedBillingCases c
  LEFT JOIN case_enrollment_details_current o on c.case_id = o.case_id AND o.field_type = 'employee' and o.is_deleted = 0
  LEFT JOIN demographics d on c.case_id = d.id
  where input_groupID <= 0 
  AND c.added > (UNIX_TIMESTAMP() - 30)
   group by c.case_id; 

With RankFamily as (
    SELECT *
    ,ROW_NUMBER () OVER(PARTITION BY case_group  ORDER BY MatchMRN DESC, PATIENT DESC,  PolicyHolder ASC, STR_TO_DATE(DOB,"%m/%d/%Y") DESC, MRN ASC) as rownum
    FROM (SELECT f.*
    	  ,IF(AES_DECRYPT(d.MRN,@EncKey)=f.MRN,"Y","N") as MatchMRN
		  FROM FamilyUnit f
   		  LEFT JOIN demographics d on f.case_id = d.id) TempTbl
)

DELETE FROM FamilyUnit
WHERE case_id not in (SELECT case_id 
                      FROM RankFamily
                      WHERE rownum = 1);

SET @sql = NULL;
SET @sql = CONCAT("

With ChargeInfo as (
SELECT c.case_id
,CASE 
	WHEN cp.campus_alias in ('Cohen','LIJ') THEN CONCAT(AES_DECRYPT(d.MRN,@EncKey),'//',DATE_FORMAT(ch.admit_date,'%Y%m%d'))
    ELSE CAST(AES_DECRYPT(ch.charges_ref_number,@EncKey) as CHAR)
 END as Charges_ref_num
,CAST(AES_DECRYPT(ch.Total_Acc_Bal,@EncKey) as CHAR) as Total_Acc_Bal
,CAST(AES_DECRYPT(ch.Account_Class,@EncKey) as CHAR) as Account_Class
,IFNULL(ch.admit_date,0) as admit_date
,IFNULL(ch.discharge_date,0) as discharge_date
,IF(cp.campus_alias <> '',
    cp.campus_alias,
    cp.campus_name) as Campus
,AES_DECRYPT(d.MRN, @EncKey) as MRN
,ch.serial_number
FROM MovedBillingCases c
LEFT JOIN demographics d on c.case_id = d.id
INNER JOIN charges ch on c.case_id = ch.case_id
LEFT JOIN campuses cp on ch.campus_id = cp.id
WHERE CONCAT(ch.created_at,ch.charges_ref_number) in (SELECT CONCAT(MAX(ch2.created_at),ch2.charges_ref_number)
                                                      FROM charges ch2
                                                      WHERE ch.case_id = ch2.case_id
  				                                      GROUP BY CASE 
																WHEN cp.campus_alias in ('Cohen','LIJ') THEN CONCAT(AES_DECRYPT(d.MRN,'",@EncKey,"'),DATE_FORMAT(ch2.admit_date,'%Y%m%d'))
																ELSE CAST(AES_DECRYPT(ch2.charges_ref_number,'",@EncKey,"') as CHAR)
													  END)
),

SignatureInfo as (
select IFNULL(d.id,s.case_id) as case_id
,s.user_id
,FROM_UNIXTIME(s.created,'%Y-%m-%d') as created
,LAST_DAY(FROM_UNIXTIME(s.created,'%Y-%m-%d')) as LDOM
,AES_DECRYPT(d.MRN,'",@EncKey,"')
,concat(setting.value,'.',s.case_group_id) as SignatureID
from (select * 
      from signatures 
      group by IF(case_group_id is NULL 
                  OR case_group_id='', CONCAT('CG- ',case_id), case_group_id)) as s
LEFT JOIN demographics d on s.case_group_id = d.case_group
LEFT JOIN setting on setting_key = 'HOSPITAL_NAME'
where user_id IS NOT NULL 
and user_id IN (select id 
				from admin_user 
				where user_type !=1 
				and username not in ('shivam_support','revmax_superadmin')
				)
and s.case_id NOT IN(select id from demographics where AES_DECRYPT(MRN,'",@EncKey,"') LIKE '0-%')
and YEAR(FROM_UNIXTIME(s.created,'%Y-%m-%d')) >= 2023
),

AdmitDates as (
select *
,ROW_NUMBER () OVER(PARTITION BY case_id ORDER BY created_at desc) as rownum
from admit_dates
),

LinkedInfo as (
SELECT f.case_id
    ,f.MRN
    ,f.SSN
    ,f.Gender
    ,f.DOB
    ,f.LASTNAME
    ,f.Medicaid
    ,f.case_group
    ,IF(AES_DECRYPT(d.MRN,'",@EncKey,"')=f.MRN,'Y','N') as MatchMRN
    ,IFNULL(f.patient, 
            MAX(CASE
    	 	WHEN f.MRN = AES_DECRYPT(d.MRN,'",@EncKey,"') THEN 'Yes'
            WHEN @NameKey = @LastKey AND CAST(UPPER(CONCAT(f.LASTNAME,f.FIRSTNAME)) AS CHAR) = UPPER(CONCAT(TRIM(SUBSTRING_INDEX(CAST(AES_DECRYPT(d.",@NameKey,",'",@EncKey,"') AS CHAR),',',1)),TRIM(SUBSTRING_INDEX(CAST(AES_DECRYPT(d.",@NameKey,",'",@EncKey,"') AS CHAR),',',-1)))) THEN 'Yes'
    	 	WHEN CAST(UPPER(CONCAT(f.LASTNAME,f.FIRSTNAME)) AS CHAR) = UPPER(CONCAT(SUBSTRING_INDEX(CAST(AES_DECRYPT(d.",@LastKey,",'",@EncKey,"') AS CHAR),'(',1),SUBSTRING_INDEX(CAST(AES_DECRYPT(d.",@NameKey,",'",@EncKey,"') AS CHAR),'(',1))) THEN 'Yes'
    	 	ELSE 'No'
    	 END)) as 'Patient'
    ,f.Enrolled
    ,f.PolicyHolder
    ,f.created
    ,f.FIRSTNAME
    ,f.AE
    ,f.ESI_ID
    ,f.MCD_ID
    ,f.ESI_CARRIER
    ,f.ESI_EFF
    ,f.ESI_TERM
    ,f.MCD_TERM
    ,d4.id
,MAX(CASE
    WHEN f.MRN = AES_DECRYPT(d3.MRN,'",@EncKey,"') THEN l1.linked_case_id
    WHEN @NameKey = @LastKey AND CAST(UPPER(CONCAT(f.LASTNAME,f.FIRSTNAME)) AS CHAR) = UPPER(CONCAT(TRIM(SUBSTRING_INDEX(CAST(AES_DECRYPT(d3.",@NameKey,",'",@EncKey,"') AS CHAR),',',1)),TRIM(SUBSTRING_INDEX(CAST(AES_DECRYPT(d3.",@NameKey,",'",@EncKey,"') AS CHAR),',',-1)))) THEN l1.linked_case_id
    WHEN CAST(UPPER(CONCAT(f.LASTNAME,f.FIRSTNAME)) AS CHAR) = UPPER(CONCAT(SUBSTRING_INDEX(CAST(AES_DECRYPT(d3.",@LastKey,",'",@EncKey,"') AS CHAR),'(',1),SUBSTRING_INDEX(CAST(AES_DECRYPT(d3.",@NameKey,",'",@EncKey,"') AS CHAR),'(',1))) THEN l1.linked_case_id
    WHEN f.MRN = AES_DECRYPT(d4.MRN,'",@EncKey,"') THEN l2.case_id
    WHEN @NameKey = @LastKey AND CAST(UPPER(CONCAT(f.LASTNAME,f.FIRSTNAME)) AS CHAR) = UPPER(CONCAT(TRIM(SUBSTRING_INDEX(CAST(AES_DECRYPT(d4.",@NameKey,",'",@EncKey,"') AS CHAR),',',1)),TRIM(SUBSTRING_INDEX(CAST(AES_DECRYPT(d4.",@NameKey,",'",@EncKey,"') AS CHAR),',',-1)))) THEN l2.case_id
    WHEN CAST(UPPER(CONCAT(f.LASTNAME,f.FIRSTNAME)) AS CHAR) = UPPER(CONCAT(SUBSTRING_INDEX(CAST(AES_DECRYPT(d4.",@LastKey,",'",@EncKey,"') AS CHAR),'(',1),SUBSTRING_INDEX(CAST(AES_DECRYPT(d4.",@NameKey,",'",@EncKey,"') AS CHAR),'(',1))) THEN l2.case_id
 ELSE NULL
 END) as linked_RVCase
,MAX(CASE
    WHEN f.MRN = AES_DECRYPT(d3.MRN,'",@EncKey,"') THEN CAST(SUBSTRING_INDEX(AES_DECRYPT(dm5.column_value,'",@EncKey,"'), '<', 1) as CHAR)
    WHEN @NameKey = @LastKey AND CAST(UPPER(CONCAT(f.LASTNAME,f.FIRSTNAME)) AS CHAR) = UPPER(CONCAT(TRIM(SUBSTRING_INDEX(CAST(AES_DECRYPT(d3.",@NameKey,",'",@EncKey,"') AS CHAR),',',1)),TRIM(SUBSTRING_INDEX(CAST(AES_DECRYPT(d3.",@NameKey,",'",@EncKey,"') AS CHAR),',',-1)))) THEN CAST(SUBSTRING_INDEX(AES_DECRYPT(dm5.column_value,'",@EncKey,"'), '<', 1) as CHAR)
    WHEN CAST(UPPER(CONCAT(f.LASTNAME,f.FIRSTNAME)) AS CHAR) = UPPER(CONCAT(SUBSTRING_INDEX(CAST(AES_DECRYPT(d3.",@LastKey,",'",@EncKey,"') AS CHAR),'(',1),SUBSTRING_INDEX(CAST(AES_DECRYPT(d3.",@NameKey,",'",@EncKey,"') AS CHAR),'(',1))) THEN CAST(SUBSTRING_INDEX(AES_DECRYPT(dm5.column_value,'",@EncKey,"'), '<', 1) as CHAR)
    WHEN f.MRN = AES_DECRYPT(d4.MRN,'",@EncKey,"') THEN CAST(AES_DECRYPT(dm6.column_value,'",@EncKey,"') as CHAR)
    WHEN @NameKey = @LastKey AND CAST(UPPER(CONCAT(f.LASTNAME,f.FIRSTNAME)) AS CHAR) = UPPER(CONCAT(TRIM(SUBSTRING_INDEX(CAST(AES_DECRYPT(d4.",@NameKey,",'",@EncKey,"') AS CHAR),',',1)),TRIM(SUBSTRING_INDEX(CAST(AES_DECRYPT(d4.",@NameKey,",'",@EncKey,"') AS CHAR),',',-1)))) THEN CAST(AES_DECRYPT(dm6.column_value,'",@EncKey,"') as CHAR)
    WHEN CAST(UPPER(CONCAT(f.LASTNAME,f.FIRSTNAME)) AS CHAR) = UPPER(CONCAT(SUBSTRING_INDEX(CAST(AES_DECRYPT(d4.",@LastKey,",'",@EncKey,"') AS CHAR),'(',1),SUBSTRING_INDEX(CAST(AES_DECRYPT(d4.",@NameKey,",'",@EncKey,"') AS CHAR),'(',1))) THEN CAST(AES_DECRYPT(dm6.column_value,'",@EncKey,"') as CHAR)
 ELSE NULL
 END) as linked_SecondaryIns
FROM FamilyUnit f
LEFT JOIN demographics d on f.case_id = d.id
LEFT JOIN linked_case l1 on f.case_id = l1.case_id
LEFT JOIN linked_case l2 on f.case_id = l2.linked_case_id
LEFT JOIN demographics d3 on l1.linked_case_id = d3.id
LEFT JOIN demographics d4 on l2.case_id = d4.id 
LEFT JOIN demographic_meta dm5 on l1.linked_case_id = dm5.case_id and dm5.column_name = '",@MCD_Meta,"'
LEFT JOIN demographic_meta dm6 on l2.case_id = dm6.case_id and dm6.column_name = '",@MCD_Meta,"'
GROUP BY case_id,MRN,SSN,DOB,FIRSTNAME
    ),
                  
EmployerInfo as (  
select case_id
    ,AES_DECRYPT(EmpName,'",@EncKey,"') as EmpName
    ,rownum
FROM (
SELECT et.case_id
    ,en.EmpName
,ROW_NUMBER () OVER(PARTITION BY et.case_id ORDER BY et.created DESC) as rownum
FROM FamilyUnit f
INNER JOIN employers_tab et on f.case_id = et.case_id
INNER JOIN employer_new en on et.employer_id = en.id) INNERT
where rownum = 1
    )

select CONCAT(InnerTable.case_id,'-',InnerRow) as case_id
,CASE 
	WHEN linked_RVCase IS NOT NULL THEN linked_RVCase
    WHEN InnerRow = 1 THEN InnerTable.case_id
    WHEN Patient = 'Y' AND InnerTable.MRN = DemoMRN THEN InnerTable.case_id
END as OriginalCase_ID
,CASE 
	WHEN InnerTable.MRN in ('NONE','None') THEN 'none'
    WHEN InnerTable.MRN in ('n/a','N/A','N/a') THEN 'none'
	WHEN InnerTable.MRN IS NOT NULL THEN InnerTable.MRN
    WHEN Patient = 'Y' AND InnerTable.MRN = DemoMRN THEN DemoMRN
    WHEN Patient = 'Y' AND CAST(CONCAT(LastName,FirstName) as CHAR) = SUBSTRING_INDEX(BioName, '(', 1) THEN DemoMRN
    WHEN linked_RVCase IS NOT NULL THEN linked_DemoMRN
    ELSE 'none'
END as MRN
,SSN
,GENDER
,DOB
,TRIM(LastName) as LastName
,TRIM(FirstName) as FirstName
,MCD_ID as Medicaid
,Patient
,Enrolled
,PolicyHolder
,esi_verification_date
,Policy_Holder
,PH_DOB
,PH_SSN
,PH_GENDER
,PH_ENROLLED
,PH_MRN
,PH_MEDICAID
,ESI_DATE
,New_Carrier
,Policy
,CASE 
	WHEN linked_RVCase IS NOT NULL THEN linked_SecondaryIns
    WHEN Patient = 'Y' and InnerTable.MRN = DemoMrn THEN SecondaryIns
    WHEN Patient = 'Y' and SUBSTRING_INDEX(BioName, '(', 1) = CAST(FullSTempName AS CHAR) THEN SecondaryIns
    WHEN UPPER(InnerTable.MRN) in ('SELF PAY', 'SELFPAY', '-') THEN NULL
    WHEN linked_RVCase IS NOT NULL THEN linked_SecondaryIns
END as SecondaryIns
,CommercialPlanYear
,EmployerName
,linked_RVCase
,IF(@DB = 'Mercy_Health_AR', CONCAT(GroupID, 'AR'),GroupID) as GroupID
,c1.charges_ref_num as AcctNum
,c1.Total_Acc_Bal as Charges
,CASE
	WHEN c1.admit_date = 0 THEN NULL
	ELSE DATE_FORMAT(STR_TO_DATE(COALESCE(c1.admit_date, AES_DECRYPT(ad.admit_date,@EncKey)),'",@Admit_Date_Format,"'),'%m/%d/%Y')
END as Admit_Date
,DATE_FORMAT(STR_TO_DATE(
  CASE 
	WHEN c1.discharge_date = 0 THEN NULL
	ELSE c1.discharge_date
END,'",@Admit_Date_Format,"'),'%m/%d/%Y') as Discharge_Date
,CaseOwner
,FeedCategory
,FeedPtType
,CaseAddedDate
,COALESCE(c1.Campus, InnerTable.Campus) as Campus
,NotInvoicingPt
,HospitalNotified
,SignatureDate
,COALESCE(c1.Account_Class,SvcType) as SvcType
,ESI_TERM
,MCD_TERM
,EmployerAddress
,EmployerCity
,EmployerState
,EmployerZip
,EmployerType
,State
,serial_number
,product_type
from (
SELECT f.case_id
,ROW_NUMBER () OVER(PARTITION BY f.case_id  ORDER BY MatchMRN DESC, f.PATIENT DESC,  f.PolicyHolder ASC, STR_TO_DATE(f.DOB,'"'%m/%d/%Y'"') DESC, f.MRN ASC) as InnerRow   
,TRIM(f.MRN) as MRN
,TRIM(AES_DECRYPT(d.MRN,'",@EncKey,"')) as DemoMRN
,TRIM(AES_DECRYPT(d2.MRN,'",@EncKey,"')) as linked_DemoMRN
,CONCAT(TRIM(f.LastName),TRIM(f.FirstName)) as FullSTempName
,CASE
     WHEN @NameKey = @LastKey THEN CAST(CONCAT(TRIM(SUBSTRING_INDEX(AES_DECRYPT(d.",@NameKey,",'",@EncKey,"'),',',1)),TRIM(SUBSTRING_INDEX(AES_DECRYPT(d.",@NameKey,",'",@EncKey,"'),',',-1))) as CHAR)
     ELSE CAST(CONCAT(TRIM(AES_DECRYPT(d.",@LastKey,",'",@EncKey,"')),TRIM(AES_DECRYPT(d.",@NameKey,",'",@EncKey,"'))) as CHAR)
END as BioName
,TRIM(REGEXP_SUBSTR(CAST(f.SSN as CHAR),'([[:digit:]]|[-]|[:space:])+')) as SSN
,f.GENDER
,TRIM(f.DOB) as DOB
,CASE
    WHEN CAST(f.LastName AS BINARY) = UPPER(f.LastName) THEN CONCAT(LEFT(f.LastName,1),LOWER(RIGHT(f.LastName,LENGTH(f.LastName)-1)))
    WHEN CAST(f.LastName AS BINARY) = LOWER(f.LastName) THEN CONCAT(UPPER(LEFT(f.LastName,1)),RIGHT(f.LastName,LENGTH(f.LastName)-1))
    ELSE f.LastName 
 END as LastName
,CASE
    WHEN CAST(f.FirstName AS BINARY) = UPPER(f.FirstName) THEN CONCAT(LEFT(f.FirstName,1),LOWER(RIGHT(f.FirstName,LENGTH(f.FirstName)-1)))
    WHEN CAST(f.FirstName AS BINARY) = LOWER(f.FirstName) THEN CONCAT(UPPER(LEFT(f.FirstName,1)),RIGHT(f.FirstName,LENGTH(f.FirstName)-1))
    ELSE f.FirstName 
 END as FirstName   
,f.MCD_ID
,f.linked_SecondaryIns
,DATE_FORMAT(d.date_add,'%m/%d/%Y') as CaseAddedDate
,au.username as CaseOwner
,CASE
	WHEN dcn.category_id = 1 THEN 'NICU'
	WHEN dcn.category_id = 2 THEN 'PICU'
	ELSE 'ADULT'
END as FeedCategory
,p.patient_type as FeedPtType
,CASE 
	WHEN f.PATIENT in ('No','no') THEN 'N'
    WHEN f.Patient in ('Yes','yes') THEN 'Y'
    ELSE NULL
END as PATIENT
,CASE 
	WHEN f.AE in ('No','no') THEN 'N'
    WHEN f.AE in ('Yes','yes') THEN 'Y'
    ELSE NULL
END as ENROLLED
,f.PolicyHolder
,IFNULL(cvd.esi_verification_date,DATE_FORMAT(NOW(),'%m/%d/%Y')) as esi_verification_date
,CONCAT(CASE
   		 WHEN CAST(fn.field_value AS BINARY) = UPPER(fn.field_value) THEN CONCAT(LEFT(fn.field_value,1),LOWER(RIGHT(fn.field_value,LENGTH(fn.field_value)-1)))
   		 WHEN CAST(fn.field_value AS BINARY) = LOWER(fn.field_value) THEN CONCAT(UPPER(LEFT(fn.field_value,1)),RIGHT(fn.field_value,LENGTH(fn.field_value)-1))
    	 ELSE fn.field_value 
        END,
        ' '
        ,CASE
   		 WHEN CAST(ln.field_value AS BINARY) = UPPER(ln.field_value) THEN CONCAT(LEFT(ln.field_value,1),LOWER(RIGHT(ln.field_value,LENGTH(ln.field_value)-1)))
    	 WHEN CAST(ln.field_value AS BINARY) = LOWER(ln.field_value) THEN CONCAT(UPPER(LEFT(ln.field_value,1)),RIGHT(ln.field_value,LENGTH(ln.field_value)-1))
    	 ELSE ln.field_value
        END) as Policy_Holder
,db.field_value as PH_DOB
,REGEXP_SUBSTR(CAST(ssn.field_value as CHAR),'([[:digit:]]|[-]|[:space:])+') as PH_SSN
,gd.field_value as PH_GENDER
,CASE 
	WHEN pt.field_value in ('No','no') THEN 'N'
    WHEN pt.field_value in ('Yes','yes') THEN 'Y'
    ELSE NULL
END as PH_PATIENT
,CASE 
	WHEN ae.field_value in ('No','no') THEN 'N'
    WHEN ae.field_value in ('Yes','yes') THEN 'Y'
    ELSE NULL
END as PH_ENROLLED
,TRIM(mn.field_value) as PH_MRN
,TRIM(md.field_value) as PH_MEDICAID
,IFNULL(f.ESI_EFF, ed.field_value) as ESI_DATE
,TRIM(f.ESI_CARRIER) as New_Carrier
,TRIM(f.ESI_ID) as Policy
,IFNULL(CAST(SUBSTRING_INDEX(AES_DECRYPT(dm.column_value,'",@EncKey,"'), '<', 1) as CHAR),'Medicaid') as SecondaryIns
,CAST(AES_DECRYPT(d.commercial_insurance_plan_year,'",@EncKey,"') as CHAR) as CommercialPlanYear
,CAST(IFNULL(nm.field_value,e.EmpName) as Char) as EmployerName
,f.linked_RVCase
,f.case_group as GroupID
,IF(c.campus_alias <> '',c.campus_alias,IFNULL(c.campus_name,'-')) as Campus
,CASE 
    WHEN cvd.not_invoicing_patient = 1 THEN 'Y'
    ELSE 'N'
END as NotInvoicingPt
,CASE
    WHEN cvd.hospital_notified = 1 THEN 'Y'
    ELSE 'N'
END as HospitalNotified
,DATE_FORMAT(si.created,'%m/%d/%Y') as SignatureDate
,CAST(AES_DECRYPT(dm2.column_value,'",@EncKey,"') as Char) as SvcType
,f.ESI_TERM
,f.MCD_TERM
,ea.field_value as EmployerAddress
,ec.field_value as EmployerCity
,es.field_value as EmployerState
,ez.field_value as EmployerZip
,CASE
	WHEN ep.field_value = 'No' THEN 'Full Time'
	WHEN ep.field_value = 'Yes' THEN 'Part Time'
END as EmployerType
,stt.field_value as State
,sop.product_type
FROM LinkedInfo f
LEFT JOIN demographics d on f.case_id = d.id
LEFT JOIN admin_user au on d.case_owner = au.id
LEFT JOIN campuses c on d.campus=c.id
LEFT JOIN demographics d2 on f.linked_RVCase = d2.id
LEFT JOIN SignatureInfo si on f.case_id = si.case_id
LEFT JOIN (select * from demographics_category group by case_id) dcn on dcn.case_id = f.case_id
LEFT JOIN EmployerInfo e on f.case_id = e.case_id
LEFT JOIN case_enrollment_details_current ae on f.case_id = ae.case_id AND ae.field_type = 'employee' AND ae.field_key = 'AE' AND ae.is_deleted = 0
LEFT JOIN case_enrollment_details_current pt on f.case_id = pt.case_id AND pt.field_type = 'employee' AND pt.field_key = 'PATIENT' AND pt.is_deleted = 0
LEFT JOIN case_enrollment_details_current fn on f.case_id = fn.case_id AND fn.field_type = 'employee' AND fn.field_key = 'FIRSTNAME' AND fn.is_deleted = 0   
LEFT JOIN case_enrollment_details_current ln on f.case_id = ln.case_id AND ln.field_type = 'employee' AND ln.field_key = 'LASTNAME' AND ln.is_deleted = 0
LEFT JOIN case_enrollment_details_current db on f.case_id = db.case_id AND db.field_type = 'employee' AND db.field_key = 'DOB' AND db.is_deleted = 0
LEFT JOIN case_enrollment_details_current ssn on f.case_id = ssn.case_id AND ssn.field_type = 'employee' AND ssn.field_key = 'SSN' AND ssn.is_deleted = 0
LEFT JOIN case_enrollment_details_current gd on f.case_id = gd.case_id AND gd.field_type = 'employee' AND gd.field_key = 'GENDER' AND gd.is_deleted = 0
LEFT JOIN case_enrollment_details_current mn on f.case_id = mn.case_id AND mn.field_type = 'employee' AND mn.field_key = 'MRN' AND mn.is_deleted = 0
LEFT JOIN case_enrollment_details_current md on f.case_id = md.case_id AND md.field_type = 'employee' AND md.field_key = 'MCDID' AND md.is_deleted = 0
LEFT JOIN case_enrollment_details_current ed on f.case_id = ed.case_id AND ed.field_type = 'employer' AND ed.field_key = 'ESI DATE' AND ed.is_deleted = 0
LEFT JOIN case_enrollment_details_current nm on f.case_id = nm.case_id AND nm.field_type = 'employer' AND nm.field_key = 'NAME' AND nm.is_deleted = 0
LEFT JOIN case_enrollment_details_current ea on f.case_id = ea.case_id AND ea.field_type = 'employer' AND ea.field_key = 'ADDRESS' AND ea.is_deleted = 0
LEFT JOIN case_enrollment_details_current ec on f.case_id = ec.case_id AND ec.field_type = 'employer' AND ec.field_key = 'CITY' AND ec.is_deleted = 0              
LEFT JOIN case_enrollment_details_current es on f.case_id = es.case_id AND es.field_type = 'employer' AND es.field_key = 'STATE' AND es.is_deleted = 0                  
LEFT JOIN case_enrollment_details_current ez on f.case_id = ez.case_id AND ez.field_type = 'employer' AND ez.field_key = 'ZIP' AND ez.is_deleted = 0 
LEFT JOIN case_enrollment_details_current ep on f.case_id = ep.case_id AND ep.field_type = 'employer' AND ep.field_key = 'PART TIME OR FULL TIME' AND ep.is_deleted = 0 
LEFT JOIN case_enrollment_details_current stt on f.case_id = stt.case_id AND stt.field_type = 'employee' AND stt.field_key = 'STATE' AND stt.is_deleted = 0
LEFT JOIN demographic_meta dm on f.case_id = dm.case_id and dm.column_name = '",@MCD_Meta,"'
LEFT JOIN demographic_meta dm2 on d.id = dm2.case_id and dm2.column_name = 'Account_Class'
LEFT JOIN case_verification_details cvd on f.case_id = cvd.case_id and cvd.data_from = 'enable'
LEFT JOIN state_operations sop on f.case_id = sop.case_id and sop.is_default = 1
LEFT JOIN patient_activity p on f.case_id = p.case_id and p.id = (SELECT max(pa.id)
                                                                  FROM patient_activity pa
                                                                  WHERE p.case_id = pa.case_id)) AS InnerTable
LEFT JOIN ChargeInfo c1 on IFNULL(InnerTable.linked_DemoMRN, InnerTable.MRN) = c1.MRN
LEFT JOIN AdmitDates ad on InnerTable.case_id = ad.case_id and ad.rownum = 1
WHERE InnerTable.case_id IS NOT NULL
ORDER BY CONCAT(InnerTable.case_id,'-',InnerRow);
");

PREPARE stmt FROM @sql;
EXECUTE stmt;
END$$    
DELIMITER ;