DROP PROCEDURE IF EXISTS InFlightCases;

DELIMITER $$ 

CREATE PROCEDURE InFlightCases(Admin_id INT, Days INT)
BEGIN

DECLARE ENCKEY VARCHAR(100);

SET SESSION group_concat_max_len = 1000000;

SET ENCKEY = EncKey();
SET @SQL_ = NULL;

SET @SQL_ = CONCAT("

WITH 
Assign_user AS (
    SELECT cau.case_id,
           cau.user_id,
           cau.created,
           AES_DECRYPT(au.name, '", ENCKEY, "') AS name,
     ROW_NUMBER () OVER(PARTITION BY cau.case_id ORDER BY cau.id desc) as rownum
    FROM cases_assigned_users cau
    LEFT JOIN admin_user au ON au.id = cau.user_id
),
                   
AdmitDates AS (
    SELECT case_id,
           admit_date,
           ROW_NUMBER() OVER (PARTITION BY case_id ORDER BY id DESC) AS rownum
    FROM admit_dates
),
                   
Last_note_date AS (
    SELECT case_id,
           MAX(NoteDate) AS Last_note_date
    FROM notes
    GROUP BY case_id
),
                   
RankedEmployers AS (
    SELECT * FROM (
        SELECT et.case_id,
               AES_DECRYPT(en.EmpName, '", ENCKEY, "') AS Employer,
               ROW_NUMBER() OVER (PARTITION BY et.case_id ORDER BY et.created DESC) AS rownum
        FROM employers_tab et
        LEFT JOIN employer_new en ON en.id = et.employer_id
    ) AS FirstTable
    WHERE rownum = 1
)


SELECT 
    d.id AS case_id,
    hospital.value AS 'Hospital',
    campuses.campus_name AS CAMPUS,
    AES_DECRYPT(d.MRN, '", ENCKEY, "') AS MRN,
    CASE
        WHEN d.Total_Acc_Bal < 100000 THEN '< 100,000'
        WHEN d.Total_Acc_Bal BETWEEN 100000 AND 300000 THEN '100,000 - 300,000'
        WHEN d.Total_Acc_Bal BETWEEN 300000 AND 500000 THEN '300,000 - 500,000'
        WHEN d.Total_Acc_Bal BETWEEN 500000 AND 1000000 THEN '500,000 - 1M'
        WHEN d.Total_Acc_Bal > 1000000 THEN '1M+'
        ELSE 'Unknown'
    END AS ChargeRange,
    d.Total_Acc_Bal AS 'Total Charges',
    L.Last_note_date AS 'Last Note Date',
    (DATEDIFF(CURDATE(), L.Last_note_date) - (WEEK(CURDATE()) - WEEK(L.Last_note_date)) * 2 - (WEEKDAY(L.Last_note_date) = 6) - (WEEKDAY(CURDATE()) = 5)) AS 'Days_since_last_Touched',
    cc.name AS 'Cases Categories',
    AES_DECRYPT(ad.admit_date, '", ENCKEY, "') AS Admit_Date,
    AES_DECRYPT(d.DischargeDate, '", ENCKEY, "') AS DischargeDate,
    d.date_add AS 'Added On',
    IFNULL(cec.field_value, re.Employer) AS Employer,
    IFNULL(AES_DECRYPT(admin_user.name, '", ENCKEY, "'),au.name) AS 'Assigned To',
    cs.status AS 'Current Status',
    AES_DECRYPT(admin_user.name, '", ENCKEY, "') AS CaseOwner
FROM demographics d 
LEFT JOIN case_enrollment_details_current cec ON d.id = cec.case_id AND cec.field_type = 'employer' AND cec.field_key = 'NAME' AND cec.is_deleted = 0
LEFT JOIN case_status cs ON d.case_status = cs.value
LEFT JOIN setting hospital ON hospital.setting_key = 'HOSPITAL_NAME'
LEFT JOIN Last_note_date L ON L.case_id = d.id
LEFT JOIN admin_user ON admin_user.id = d.case_owner
LEFT JOIN campuses ON campuses.id = d.campus
LEFT JOIN demographics_category dc ON dc.case_id = d.id
LEFT JOIN cases_categories cc ON cc.id = dc.category_id
LEFT JOIN Assign_user au ON au.case_id = d.id and au.rownum = 1
LEFT JOIN RankedEmployers re ON re.case_id = d.id
LEFT JOIN AdmitDates ad ON d.id = ad.case_id AND ad.rownum = 1
WHERE AES_DECRYPT(d.MRN, '", ENCKEY, "') NOT LIKE '%0-%'
  AND (DATEDIFF(CURDATE(), L.Last_note_date) - (WEEK(CURDATE()) - WEEK(L.Last_note_date)) * 2 - (WEEKDAY(L.Last_note_date) = 6) - (WEEKDAY(CURDATE()) = 5)) > ", Days, "
  AND (hospital.value = 'Phoebe' OR campuses.campus_isactive = 1)
  AND (", Admin_id, " < 0 OR admin_user.id = ", Admin_id, ")
");

PREPARE stmt FROM @SQL_;
EXECUTE stmt;

END$$
DELIMITER ;