DROP PROCEDURE IF EXISTS Approval_Dash;

DELIMITER $$    
CREATE PROCEDURE Approval_Dash()
BEGIN

SET @EncKey = EncKey();
SET SESSION group_concat_max_len = 1000000;         

SET @sql = NULL;
SET @sql = CONCAT("

WITH Cohort AS (
  SELECT t.case_id
         ,t.created
         ,NULL as Override
  FROM ( SELECT *
    FROM track_case t
    WHERE t.archive_status = 0
      AND t.id = (
        SELECT MIN(t2.id)
        FROM track_case t2
        WHERE t.case_id = t2.case_id
          AND t.status = t2.status
          AND t2.archive_status = 0 )) t
LEFT JOIN demographics d on t.case_id = d.id
LEFT JOIN case_status c on t.status = c.value
WHERE c.status = 'Application Approved'
AND AES_DECRYPT(d.MRN,'",@EncKey,"') != "'"0-"'"
#AND YEAR(FROM_UNIXTIME(t.created,"'"%Y-%m-%d"'")) >= 2023

UNION ALL

SELECT n.case_id
#,ROUND(UNIX_TIMESTAMP(NoteDate),0)
,IFNULL(UNIX_TIMESTAMP(STR_TO_DATE(REGEXP_SUBSTR(AES_DECRYPT(n.Note,'",@EncKey,"'), '[0-9]{1,2}/[0-9]{1,2}/[0-9]{4}'),'%m/%d/%Y')),
        ROUND(UNIX_TIMESTAMP(NoteDate),0)) as NoteDate
,REGEXP_SUBSTR(REPLACE(AES_DECRYPT(n.Note,'",@EncKey,"'),',',''), "'"[0-9]+"'") as Override
FROM notes n
INNER JOIN note_type nt on n.note_type = nt.type_id and nt.type = 'Approval'
),

Overrides as (
SELECT distinct n.case_id
,REGEXP_SUBSTR(REPLACE(AES_DECRYPT(n.Note,'",@EncKey,"'),',',''), '[0-9]+') as Override
FROM notes n
INNER JOIN note_type nt on n.note_type = nt.type_id and nt.type = 'Approval'
),

Track_Sig as (
SELECT distinct d.id as case_id
,s.created
,s.case_group_id
,LAST_DAY(FROM_UNIXTIME(s.created,"'"%Y-%m-%d"'")) as LDOM
from track_case t
LEFT JOIN case_status c on t.status = c.value
INNER JOIN signatures s on t.case_id = s.case_id 
                      and s.id = (SELECT min(id)
							      FROM signatures s2
			                      WHERE s.case_id = s2.case_id)
LEFT JOIN demographics d on s.case_group_id = d.case_group
where c.status = 'Application Approved'
and YEAR(FROM_UNIXTIME(t.created,'%Y-%m-%d')) >= 2023
),            

CaseEnrollmentRank as (
SELECT ce.*
,ROW_NUMBER () OVER(PARTITION BY case_group ORDER BY id asc) as rownum
,d.case_group
FROM case_enrollment ce
LEFT JOIN demographics d on ce.case_id = d.id
),

EmployerRank as (
SELECT e.*
,ROW_NUMBER () OVER(PARTITION BY case_id ORDER BY created asc) as rownum
FROM employers_tab e
),   

BAS as
(SELECT d.id 
,c.bas_assigned, 
AES_DECRYPT(a.name,'",@EncKey,"') AS Bas_Assigned_Name
FROM demographics d
LEFT JOIN CaseEnrollmentRank c on d.case_group = c.case_group and c.rownum = 1
LEFT JOIN admin_user a ON a.id = c.bas_assigned
),

CaseDetailsRanks as (
SELECT case_id
,CASE
     WHEN not_invoicing_patient = 0 THEN 'Yes'
     ELSE 'No'
END as Invoicing
,esi_verification_date
,sum(charges) as charges
,ROW_NUMBER () OVER(PARTITION BY case_id ORDER BY data_from ASC, id DESC) as rownum
FROM case_verification_details
group by case_id,data_from
)

SELECT distinct rvp.value as 'RVP'
    ,hospital.value as 'Hospital'
    ,region.value as 'Region'
    ,CONCAT(t.case_id,'.',hospital.value) as case_id
    ,AES_DECRYPT(d.MRN,'",@EncKey,"') as MRN
    ,CAST(AES_DECRYPT(a.name,'",@EncKey,"') as CHAR) as PatientHelper
    ,FROM_UNIXTIME(s.created,"'"%Y-%m-%d"'") as SignatureDate
    ,MONTH(FROM_UNIXTIME(s.created,"'"%Y-%m-%d"'")) as SignatureMonth
    ,YEAR(FROM_UNIXTIME(s.created,"'"%Y-%m-%d"'")) as SignatureYear
    ,FROM_UNIXTIME(t.created,"'"%Y-%m-%d"'") as ApprovalDate
    ,MONTH(FROM_UNIXTIME(t.created,"'"%Y-%m-%d"'")) as ApprovalMonth
    ,YEAR(FROM_UNIXTIME(t.created,"'"%Y-%m-%d"'")) as ApprovalYear
    ,d.Total_Acc_Bal AS TotalCharges
    ,CASE
    	WHEN t.Override IS NOT NULL THEN t.Override
    	WHEN o.Override IS NOT NULL THEN cvd.charges - o.Override
    	ELSE cvd.charges
    END as CapturedCharges
    ,d.max_case_rank as CaseRank
    ,CASE
        WHEN dcn.category_id = 1 THEN 'NICU'
        WHEN dcn.category_id = 2 THEN 'PICU'
        ELSE 'ADULT'
    END as CaseCategory
    ,cp.campus_name as campus
    ,concat(hospital.value,'.',s.case_group_id) as SignatureID
    #,met.TotalCharges as SignatureCharges
    ,COALESCE(
        bb.Bas_Assigned_Name,
        AES_DECRYPT(a2.name,'",@EncKey,"') 
             ) AS 'BAS Assigned'
    ,cvd.Invoicing
    ,d.case_group
    ,esi_verification_date
    ,IFNULL(REPLACE(o8.field_value,'amp;',''),AES_DECRYPT(EmpName,'",@EncKey,"')) as 'Employer'
    ,CASE
    	#WHEN t.Override IS NOT NULL THEN t.Override
    	#WHEN o.Override IS NOT NULL THEN cvd.charges - o.Override
    	WHEN EOMCharges(t.case_id, FROM_UNIXTIME(t.created,"'"%Y-%m-%d"'")) IS NULL AND cvd.charges IS NULL THEN t.Override
    	WHEN cvd.charges IS NULL THEN NULL
    	WHEN EOMCharges(t.case_id, FROM_UNIXTIME(t.created,"'"%Y-%m-%d"'")) IS NULL THEN cvd.charges
    	ELSE EOMCharges(t.case_id, FROM_UNIXTIME(t.created,"'"%Y-%m-%d"'"))
    END as EOMCharges
FROM Cohort t
LEFT JOIN Overrides o on t.case_id = o.case_id
LEFT JOIN demographics d on t.case_id = d.id
LEFT JOIN campuses cp on d.campus = cp.id
LEFT JOIN CaseEnrollmentRank ce on d.id = ce.case_id and ce.rownum = 1
LEFT JOIN admin_user a2 ON ce.bas_assigned = a2.id
LEFT JOIN admin_user a ON d.case_owner = a.id
LEFT JOIN case_enrollment_details_current o8 on d.id = o8.case_id and o8.field_type = 'employer' and o8.field_key = 'NAME' and o8.is_deleted = 0
LEFT JOIN EmployerRank et on d.id = et.case_id and et.rownum = 1
LEFT JOIN employer_new en on en.id = et.employer_id
LEFT JOIN CaseDetailsRanks cvd on t.case_id = cvd.case_id and cvd.rownum = 1
LEFT JOIN (select * from demographics_category group by case_id) dcn on  dcn.case_id = d.id
LEFT JOIN setting hospital on hospital.setting_key = 'HOSPITAL_NAME'
LEFT JOIN setting rvp on rvp.setting_key = 'RVP_NAME'
LEFT JOIN setting region on region.setting_key ='REGION'
LEFT JOIN BAS bb ON d.id = bb.id
LEFT JOIN Track_Sig s on t.case_id = s.case_id and s.created = (SELECT min(s2.created) FROM Track_Sig s2 WHERE  s.case_id = s2.case_id)
AND (hospital.value = 'Phoebe' OR cp.campus_isactive = 1)
");

PREPARE stmt FROM @sql;
EXECUTE stmt;

END$$    
DELIMITER ;