DROP PROCEDURE IF EXISTS SavedEmployerReadmits;
DELIMITER $$
CREATE PROCEDURE SavedEmployerReadmits(Input_val CHAR(100), Input_days INT, Input_Feed VARCHAR(255))
BEGIN
SET @EncKey = EncKey();
SET SESSION group_concat_max_len = 1000000;

IF Input_Feed = '0' THEN
  SET @FeedbackFilter := '';
  SET @JoinFeedBack := "LEFT JOIN Feedback f ON d.id = f.case_id AND f.rownum = 1";
ELSEIF Input_Feed = '1' THEN
  SET @FeedbackFilter := "
    WHERE (
      DATEDIFF(NOW(), time) > 60
      OR (
        feedback NOT LIKE '%NO ACCESS TO ESI%'
        AND feedback NOT LIKE '%Hospital Employee%'
        AND feedback NOT LIKE '%Medicare A and B%'
        AND feedback NOT LIKE '%Medicare A & B%'
      )
    )";
  SET @JoinFeedBack := "INNER JOIN Feedback f ON d.id = f.case_id AND f.rownum = 1";
ELSE
  SET @InputArray := Input_Feed;
  SET @FeedbackFilter := 'WHERE (';
  WHILE LOCATE(',', @InputArray) > 0 DO
    SET @part := SUBSTRING_INDEX(@InputArray, ',', 1);
    SET @FeedbackFilter := CONCAT(@FeedbackFilter, " feedback LIKE '", @part, "' OR");
    SET @InputArray := SUBSTRING(@InputArray, LOCATE(',', @InputArray) + 1);
  END WHILE;
  SET @FeedbackFilter := CONCAT(@FeedbackFilter, " feedback LIKE '", @InputArray, "')");
  SET @JoinFeedBack := "INNER JOIN Feedback f ON d.id = f.case_id AND f.rownum = 1";
END IF;

SET @sql = NULL;
SET @sql = CONCAT(
"WITH
Current_Balance AS (
  SELECT
    case_id,
    CAST(REPLACE(REPLACE(AES_DECRYPT(Total_Acc_Bal, '", @EncKey, "'), '$', ''), ',', '') AS DECIMAL(10,2)) AS CurrentBalance,
    DATE_FORMAT(STR_TO_DATE(discharge_date, '%m/%d/%Y'), '%Y/%m/%d') AS discharge_date,
    ROW_NUMBER() OVER (PARTITION BY case_id ORDER BY DATE_FORMAT(STR_TO_DATE(admit_date, '%m/%d/%Y'), '%Y/%m/%d') DESC, created_at DESC) AS rn_balance
  FROM charges
),

AssignedUsers AS (
  SELECT 
    a.case_id,
    u.username AS Assignee
  FROM cases_assigned_users a
  LEFT JOIN admin_user u ON a.user_id = u.id
  WHERE a.id = (
    SELECT MAX(a2.id)
    FROM cases_assigned_users a2
    WHERE a.case_id = a2.case_id
  )
),

Feedback AS (
  SELECT *,
    ROW_NUMBER() OVER (PARTITION BY case_id ORDER BY id DESC) AS rownum
  FROM case_feedback
  ", @FeedbackFilter, "
),

MaxCase AS (
  SELECT 
    case_id,
    MAX(id) AS id
  FROM track_case
  GROUP BY case_id
),

Previous_Status AS (
  SELECT 
    d.id AS case_id,
    cs.status AS CurrentStatus,
    cs1.status AS PreviousStatus
  FROM demographics d
    LEFT JOIN case_status cs ON cs.value = d.case_status
    LEFT JOIN (
      SELECT tc1.*
      FROM track_case tc1
      INNER JOIN (
        SELECT case_id, MAX(created) AS max_created
        FROM track_case
        GROUP BY case_id
      ) tc2 ON tc1.case_id = tc2.case_id AND tc1.created = tc2.max_created
  ) tc ON tc.case_id = d.id
  LEFT JOIN case_status cs1 ON cs1.value = tc.previous_status
 # WHERE cs.status = 'Saved Employer Cases'
)

SELECT 
  hospital.value AS 'Hospital',
  rvp.value AS 'RVP',
  d.id AS 'Case_ID',
  cp.campus_name AS Campus,
  CONCAT(GetFirstName(d.id), ' ', GetLastName(d.id)) AS Name,
  CAST(AES_DECRYPT(d.MRN, '", @EncKey, "') AS CHAR) AS MRN,
  d.admit_dates AS Date_Admitted,
  c.status AS Bucket,
  FROM_UNIXTIME(t.created, '%Y-%m-%d') AS MovedToBucket,
  d.days_left AS DaysLeft,
  d.Total_Acc_Bal,
  cb.CurrentBalance,
  cb.discharge_date AS DischargeDate,
  a.username AS CaseOwner,
  au.Assignee AS AssignedUser,
  f.feedback AS FeedbackReason,
  ps.PreviousStatus
FROM demographics d
LEFT JOIN case_status c ON d.case_status = c.value
LEFT JOIN setting rvp ON rvp.setting_key = 'RVP_NAME'
LEFT JOIN setting hospital ON hospital.setting_key = 'HOSPITAL_NAME'
LEFT JOIN MaxCase m ON d.id = m.case_id
LEFT JOIN track_case t ON m.case_id = t.case_id AND m.id = t.id
LEFT JOIN admin_user a ON d.case_owner = a.id
LEFT JOIN AssignedUsers au ON d.id = au.case_id
LEFT JOIN Previous_Status ps ON ps.case_id = d.id
LEFT JOIN Current_Balance cb ON cb.case_id = d.id AND cb.rn_balance = 1
", @JoinFeedBack, "
LEFT JOIN campuses cp ON d.campus = cp.id
WHERE FIND_IN_SET(c.status, '", Input_val, "')
  AND d.days_left > '", Input_days, "'
  AND d.Total_Acc_Bal != cb.CurrentBalance
  AND AES_DECRYPT(d.MRN, '", @EncKey, "') NOT LIKE '%0-%'
  AND (hospital.value = 'Phoebe' OR cp.campus_isactive = 1)
ORDER BY d.days_left DESC"
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
END$$
DELIMITER ;