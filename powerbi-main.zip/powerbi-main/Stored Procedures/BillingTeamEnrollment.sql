DROP PROCEDURE IF EXISTS BillingTeamEnrollment;
DELIMITER $$    
 
CREATE PROCEDURE BillingTeamEnrollment()
BEGIN
    SET @EncKey = EncKey();
    SET SESSION group_concat_max_len = 1000000;
 
    SET @sql = NULL;
    SET @sql = CONCAT(
"WITH CaseEnrollmentRank AS (
    SELECT *, 
           ROW_NUMBER() OVER (PARTITION BY case_id ORDER BY id ASC) AS rownum
    FROM case_enrollment
),
 
Notee AS (
    SELECT 
        d.case_group, 
        MAX(DATE_FORMAT(n.date_add, '%Y-%m-%d')) AS NoteDatee
    FROM demographics d
    LEFT JOIN notes n ON n.case_id = d.id
    GROUP BY d.case_group
),
 
Last_note_date AS (
    SELECT 
        d.id, 
        COALESCE(n.NoteDatee, MAX(DATE_FORMAT(nn.date_add, '%Y-%m-%d'))) AS Last_note_date
    FROM demographics d
    LEFT JOIN notes nn ON nn.case_id = d.id
    LEFT JOIN Notee n ON n.case_group = d.case_group
    GROUP BY d.id
),
 
Bas_Assign_Case_Group AS (
    SELECT 
        d.case_group,
        MAX(AES_DECRYPT(au.name, '", @EncKey, "')) AS bas_assign,
        MAX(Last_note_date) AS Last_note_date
    FROM demographics d 
    LEFT JOIN case_enrollment ce ON d.id = ce.case_id
    LEFT JOIN admin_user au ON ce.bas_assigned = au.id
    LEFT JOIN Last_note_date lnd ON lnd.id = d.id
    GROUP BY d.case_group  
),
 
all_links AS (
    WITH RECURSIVE bidirectional AS (
        SELECT case_id, linked_case_id
        FROM linked_case
        UNION
        SELECT linked_case_id, case_id
        FROM linked_case
    ),
    recurse AS (
        SELECT
            case_id,
            linked_case_id,
            CAST(case_id AS CHAR(200)) AS path
        FROM bidirectional
        UNION ALL
        SELECT
            r.case_id,
            b.linked_case_id,
            CONCAT(r.path, ',', b.linked_case_id) AS path
        FROM recurse r
        JOIN bidirectional b
            ON r.linked_case_id = b.case_id
        WHERE FIND_IN_SET(b.linked_case_id, r.path) = 0
    )
    SELECT DISTINCT
        case_id,
        linked_case_id AS linked_case
    FROM recurse
),
 
Linked_cases AS (
    SELECT 
        al.case_id,
        d.case_group,
        COALESCE(
            AES_DECRYPT(au1.name, '", @EncKey, "'),
            AES_DECRYPT(au2.name, '", @EncKey, "'),
            bgg.bas_assign
        ) AS BAS_Assigned,
        bgg.Last_note_date,
        GROUP_CONCAT(
            DISTINCT 
            CASE 
                WHEN al.linked_case != d.id THEN al.linked_case 
                ELSE NULL 
            END 
            ORDER BY al.linked_case
        ) AS linked_cases
    FROM all_links al
    LEFT JOIN demographics d ON d.id = al.case_id
    LEFT JOIN case_enrollment ce ON ce.case_id = al.case_id
    LEFT JOIN admin_user au1 ON ce.bas_assigned = au1.id
    LEFT JOIN Bas_Assign_Case_Group bgg ON bgg.case_group = d.case_group
    LEFT JOIN case_enrollment c ON c.case_id = al.linked_case
    LEFT JOIN admin_user au2 ON c.bas_assigned = au2.id
    GROUP BY al.case_id, d.case_group, bgg.Last_note_date
)

 
SELECT DISTINCT
    d.id AS CaseID,
    hospital.value AS Hospital,
    d.Total_Acc_Bal AS TotalCharges,
    cs.status AS Bucket,
    AES_DECRYPT(d.MRN, '", @EncKey, "') AS MRN,
    d.days_left AS 'Days Left',
    GetDOB(d.id) AS DOB,
    d.admit_dates AS AdmitDate,
    COALESCE(ce.potential_charges, cr.potential_charges) AS 'Potential Charges',
#   CASE
#       WHEN DATEDIFF(d.admit_dates, GetDOB(d.id)) <= 7 AND DATEDIFF(CURDATE(), d.admit_dates) < 30 
#           THEN GetDOB(d.id)
#       ELSE 
#           COALESCE(
#               STR_TO_DATE(ce.effective_date, '%m/%d/%Y'), 
#               STR_TO_DATE(cl.effective_date, '%m/%d/%Y'))
#   END AS Recommended_EffectiveDate,
    COALESCE(
        STR_TO_DATE(ce.effective_date, '%m/%d/%Y'), 
        STR_TO_DATE(cl.effective_date, '%m/%d/%Y')
    ) AS Recommended_EffectiveDate,
    GetLastName(d.id) AS LastName,
    GetFirstname(d.id) AS FirstName,
    cp.campus_name as Campus,
    IF(hospital.value = 'The valley Health System', Plan.column_value, NULL) AS 'Plan Code'
FROM demographics d
LEFT JOIN Linked_cases l ON d.id = l.case_id
LEFT JOIN case_status cs ON d.case_status = cs.value 
LEFT JOIN setting hospital ON hospital.setting_key = 'HOSPITAL_NAME'
LEFT JOIN CaseEnrollmentRank ce ON d.id = ce.case_id AND ce.rownum = 1
LEFT JOIN CaseEnrollmentRank cl ON FIND_IN_SET(cl.case_id, l.linked_cases) > 0 AND cl.rownum = 1 AND cl.effective_date IS NOT NULL
LEFT JOIN CaseEnrollmentRank cr ON FIND_IN_SET(cr.case_id, l.linked_cases) > 0 AND cr.rownum = 1 AND cr.potential_charges IS NOT NULL
LEFT JOIN campuses cp on d.campus = cp.id
LEFT JOIN (SELECT case_id, AES_DECRYPT(column_value, '", @EncKey, "') column_value FROM demographic_meta WHERE column_name = 'PlanCode') Plan ON Plan.case_id = d.id
WHERE 
    LEFT(AES_DECRYPT(d.MRN, '", @EncKey, "'), 2) != '0-'
    AND cs.status IN ('App prep', 'Employer Outreach', 'Application Sent')
    AND (hospital.value = 'Phoebe' OR cp.campus_isactive = 1) "
    );
 
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    
END$$    
 
DELIMITER ;