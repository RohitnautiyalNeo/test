DROP PROCEDURE IF EXISTS SigChargeInfo;

DELIMITER $$    
CREATE PROCEDURE SigChargeInfo()
BEGIN

 SELECT setting.value
 ,format.value 
 into 
 @Admit_DT
 ,@Admit_DT_Format
 from setting 
 left join setting format on format.setting_key = 'ADMIT_DATE_FORMAT'
 where setting.setting_key = 'ADMIT_DATE_FIELD';

SET @EncKey = EncKey();
SET SESSION group_concat_max_len = 1000000;
 
 SET @sql = NULL;
 SET @sql = CONCAT("
 
WITH Cohort AS (
SELECT DISTINCT 
 IFNULL(d.id,s.case_id) AS case_id
,s.user_id
,FROM_UNIXTIME(s.created,'%Y-%m-%d') AS created
,LAST_DAY(FROM_UNIXTIME(s.created,'%Y-%m-%d')) AS LDOM
,DATE_SUB(FROM_UNIXTIME(s.created,'%Y-%m-%d'), INTERVAL 60 DAY) AS SixtyPrior
,AES_DECRYPT(d.MRN, '",@EncKey,"') AS MRN
,CONCAT(setting.value,'.',s.case_group_id) AS SignatureID
,o.type AS OutreachType
,cs.status
FROM (
        SELECT case_id, user_id, campus, case_group_id, created, outreach_type
        FROM signatures 
        GROUP BY IF(case_group_id IS NULL 
                    OR case_group_id = '', CONCAT('CG- ',case_id), case_group_id)
     ) AS s
LEFT JOIN demographics d ON s.case_group_id = d.case_group
LEFT JOIN setting ON setting_key = 'HOSPITAL_NAME'
LEFT JOIN outreach_type o ON s.outreach_type = o.type_id
LEFT JOIN case_status cs ON d.case_status = cs.value
WHERE user_id IS NOT NULL 
AND user_id IN (
                SELECT id 
                FROM admin_user 
                WHERE user_type != 1 
                AND username NOT IN ('shivam_support','revmax_superadmin','amit_support')
               )
AND s.case_id NOT IN (
                        SELECT id 
                        FROM demographics 
                        WHERE AES_DECRYPT(MRN, '",@EncKey,"') LIKE '0-%'
                     )
),

ME_Total_Charges AS (
SELECT
 x.case_id,
 SUM(x.TotalCharges) AS TotalCharges,
 MAX(x.created_at) AS created_at_max
FROM (
        SELECT c.case_id,
         CAST(REPLACE(REPLACE(AES_DECRYPT(c.Total_Acc_Bal, '",@EncKey,"'),'$',''),',','') AS DECIMAL(10,2)) AS TotalCharges,
         c.created_at, 
         ROW_NUMBER() OVER (PARTITION BY c.case_id, AES_DECRYPT(c.charges_ref_number, '",@EncKey,"') ORDER BY c.id DESC) AS rn
        FROM charges c
        INNER JOIN Cohort h ON h.case_id = c.case_id
        WHERE AES_DECRYPT(c.Total_Acc_Bal, '",@EncKey,"') IS NOT NULL
        AND FROM_UNIXTIME(c.created_at,'%Y-%m-%d') <= h.LDOM
     ) x
WHERE x.rn = 1
GROUP BY x.case_id
),

Sixty_Prior_Charges AS (
SELECT
 x.case_id,
 SUM(x.TotalCharges) AS TotalCharges,
 MAX(x.created_at) AS created_at_max
FROM (
        SELECT c.case_id,
         CAST(REPLACE(REPLACE(AES_DECRYPT(c.Total_Acc_Bal, '",@EncKey,"'),'$',''),',','') AS DECIMAL(10,2)) AS TotalCharges,
         c.created_at,
         ROW_NUMBER() OVER (PARTITION BY c.case_id, AES_DECRYPT(c.charges_ref_number, '",@EncKey,"') ORDER BY c.id DESC) AS rn
        FROM charges c
        INNER JOIN Cohort h ON h.case_id = c.case_id
        WHERE AES_DECRYPT(c.Total_Acc_Bal, '",@EncKey,"') IS NOT NULL
        AND STR_to_date(admit_date,'",@Admit_DT_Format,"') >= h.SixtyPrior
        AND FROM_UNIXTIME(c.created_at,'%Y-%m-%d') <= h.LDOM
     ) x
WHERE x.rn = 1
GROUP BY x.case_id
)
 
SELECT 
 s.case_id
,s.SignatureID
,IFNULL(c.TotalCharges,0) AS TotalCharges
,IFNULL(sc.TotalCharges,0) AS SixtyPriorCharges
FROM Cohort s
LEFT JOIN ME_Total_Charges c ON s.case_id = c.case_id
LEFT JOIN Sixty_Prior_Charges sc ON s.case_id = sc.case_id 
ORDER BY case_id
");
 
 PREPARE stmt FROM @sql;
 EXECUTE stmt;
 
 END$$    
 DELIMITER ;