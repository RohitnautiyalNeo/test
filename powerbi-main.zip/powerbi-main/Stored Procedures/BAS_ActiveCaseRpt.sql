DROP PROCEDURE IF EXISTS BasActiveCases;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `BasActiveCases`(IN `ReportType` INT)
BEGIN

SET @EncKey = EncKey();
SET SESSION group_concat_max_len = 1000000;

SET @sql = NULL;
SET @sql = CONCAT("
              
With 
Linked_Cases as (
select d.id as case_id
,IFNULL(l2.case_id,l.linked_case_id) as linked_caseID
from demographics d
LEFT JOIN linked_case l on d.id = l.case_id and l.id = (select ll.id from linked_case ll where l.case_id = ll.case_id group by case_id)
LEFT JOIN linked_case l2 on d.id = l2.linked_case_id and l2.id = (select ll.id from linked_case ll where l2.linked_case_id = ll.linked_case_id group by linked_case_id)
),

Notee AS (
    SELECT  
        d.case_group, 
        MAX(DATE_FORMAT(n.date_add, '%Y-%m-%d')) AS NoteDatee
    FROM demographics d
    LEFT JOIN notes n ON n.case_id = d.id
    GROUP BY d.case_group
),

Last_note_date AS (
    SELECT 
        d.id, 
        COALESCE(
            n.NoteDatee, 
            MAX(DATE_FORMAT(nn.date_add, '%Y-%m-%d'))
                  ) AS Last_note_date
    FROM demographics d
    LEFT JOIN notes nn on nn.case_id = d.id
    LEFT JOIN Notee n ON n.case_group = d.case_group
    GROUP BY d.id
),

Employer_Response as (
SELECT case_id
,MAX(NoteDate) as NoteDate
FROM notes n
LEFT JOIN note_type nt on n.Note_type = nt.type_id
WHERE nt.type = 'Employer Response'
GROUP BY case_id
),

Enrollment_Complete as (                  
SELECT case_id
,NoteDate
,ROW_NUMBER () OVER(PARTITION BY n.case_id ORDER BY n.id asc) as rownum
FROM notes n
LEFT JOIN demographics d on n.case_id = d.id
WHERE AES_DECRYPT(Note,'",@EncKey,"') like '%Enrollment Status%ENROLLMENT COMPLETE%'
), 
 
ESI_Consent_Received AS (
    SELECT case_id
    ,NoteDate
    ,ROW_NUMBER () OVER(PARTITION BY n.case_id ORDER BY n.id asc) as rownum
    FROM notes n 
    LEFT JOIN demographics d ON n.case_id = d.id
    WHERE AES_DECRYPT(Note,'",@EncKey,"') LIKE '%ESI Consent Received%'
 
),

CaseEnrollmentRank as (
SELECT ce.*
,ROW_NUMBER () OVER(PARTITION BY case_group ORDER BY id asc) as rownum
,d.case_group
FROM case_enrollment ce
LEFT JOIN demographics d on ce.case_id = d.id
),

BAS as
(SELECT d.id 
,c.bas_assigned, 
AES_DECRYPT(a.name,'",@EncKey,"') AS Bas_Assigned_Name
FROM demographics d
LEFT JOIN CaseEnrollmentRank c on d.case_group = c.case_group and c.rownum = 1
LEFT JOIN admin_user a ON a.id = c.bas_assigned
),
                  
Is_Active as
(SELECT d.id 
,c.is_active_case
FROM demographics d
LEFT JOIN CaseEnrollmentRank c on d.case_group = c.case_group and c.rownum = 1
),

CostEffective as (
SELECT case_id
,CASE 
     WHEN NotCostEffective = 1 THEN 'No'
     WHEN CE = 1 THEN 'C/E'
     ELSE NULL
END as 'CE'
,CASE
     WHEN CE = 1 THEN FROM_UNIXTIME(created)
     ELSE NULL
END as CE_Date
FROM (
select s.case_id
,s.NotCostEffective
,max(p.family_members_enrolling) as CE
,p.created
from state_operations s
INNER JOIN state_operations_plans p on s.id = p.relation_id
group by case_id) as InnerTable
),

AppPrepStart as (
SELECT case_id
,cs.status
,FROM_UNIXTIME(MIN(created)) as created
FROM track_case tc
LEFT JOIN case_status cs on tc.status = cs.value
WHERE cs.status = 'App Prep'
GROUP BY case_id, status
),  

Last_BAS_Touch as (
SELECT n.case_id
,MAX(NoteDate) as NoteDate
FROM CaseEnrollmentRank ce
INNER JOIN notes n on ce.case_id = n.case_id AND ce.bas_assigned = n.added_by
WHERE ce.rownum = 1
GROUP BY case_id
),

Last_Moved_Date as (
select case_id
,max(created) as created
from track_case 
GROUP BY case_id
),

PtSSN as (
SELECT o.case_id
,o.field_value as SSN
FROM (
SELECT *
FROM case_enrollment_details_current
WHERE field_key = 'PATIENT'
and field_value in ('Yes','yes')
group by case_id) InnerTable
LEFT JOIN case_enrollment_details_current o on InnerTable.case_id = o.case_id AND 
o.field_key = 'SSN' AND 
o.field_type = InnerTable.field_type AND 
o.familymembernumber = InnerTable.familymembernumber AND
o.is_deleted = 0
),

SO_Lastnote_detail as (
Select 
        n.case_id,
        AES_DECRYPT(au.name, '",@EncKey,"') as user,
        n.Notedate AS Notedate,
        nt.type AS note_type,
        AES_DECRYPT(n.Note, '",@EncKey,"') AS note,
        AES_DECRYPT(au.name, '",@EncKey,"') AS name,
        ROW_NUMBER() OVER (PARTITION BY case_id ORDER BY n.date_upd DESC) AS rownum

from notes n
LEFT JOIN admin_user au ON au.id=n.added_by
LEFT JOIN note_type nt ON nt. type_id=n. Note_type
where AES_DECRYPT(au. name,'",@EncKey,"') IN ('Abby Brady','Erin Mullen', 'Kaitlin Roderick', 'Kelly Doherty', 'Nicole Norton', 'Nolan Piskorski', 'Olivia Rogers', 'Paige Murphy','Heven Wolde','Daniel Gleason','Jany Gonzalez')
),

BAS_Lastnote_detail as (
Select 
        n.case_id,
        AES_DECRYPT(au.name, '",@EncKey,"') as user,
        n.Notedate AS Notedate,
        nt.type AS note_type,
        AES_DECRYPT(n.Note, '",@EncKey,"') AS note,
        AES_DECRYPT(au.name, '",@EncKey,"') AS name,
        ROW_NUMBER() OVER (PARTITION BY case_id ORDER BY n.date_upd DESC) AS rownum

from notes n
LEFT JOIN admin_user au ON au.id=n.added_by
LEFT JOIN note_type nt ON nt. type_id=n. Note_type
where AES_DECRYPT(au. name,'",@EncKey,"') IN ('Antonett A Young', 'Anamaria Mercedez','Allison A. Anderson', 'Daniel Cronin', 'Gheevar Jacob', 'Melissa Sorrentino', 'Imbry Ladd', 'Julie Murphy', 'Gabi Zanelli')
),

EO_Lastnote_detail as (
select 
        n.case_id,
        AES_DECRYPT(au.name, '",@EncKey,"') as user,
        n.Notedate AS Notedate,
        nt.type AS note_type,
        AES_DECRYPT(n.Note, '",@EncKey,"') AS note,
        AES_DECRYPT(au.name, '",@EncKey,"') AS name,
        ROW_NUMBER() OVER (PARTITION BY case_id ORDER BY n.date_upd DESC) AS rownum

from notes n
LEFT JOIN admin_user au ON au.id=n.added_by
LEFT JOIN note_type nt ON nt. type_id=n. Note_type
where AES_DECRYPT(au. name,'",@EncKey,"') IN ('Cheryl Chase', 'Danielle Ciaccio', 'Donna Griffin', 'Jen Ford', 'Noreen Consentino')
)

SELECT 
    IF(COALESCE(ce.is_active_case, ia.is_active_case) = 'yes','Active Case', NULL) AS 'Active Case'
    ,s.value AS 'Hospital'
    ,cs.status AS 'Bucket'
    ,DATEDIFF(NOW(),FROM_UNIXTIME(lmd.created)) as 'Days in Bucket'
    ,d.id as CaseID
    ,l.linked_caseID as 'linked CaseID'
    ,ce.qle_type as QLE
    ,d.Total_Acc_Bal AS 'Total Charges' 
    ,AES_DECRYPT(d.MRN,'",@EncKey,"') AS MRN 
    ,region.value AS Region 
    ,COALESCE(
        bb.Bas_Assigned_Name,
        AES_DECRYPT(a.name,'",@EncKey,"'),
        AES_DECRYPT(a2.name,'",@EncKey,"') 
             ) AS 'BAS Assigned'
    ,d.admit_dates AS 'Admit Date'
    ,d.days_left AS 'Days Left' 
    ,IFNULL(REPLACE(o8.field_value,'amp;',''),AES_DECRYPT(EmpName,'#ENCKEY#')) as 'Employer'
    ,IFNULL(ce.potential_charges,cl.potential_charges) AS 'Potential Charges'
	,CASE
		WHEN s.value in ('CHOA','Northern Light','Prisma Health','The valley Health System','Northeast Georgia',
		                        'Emory Health System','Northside','Phoebe','Saint Francis','Augusta University Medical Center') and ap.created IS NOT NULL THEN DATE(ap.created)
   	    ELSE DATE(cef.CE_Date)
	 END as 'C/E Date'
    ,ecr.NoteDate AS 'ESI Consent Date'
    ,IFNULL(ce.enrollment_sent,cl.enrollment_sent) AS 'Enrollment Start Date'
    ,DATEDIFF(CURDATE(),Ln.Last_note_date) AS 'Days Since Last Touched'
    ,Ln.Last_note_date as 'Last Note Date'
    ,IFNULL(ce.provided_by_hr,cl.provided_by_hr) AS 'Booking Scheduled'
    ,IFNULL(ce.enrollment_status,cl.enrollment_status) AS 'Enrollment Status'
    ,er.NoteDate as 'Last Employer Response'
    ,lb.NoteDate as 'Last BAS Touch'
    ,IFNULL(ce.employer_responsive,cl.employer_responsive) AS 'Employer Responsive'
    ,TRIM(
        CONCAT_WS(
            ', ',
            CASE WHEN ce.dv_not_required = 'yes' THEN 'dv_not_required' ELSE NULL END, 
            CASE WHEN ce.dv_received = 'yes' THEN 'dv_received' ELSE NULL END, 
            CASE WHEN ce.dv_send_to_hr = 'yes' THEN 'dv_send_to_hr' ELSE NULL END, 
            CASE WHEN ce.bc_ordered = 'yes' THEN 'bc_ordered' ELSE NULL END, 
            CASE WHEN ce.order_bc = 'yes' THEN 'order_bc' ELSE NULL END 
        )
    ) AS 'Patient DV Status'
    ,IFNULL(ce.retro_leave_balance,cl.retro_leave_balance) AS 'Retro / Leave Status'
    ,IFNULL(ce.leave_status,cl.leave_status) AS 'Leave Status'
    ,IFNULL(ce.deduction_letter,cl.deduction_letter) AS 'Deduction Letter Status'
    ,IFNULL(ce.esi_issues,cl.esi_issues) AS 'ESI Issues'
    ,IFNULL(ce.verification_status,cl.verification_status) AS 'Verification Status'
    ,ec.NoteDate as 'Enrollment Complete'
    ,CONCAT('( ',sln.Notedate,' )',' (  ',sln.note_type,' ) ',sln.note) as 'State ops Last Note Detail'
    ,CONCAT('( ',bln.Notedate,' )',' (  ',bln.note_type,' ) ',bln.note) as 'BAS Last Note Detail'
    ,CONCAT('( ',eln.Notedate,' )',' (  ',eln.note_type,' ) ',eln.note) as 'EO Last Note Detail'
    ,IFNULL(ce.is_outstanding_tasks,cl.is_outstanding_tasks) AS 'All ESI Tasks Completed'
    ,cv.esi_verification_date AS 'Verified'
    ,cv.charges as 'Captured Charges'
    ,MONTHNAME(STR_TO_DATE(ce.verify_commit_date,'%m/%d/%Y')) as CommitMonth
    ,CASE
    	WHEN ssn.SSN IS NULL THEN 'N'
    	ELSE 'Y'
    END as 'Patient SSN'
",
CASE
	WHEN ReportType = '0' THEN 
"FROM CaseEnrollmentRank ce
LEFT JOIN demographics d ON ce.case_id = d.id"
    WHEN ReportType = '1' THEN 
"FROM demographics d 
LEFT JOIN CaseEnrollmentRank ce ON ce.case_id = d.id AND ce.rownum = 1"
END,
"
LEFT JOIN employers_tab et on d.id = et.case_id and et.id = (select max(et2.id) from employers_tab et2 where et.case_id = et2.case_id)
LEFT JOIN employer_new en on en.id = et.employer_id
LEFT JOIN Linked_Cases l on d.id = l.case_id
LEFT JOIN CaseEnrollmentRank cl on ce.case_id = l.linked_caseID AND ce.rownum = 1
LEFT JOIN admin_user a2 ON cl.bas_assigned = a2.id
LEFT JOIN Employer_Response er on d.id = er.case_id 
LEFT JOIN Last_BAS_Touch lb on d.id = lb.case_id
LEFT JOIN Last_Moved_Date lmd on d.id = lmd.case_id
LEFT JOIN Enrollment_Complete ec on d.id = ec.case_id and ec.rownum = 1
LEFT JOIN case_status cs on d.case_status = cs.value
LEFT JOIN case_verification_details cv ON cv.case_id = d.id and cv.data_from = 'enable' and cv.id = (select id from case_verification_details cv2 where cv.case_id = cv2.case_id group by case_id)
LEFT JOIN setting s ON s.setting_key = 'HOSPITAL_NAME'
LEFT JOIN admin_user a ON ce.bas_assigned = a.id
LEFT JOIN setting region ON region.setting_key = 'REGION'
LEFT JOIN setting rvp ON rvp.setting_key = 'RVP_NAME'
LEFT JOIN AppPrepStart ap on d.id = ap.case_id
LEFT JOIN CostEffective cef on d.id = cef.case_id
LEFT JOIN PtSSN ssn on d.id = ssn.case_id
LEFT JOIN ESI_Consent_Received ecr ON ecr.case_id = d.id and ecr.rownum = 1
LEFT JOIN Last_note_date Ln ON Ln.id = d.id
LEFT JOIN BAS bb ON d.id = bb.id
LEFT JOIN Is_Active ia ON ia.id = d.id
LEFT JOIN case_enrollment_details_current o8 on d.id = o8.case_id and 
                            o8.field_type = 'employer' and 
                            o8.field_key = 'NAME' and 
                            o8.is_deleted = 0 
LEFT JOIN SO_Lastnote_detail sln ON sln.case_id=d.id AND sln.rownum=1
LEFT JOIN BAS_Lastnote_detail bln ON bln.case_id=d.id AND bln.rownum=1
LEFT JOIN EO_Lastnote_detail eln ON eln.case_id=d.id AND eln.rownum=1
LEFT JOIN campuses cp ON cp.id = d.campus
",
CASE
	WHEN ReportType = '0' THEN 
"WHERE ce.is_active_case = "'"yes"'"
and ce.rownum = 1"
    WHEN ReportType = '1' THEN 
"WHERE cs.status in ('App Prep', 'Application Sent', 'Application Approved', 'Employer Outreach', 'Maintenance', 'Issue bucket')"
END,
"
AND AES_DECRYPT(d.MRN,'",@EncKey,"') NOT LIKE "'"%0-%"'"
AND (s.value = 'Phoebe' OR cp.campus_isactive = 1)
ORDER BY cs.status
");

PREPARE stmt FROM @sql;
EXECUTE stmt;

END$$
DELIMITER ;