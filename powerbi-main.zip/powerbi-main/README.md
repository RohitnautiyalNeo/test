## PFA Data Analytics GitHub Repository

The purpose of this repository is for 
1. Documenting processes for the data analytics team
2. Version control for data analytics files

### Stored Procedures

Stores the master version of the stored procedures since we are unable to see the master version of the code in the Prisma templates

### Functions

Stores the master version of the various functions used in both Enable and CATS